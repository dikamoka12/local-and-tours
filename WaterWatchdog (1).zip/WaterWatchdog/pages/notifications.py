import streamlit as st
import pandas as pd
from utils.authentication import get_user_details, is_subscription_active
from utils.notifications import register_notification_preferences, send_water_quality_alert
from utils.data_processor import get_pollution_alerts
import json
import time
import phonenumbers

def app():
    """Notifications page for managing alert preferences and testing notifications"""
    st.title("Water Quality Alerts & Notifications")
    
    # Get user authentication status
    if 'authentication_status' not in st.session_state or not st.session_state['authentication_status']:
        st.warning("Please log in to access notification settings")
        st.info("If you don't have an account, you can register in the login page")
        return
    
    username = st.session_state['username']
    user_details = get_user_details(username)
    
    # Check if user has an active subscription
    subscription_active = is_subscription_active(username)
    
    # Display tabs
    tab1, tab2, tab3 = st.tabs(["Alert Settings", "Test Notification", "Recent Alerts"])
    
    with tab1:
        st.header("Notification Settings")
        
        if not subscription_active:
            st.warning("SMS notifications require an active subscription. Please subscribe to enable this feature.")
            st.button("Go to Subscription Page", on_click=lambda: st.switch_page("pages/subscription.py"))
        else:
            st.success("Your subscription is active. You can configure and receive SMS notifications.")
            
            # Notification settings form
            with st.form("notification_settings_form"):
                st.subheader("Configure your alert preferences")
                
                # Phone number with country code selection
                col1, col2 = st.columns([1, 2])
                with col1:
                    country_code = st.selectbox(
                        "Country Code",
                        options=["+27", "+1", "+44", "+61", "+64", "+81", "+86", "+91", "+254", "+255", "+256", "+250"],
                        index=0,
                        help="Select your country code"
                    )
                with col2:
                    phone_number = st.text_input(
                        "Phone Number (without country code)",
                        placeholder="e.g., 731234567",
                        help="Enter your phone number without the country code"
                    )
                
                # Combine country code and phone number
                full_phone_number = f"{country_code}{phone_number}" if phone_number else ""
                
                # Validate phone number format
                phone_valid = False
                phone_error = None
                if phone_number:
                    try:
                        parsed_number = phonenumbers.parse(full_phone_number)
                        phone_valid = phonenumbers.is_valid_number(parsed_number)
                        if not phone_valid:
                            phone_error = "Invalid phone number format"
                    except Exception:
                        phone_error = "Please enter a valid phone number"
                
                if phone_error:
                    st.error(phone_error)
                
                # Region selection
                st.subheader("Select regions to monitor")
                regions_col1, regions_col2 = st.columns(2)
                
                with regions_col1:
                    monitor_all = st.checkbox("Monitor all regions", value=True)
                
                if monitor_all:
                    selected_regions = ["All"]
                else:
                    with regions_col2:
                        selected_regions = st.multiselect(
                            "Select specific regions",
                            options=["Western Cape", "Eastern Cape", "Northern Cape", "KwaZulu-Natal", 
                                    "Free State", "North West", "Gauteng", "Mpumalanga", "Limpopo"],
                            default=["Western Cape"]
                        )
                
                # Pollution level threshold
                min_pollution_level = st.slider(
                    "Minimum pollution level to trigger alerts",
                    min_value=1,
                    max_value=10,
                    value=7,
                    help="You'll receive alerts when pollution levels reach or exceed this value"
                )
                
                # Notification methods
                st.subheader("Notification methods")
                notification_methods = []
                
                sms_col, email_col = st.columns(2)
                with sms_col:
                    if st.checkbox("SMS notifications", value=True):
                        notification_methods.append("sms")
                
                with email_col:
                    if st.checkbox("Email notifications", value=False, disabled=True):
                        notification_methods.append("email")
                    st.caption("Email notifications coming soon")
                
                # Submit button
                submit_button = st.form_submit_button("Save Notification Preferences")
                
                if submit_button:
                    if not phone_number and "sms" in notification_methods:
                        st.error("Please enter a valid phone number for SMS notifications")
                    elif phone_error:
                        st.error(phone_error)
                    elif not notification_methods:
                        st.error("Please select at least one notification method")
                    elif not selected_regions:
                        st.error("Please select at least one region to monitor")
                    else:
                        success, message = register_notification_preferences(
                            username=username,
                            phone=full_phone_number if "sms" in notification_methods else None,
                            regions=selected_regions,
                            min_level=min_pollution_level,
                            notification_methods=notification_methods
                        )
                        
                        if success:
                            st.success("Notification preferences saved successfully!")
                        else:
                            st.error(f"Error saving preferences: {message}")
            
            # Display current settings if they exist
            if 'notification_preferences' in st.session_state and username in st.session_state.notification_preferences:
                prefs = st.session_state.notification_preferences[username]
                
                st.subheader("Current Notification Settings")
                st.markdown(f"""
                - **Phone Number**: {prefs.get('phone', 'Not set')}
                - **Regions**: {', '.join(prefs.get('regions', ['None']))}
                - **Minimum Alert Level**: {prefs.get('min_level', 'Not set')}/10
                - **Notification Methods**: {', '.join(prefs.get('methods', ['None']))}
                - **Last Updated**: {prefs.get('last_updated', 'Never')}
                """)
    
    with tab2:
        st.header("Test Notification")
        
        if not subscription_active:
            st.warning("Test notifications require an active subscription")
        elif 'notification_preferences' not in st.session_state or username not in st.session_state.notification_preferences:
            st.warning("Please configure your notification settings first")
        else:
            prefs = st.session_state.notification_preferences[username]
            
            if "sms" not in prefs.get('methods', []) or not prefs.get('phone'):
                st.warning("SMS notifications are not enabled in your settings")
            else:
                st.info("Send yourself a test notification to verify your settings")
                
                with st.form("test_notification_form"):
                    st.markdown(f"A test message will be sent to: **{prefs.get('phone')}**")
                    
                    water_source = st.text_input("Water Source Name", value="Test Water Source")
                    pollution_level = st.slider("Test Pollution Level", min_value=1, max_value=10, value=8)
                    location = st.text_input("Location", value="Test Location, South Africa")
                    
                    test_button = st.form_submit_button("Send Test Notification")
                    
                    if test_button:
                        with st.spinner("Sending test notification..."):
                            success, message = send_water_quality_alert(
                                prefs.get('phone'),
                                water_source,
                                pollution_level,
                                location
                            )
                            
                            time.sleep(1)  # Small delay for better UX
                            
                            if success:
                                st.success("Test notification sent successfully!")
                                st.info("You should receive an SMS shortly. If you don't receive it, please check your phone number.")
                            else:
                                st.error(f"Failed to send test notification: {message}")
    
    with tab3:
        st.header("Recent Water Quality Alerts")
        
        # Get recent pollution alerts
        try:
            alerts = get_pollution_alerts()
            
            if not alerts or len(alerts) == 0:
                st.info("No recent alerts to display")
            else:
                # Convert to dataframe for easier display
                alerts_df = pd.DataFrame(alerts)
                
                # Display alert data with highlighting
                st.markdown("### Critical Water Quality Issues")
                
                # Define a function to highlight rows based on pollution level
                def highlight_level(row):
                    value = row.pollution_level
                    if value >= 8:
                        return ['background-color: #ff4b4b'] * len(row)
                    elif value >= 6:
                        return ['background-color: #ffab4b'] * len(row)
                    else:
                        return ['background-color: #ffeb4b'] * len(row)
                
                # Apply styling and display
                styled_df = alerts_df.style.apply(highlight_level, axis=1)
                st.dataframe(styled_df)
                
                # Allow downloading the alert data
                st.download_button(
                    label="Download Alerts Data (CSV)",
                    data=alerts_df.to_csv(index=False).encode('utf-8'),
                    file_name="water_quality_alerts.csv",
                    mime="text/csv"
                )
        except Exception as e:
            st.error(f"Error loading alerts: {str(e)}")

# Add a check for the phonenumbers module
try:
    import phonenumbers
except ImportError:
    st.error("The phonenumbers module is required for this page. Please install it using pip.")