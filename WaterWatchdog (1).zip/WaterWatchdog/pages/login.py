import streamlit as st
import streamlit_authenticator as stauth
from utils.authentication import init_authentication, register_new_user, get_user_details
from utils.common import display_apartheid_message

def app():
    # Common header for all pages
    st.markdown("<h1 style='text-align: center; color: #1E88E5; background-color: #E3F2FD; padding: 20px; border-radius: 10px;'>SOUTH AFRICAN WATER SYSTEMS</h1>", unsafe_allow_html=True)
    st.markdown("<h2 style='text-align: center; font-size: 28px; color: #D81B60; background-color: #FCE4EC; padding: 15px; margin-top: 10px; border-radius: 10px;'>TOURISTS AND LOCALS</h2>", unsafe_allow_html=True)
    
    # Display the apartheid message
    display_apartheid_message()
    
    st.markdown("<h1 style='text-align: center; color: #1E88E5; padding: 20px;'>Login / Register</h1>", unsafe_allow_html=True)
    
    # Initialize the authenticator
    authenticator = init_authentication()
    
    # Create tabs for login and registration
    tab1, tab2 = st.tabs(["Login", "Register"])
    
    with tab1:
        # Login form
        st.subheader("Login to your account")
        
        name, authentication_status, username = authenticator.login('Login', 'main')
        
        if authentication_status:
            # User is logged in
            user_details = get_user_details(username)
            
            st.success(f"Welcome {name}!")
            st.markdown(f"**Email:** {user_details.get('email', 'Not provided')}")
            st.markdown(f"**Role:** {user_details.get('role', 'User')}")
            
            # Display subscription information
            if user_details.get('subscription_type'):
                st.markdown(f"**Subscription Type:** {user_details.get('subscription_type', 'None').capitalize()}")
                st.markdown(f"**Subscription End Date:** {user_details.get('subscription_end', 'N/A')}")
            else:
                st.info("You don't have an active subscription. Subscribe to get access to premium features!")
            
            # Logout button
            authenticator.logout('Logout', 'main')
        
        elif authentication_status == False:
            st.error('Username/password is incorrect')
        elif authentication_status == None:
            st.info('Please enter your username and password to login')
    
    with tab2:
        # Registration form
        st.subheader("Create a new account")
        
        with st.form("registration_form"):
            new_username = st.text_input("Username")
            new_name = st.text_input("Full Name")
            new_email = st.text_input("Email Address")
            new_password = st.text_input("Password", type="password")
            confirm_password = st.text_input("Confirm Password", type="password")
            
            register_button = st.form_submit_button("Register")
            
            if register_button:
                # Validate inputs
                if not new_username or not new_name or not new_email or not new_password:
                    st.error("All fields are required")
                elif new_password != confirm_password:
                    st.error("Passwords do not match")
                else:
                    # Register the new user
                    success, message = register_new_user(
                        new_username, 
                        new_name, 
                        new_password, 
                        new_email
                    )
                    
                    if success:
                        st.success(message)
                        st.info("Please go to the Login tab to login with your new account")
                    else:
                        st.error(message)
        
        # Information about benefits of registration
        st.markdown("### Why Register?")
        st.markdown("""
        - Save your preferences for water sources and regions
        - Subscribe to pollution alerts for specific areas
        - Access detailed water quality reports
        - Join our community of water quality advocates
        """)
    
    # Add footer
    st.markdown("---")
    st.markdown("<div style='text-align: center; color: #616161; padding: 20px;'><p>© 2025 South African Water Systems Monitor. All rights reserved.</p><p>For water emergencies, contact: <a href='mailto:support@sawatermonitor.co.za'>support@sawatermonitor.co.za</a> | +27 800 123 456</p></div>", unsafe_allow_html=True)

if __name__ == "__main__":
    app()