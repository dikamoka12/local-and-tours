import streamlit as st

def app():
    # Common header for all pages
    st.markdown("<h1 style='text-align: center; color: #1E88E5; background-color: #E3F2FD; padding: 20px; border-radius: 10px;'>SOUTH AFRICAN WATER SYSTEMS</h1>", unsafe_allow_html=True)
    st.markdown("<h2 style='text-align: center; font-size: 28px; color: #D81B60; background-color: #FCE4EC; padding: 15px; margin-top: 10px; border-radius: 10px;'>TOURISTS AND LOCALS</h2>", unsafe_allow_html=True)
    
    st.markdown("<h1 style='text-align: center; color: #1E88E5; padding: 20px;'>Educational Resources</h1>", unsafe_allow_html=True)
    
    # Create tabs for different educational resource categories
    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "Water Safety", 
        "Traditional Knowledge", 
        "Testing Methods",
        "Conservation",
        "Downloadable Resources"
    ])
    
    with tab1:
        st.header("Water Safety Guidelines")
        
        st.subheader("Understanding Water Quality Parameters")
        st.markdown("""
        Water quality is measured using several key parameters:
        
        * **pH Level**: Measures how acidic or basic the water is. Ideal range for drinking water is 6.5-8.5.
        * **Turbidity**: Measures clarity of water. High turbidity can indicate presence of pathogens.
        * **Dissolved Oxygen**: Essential for aquatic life. Low levels can indicate pollution.
        * **Nitrates and Phosphates**: High levels can cause algal blooms and harm aquatic ecosystems.
        * **Bacteria Levels**: Presence of E.coli or coliform bacteria indicates fecal contamination.
        """)
        
        st.subheader("Visual Assessment of Water Safety")
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("**Signs of Unsafe Water**")
            st.markdown("""
            * Unusual color (green, brown, red)
            * Strong chemical or rotten egg smell
            * Visible particles or sediment
            * Oil film or surface scum
            * Dead fish or lack of aquatic life
            * Excessive algae growth
            """)
        
        with col2:
            st.markdown("**Signs of Generally Safe Water**")
            st.markdown("""
            * Clear and colorless appearance
            * No noticeable smell
            * No floating debris or scum
            * Presence of diverse aquatic life
            * Natural flow and movement
            * No excessive plant growth
            """)
        
        st.warning("Note: Visual assessment is not a substitute for proper testing. When in doubt, assume water is unsafe for drinking until properly tested or treated.")
        
        st.subheader("Emergency Water Treatment Methods")
        st.markdown("""
        If you need to treat water in an emergency situation:
        
        1. **Boiling**: Boil water vigorously for at least 1 minute (3 minutes at higher elevations). This kills most pathogens.
        
        2. **Filtration**: Use water filters or natural filtration methods to remove particles and some pathogens.
        
        3. **Natural Purification**: Traditional methods using specific plant materials and natural minerals to improve water quality.
        
        4. **Solar Disinfection (SODIS)**: Fill clear plastic bottles with water and expose to direct sunlight for at least 6 hours (or 2 days if cloudy).
        """)
    
    with tab2:
        st.header("Traditional Water Knowledge")
        
        # Create tabs for more detailed traditional knowledge
        storage_tab, sharing_tab, usage_tab, finding_tab = st.tabs([
            "Storage Methods", 
            "Sharing Systems",
            "Usage Techniques", 
            "Water Finding"
        ])
        
        with storage_tab:
            st.subheader("Traditional Storage Methods")
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("#### Clay Vessel Systems")
                st.markdown("""
                **Izimbiza (Zulu)**
                * Large, wide-mouthed clay pots with specific designs
                * Natural cooling through evaporation from clay walls
                * Broad openings facilitate rainwater collection
                * Specific clay mixture often includes ground shells for strength
                * Decorative patterns indicate water source or intended use
                
                **Motshwana (Tswana)**
                * Smaller, narrow-necked containers with sealed lids
                * Reduced evaporation rate for longer storage
                * Often used for drinking water specifically
                * Geometric patterns encode water quality information
                * Hand-burnished interiors increase water resistance
                
                **Umbhumbulu (Xhosa)**
                * Medium-sized clay vessels with dual chambers
                * Inner chamber for clean drinking water
                * Outer chamber filled with wet sand for cooling
                * Often buried partially in ground for stability
                * Special lip design allows controlled pouring
                """)
                
                st.markdown("#### Natural Container Adaptations")
                st.markdown("""
                **Calabash Gourds**
                * Hollowed and dried gourds from Lagenaria plants
                * Interior treated with beeswax or smoke-cured for waterproofing
                * Natural shape creates pressure for controlled pouring
                * Different sizes used for different water purposes
                * Carrying straps attached with natural fibers
                
                **Wooden Vessels**
                * Carved from specific trees like Acacia or Marula
                * Natural antimicrobial properties from wood oils
                * Often used for medicinal water storage
                * Distinctive cooling properties vary by wood type
                * Long-lasting with proper maintenance (oil treatments)
                
                **Woven Containers**
                * Ultra-tight weaving creates water-resistant baskets
                * Natural fibers include reeds, grasses, and palm fronds
                * Interior sometimes lined with clay for full waterproofing
                * Flexible and lightweight for transport
                * Can expand as fibers absorb minimal water
                """)
            
            with col2:
                st.markdown("#### Underground Storage")
                st.markdown("""
                **Cool Chambers**
                * Underground rooms with specific soil composition
                * Natural insulation maintains consistent temperature
                * Often located near but not under living spaces
                * Interior walls treated with specific clay mixtures
                * Access typically via narrow entrance to reduce contamination
                
                **Sand Dams & Filters**
                * Community-built structures across seasonal streams
                * Water stored within sand and gravel beds
                * Natural filtration as water seeps through sand layers
                * Prevents evaporation while keeping water accessible
                * Protected from contamination by animals
                
                **Clay-lined Pits**
                * Strategic depressions sealed with specific clay types
                * Often created near natural water collection points
                * Sometimes covered with woven mats to reduce debris
                * Multiple pits used on rotation for cleanliness
                * Typically community-maintained and managed
                """)
                
                st.markdown("#### Preservation Techniques")
                st.markdown("""
                **Natural Additives**
                * Specific leaves added to water storage to prevent algae growth
                * Aloe sap used as a natural water purifier in some regions
                * Charcoal from certain woods used for filtration
                * Wild sage or specific root extracts for preservation
                * Mineral-rich soils sometimes added to improve taste
                
                **Location Strategies**
                * Storage vessels kept in breezy, shaded areas
                * Clay pots sometimes wrapped in damp cloths for cooling
                * Underground storage positioned based on soil analysis
                * Rainwater collection surfaces sloped to maximize capture
                * Water vessels elevated to protect from ground contaminants
                
                **Seasonal Adaptations**
                * Different storage methods for rainy vs. dry seasons
                * Temporary large-volume storage during monsoon periods
                * Insulated storage techniques during extreme heat
                * Protected storage during flooding seasons
                * Dust protection systems during windy periods
                """)
        
        with sharing_tab:
            st.subheader("Community Water Sharing Systems")
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("#### Management Structures")
                st.markdown("""
                **Water Committees**
                * Elder-led groups overseeing community water resources
                * Specific roles for quality monitoring, maintenance, distribution
                * Women often serving as primary decision-makers near villages
                * Specific rules for conflict resolution over water access
                * Members selected based on demonstrated knowledge and fairness
                
                **Rotational Access Systems**
                * Time-based scheduling frameworks
                * Priority access for vulnerable community members
                * Physical tokens sometimes used to indicate access rights
                * Natural markers (sun position, shadow lengths) used for timing
                * Special provisions during scarcity or drought
                
                **Contribution-Based Allocation**
                * Water access proportional to maintenance labor contributed
                * Community labor days for infrastructure upkeep
                * Special skills (well-digging, clay work) counted as contribution
                * Exemptions for elderly and ill community members
                * Documentation through oral history and community accountability
                """)
                
                st.markdown("#### Knowledge Networks")
                st.markdown("""
                **Water Finder Specialists**
                * Individuals trained in identifying underground water sources
                * Knowledge of geological indicators passed through generations
                * Reading subtle vegetation patterns to locate water
                * Understanding of insect and animal behavior near water sources
                * Soil testing techniques using texture, smell, and taste
                
                **Intergenerational Training**
                * Structured apprenticeship systems for water knowledge
                * Children assigned specific water-related responsibilities
                * Specialized songs and stories encoding water knowledge
                * Seasonal training intensified during critical water periods
                * Community ceremonies marking mastery of water management skills
                """)
            
            with col2:
                st.markdown("#### Distribution Methods")
                st.markdown("""
                **Drought Response Protocols**
                * Pre-established sharing systems activated during scarcity
                * Clear prioritization for drinking, cooking, and livestock needs
                * Emergency water sources opened only during critical periods
                * Communal rationing systems with transparent allocation
                * Mutual aid networks between neighboring communities
                
                **Surplus Exchange Networks**
                * Trading excess water access for other resources
                * Water-rich communities partnering with water-poor communities
                * Secondary water sources activated only during abundance
                * Cultural taboos against water hoarding during surplus
                * Ceremonial recognition of generous water sharing
                
                **Transport Cooperatives**
                * Shared labor systems for moving water from distant sources
                * Rotating schedules for water collection duties
                * Age and gender-appropriate carrying methods and equipment
                * Specialized carrying vessels optimized for distance and terrain
                * Collective responsibility for maintaining transport paths
                """)
                
                st.markdown("#### Conflict Resolution")
                st.markdown("""
                **Traditional Mediation**
                * Respected elders serving as water dispute mediators
                * Community-wide forums for addressing major conflicts
                * Historical precedents guiding current decisions
                * Restoration of harmony prioritized over punishment
                
                **Boundary Systems**
                * Clear demarcation of water source territories
                * Inter-community agreements on shared water resources
                * Natural features used as boundary markers
                * Seasonal adjustments to boundaries during scarcity/abundance
                * Mutual access corridors for essential water needs
                
                **Adaptive Governance**
                * Flexible systems responding to changing conditions
                * Emergency powers granted during severe drought
                * Temporary resource pooling during crises
                * Collaborative decision-making across community boundaries
                * Restoration of standard protocols after crisis resolution
                """)
        
        with usage_tab:
            st.subheader("Traditional Water Usage Techniques")
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("#### Household Efficiency")
                st.markdown("""
                **Graduated Use System**
                * Multi-stage utilization of the same water
                * First use: drinking and cooking (highest quality needed)
                * Second use: personal washing and laundry
                * Third use: cleaning tools and household items
                * Final use: watering plants or construction (clay mixing)
                
                **Morning Dew Collection**
                * Specialized cloths laid out overnight to capture dew
                * Plant leaves used as natural collection surfaces
                * Strategic positioning in open areas with night cooling
                * Early morning collection before sun evaporation
                * Particularly valuable in coastal and high-altitude areas
                
                **Condensation Capture**
                * Methods for collecting water vapor during cooking
                * Clay lids designed to capture and channel condensation
                * Cooling systems to accelerate condensation process
                * Underground cooling chambers creating natural condensation
                * Particularly important during drought periods
                """)
                
                st.markdown("#### Agricultural Techniques")
                st.markdown("""
                **Companion Planting Strategies**
                * Moisture-loving plants positioned to create shade
                * Deep-rooted plants paired with shallow-rooted varieties
                * Natural arrangements mimicking indigenous plant communities
                * Drought-resistant border plants protecting vulnerable crops
                * Specific plant combinations that share water efficiently
                
                **Deep Pot Irrigation**
                * Buried clay pots with controlled perforations
                * Direct water delivery to plant root systems
                * Dramatically reduced evaporation loss
                * Slow release providing consistent moisture
                * Self-regulating based on soil dryness
                
                **Mulching Traditions**
                * Stone mulching in arid regions to reduce evaporation
                * Organic materials positioned to maximize moisture retention
                * Living ground covers that minimize soil water loss
                * Seasonal adjustments to mulching materials
                * Integration with natural pest management systems
                """)
            
            with col2:
                st.markdown("#### Specialized Techniques")
                st.markdown("""
                **Natural Filtration**
                * Sand and charcoal layered filtering systems
                * Specific plant materials that clarify turbid water
                * Clay-pot filtering with controlled seepage
                * Seed-based water purification (Moringa seeds)
                * Sun exposure techniques for pathogen reduction
                
                **Salt Reduction Methods**
                * Traditional techniques for making brackish water usable
                * Clay filtering systems that reduce salt content
                * Boiling and condensation recovery systems
                * Plant-based absorption of excess minerals
                * Blending protocols with fresher water sources
                
                **Seasonal Adaptations**
                * Different usage protocols for wet and dry seasons
                * Water harvesting intensification before dry periods
                * Altered cooking techniques during water scarcity
                * Community bathing schedules during limited supply
                * Ritualized conservation practices during critical times
                """)
                
                st.markdown("#### Modern Adaptations")
                st.markdown("""
                **Urban Applications**
                * Traditional clay coolers redesigned for apartment living
                * Space-efficient rainwater harvesting based on traditional models
                * Community collection systems in urban housing developments
                * Modified graduated usage systems for modern households
                * Apartment-suitable condensation capture techniques
                
                **Scale-Up Innovations**
                * Traditional sand storage scaled for larger communities
                * Solar technologies integrated with clay vessel cooling
                * Enhanced traditional filters for contemporary contaminants
                * Digital monitoring added to traditional distribution systems
                * Community management structures adapted for modern governance
                
                **Hybrid Systems**
                * Traditional knowledge integrated with contemporary technology
                * Indigenous plant knowledge used in modern water treatment
                * Traditional storage aesthetics with improved materials
                * Ancient water-finding techniques supporting modern drilling
                * Cultural water management principles in contemporary policy
                """)
        
        with finding_tab:
            st.subheader("Traditional Water Finding Knowledge")
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("#### Plant Indicators")
                st.markdown("""
                **Diagnostic Species**
                * Specific plants that indicate shallow groundwater:
                  - Waterblommetjies (Aponogeton distachyos)
                  - Wild fig trees (Ficus species)
                  - Palmiet reeds (Prionium serratum)
                  - Fever trees (Vachellia xanthophloea)
                  - Wild date palms (Phoenix reclinata)
                
                **Plant Conditions**
                * Deeper green foliage in otherwise dry areas
                * Unusual plant size compared to surrounding vegetation
                * Plants remaining green during drought conditions
                * Specific growth patterns indicating water flow
                * Root structure adaptations visible at soil surface
                
                **Seasonal Indicators**
                * Plants that flower only with underground water presence
                * Early leaf drop patterns indicating water stress
                * Specific fruiting behaviors near reliable water
                * Growth timing differences from surrounding vegetation
                * Root exposure behaviors in water-seeking plants
                """)
                
                st.markdown("#### Animal Behavior Reading")
                st.markdown("""
                **Wildlife Observation**
                * Animal pathways leading to hidden water sources
                * Burrowing animal activity near underground water
                * Bird behavior patterns indicating water presence
                * Insect concentrations, especially bees requiring water
                * Nocturnal animal gathering spots for drinking
                
                **Livestock Indicators**
                * Domestic animal behavior changes near water sources
                * Cattle and goat preferences for grazing in certain areas
                * Animal-created paths leading to seasonal water sources
                * Distinctive digging behaviors in water-sensing animals
                * Traditional tracking of wildlife to discover water
                
                **Insect Monitoring**
                * Termite mound positioning relative to groundwater
                * Specific ant species that nest near reliable water
                * Dragonfly presence indicating persistent water
                * Mosquito breeding patterns showing stagnant water locations
                * Dung beetle activity correlating with soil moisture levels
                """)
            
            with col2:
                st.markdown("#### Physical Environment Reading")
                st.markdown("""
                **Geological Indicators**
                * Rock formations associated with springs and seeps
                * Soil color changes indicating water table depth
                * Natural depressions where water accumulates
                * Limestone features often associated with water sources
                * Distinctive vegetation patterns along fault lines
                
                **Soil Analysis**
                * Traditional testing of soil moisture at varying depths
                * Soil smell assessment for water proximity
                * Visual inspection for subtle color gradations
                * Texture variations indicating historical water flow
                * Temperature differential testing in early morning
                
                **Weather Pattern Knowledge**
                * Understanding regional rainfall patterns and timing
                * Knowledge of how landforms affect water collection
                * Recognition of dew-forming conditions and locations
                * Prediction of seasonal springs and their reliability
                * Interpretation of cloud formations for localized rain
                """)
                
                st.markdown("#### Testing Methods")
                st.markdown("""
                **Water Quality Assessment**
                * Taste testing protocols for mineral content
                * Visual clarity examination techniques
                * Temperature assessment for spring vs. surface water
                * Sound testing (water movement below ground)
                * Monitoring water effects on cooking (mineral content)
                
                **Digging Techniques**
                * Strategic test hole placement based on indicators
                * Knowledge of proper depth for different landscapes
                * Traditional tools optimized for water discovery
                * Soil extraction and examination methods
                * Safety practices around newly discovered water
                
                **Verification Systems**
                * Multiple indicator confirmation requirements
                * Seasonal testing to verify year-round reliability
                * Community validation of new water sources
                * Knowledge sharing protocols for newly found sources
                """)
        
        st.subheader("Indigenous Water Management Practices")
        st.markdown("""
        South Africa's indigenous communities have developed water management practices over generations:
        
        **Zulu Water Conservation**
        * Traditional rain harvesting methods using clay pots (izimbiza)
        * Sacred water sites (amanzi angcwele) protection practices
        * Seasonal water usage patterns aligned with rainfall cycles
        
        **Xhosa Water Purification Techniques**
        * Use of specific sand and stone filtration methods
        * Identification of water-purifying plants like "ichibi" reeds
        * Community-based spring protection systems
        
        **Khoi-San Desert Water Finding**
        * Reading landscape features to locate underground water
        * Extracting water from specific plants in dry conditions
        * Dew collection techniques using natural materials
        """)
        
        st.subheader("Cultural Significance of Water")
        st.markdown("""
        Water plays a central role in many South African traditions:
        
        * **Cleansing Ceremonies**: Many cultural rituals involve water for spiritual purification
        * **Ancestor Communication**: Specific water sources are often associated with ancestor communication
        * **Initiation Rites**: Water from natural springs is used in various coming-of-age ceremonies
        * **Healing Practices**: Traditional healers (sangomas) use water from specific sources for medicinal purposes
        * **Rain Ceremonies**: Cultural practices to call for rain during drought conditions
        """)
        
        st.subheader("Identifying Safe Natural Water Sources")
        st.markdown("""
        Traditional methods for identifying potable water sources include:
        
        * Presence of specific plants like waterblommetjies or palmiet reeds
        * Observing which water sources are used by wildlife
        * Testing for sweetness, clarity, and temperature
        * Assessing surrounding vegetation for signs of contamination
        * Looking for natural filtration systems like specific rock formations
        """)
        
        st.info("The integration of traditional knowledge with modern water management practices can create more sustainable and culturally appropriate solutions.")
    
    with tab3:
        st.header("Water Testing Methods")
        
        st.subheader("Home Testing Options")
        st.markdown("""
        Several methods are available for testing water quality at home:
        
        **Test Strips**
        * Affordable and easy to use
        * Can test for pH, chlorine, hardness, nitrates, and more
        * Results available in minutes
        * Limited accuracy compared to laboratory testing
        
        **Digital Testers**
        * Handheld devices that measure specific parameters
        * More accurate than test strips
        * Typically measure pH, TDS (Total Dissolved Solids), and temperature
        * Require occasional calibration
        
        **Testing Kits**
        * More comprehensive than strips
        * Can test for bacteria, heavy metals, pesticides
        * Follow instructions carefully for accurate results
        * Store in cool, dry place for longevity
        """)
        
        st.subheader("When to Seek Professional Testing")
        st.markdown("""
        Consider professional laboratory testing in these situations:
        
        * Water has unusual taste, odor, or appearance
        * Family members experiencing gastrointestinal illness
        * Living near industrial areas, farms, or mining operations
        * After flooding or severe weather events
        * When using a private well (test annually)
        * Before using natural springs for drinking water
        * If home tests show concerning results
        
        South African laboratories such as WaterLab and ALS offer comprehensive water testing services.
        """)
        
        st.subheader("Understanding Test Results")
        st.markdown("""
        Key parameters in water quality tests:
        
        * **Microbiological testing**: Checks for harmful bacteria like E. coli
        * **Chemical testing**: Measures levels of chemicals like nitrates, fluoride, and chlorine
        * **Physical testing**: Evaluates characteristics like pH, turbidity, and color
        * **Metal testing**: Detects presence of metals like lead, copper, and arsenic
        * **Organic compounds**: Tests for pesticides and industrial chemicals
        
        Compare results with national standards (SANS 241) to determine if water meets safety guidelines.
        """)
    
    with tab4:
        st.header("Water Conservation Practices")
        
        st.subheader("Household Water Conservation")
        st.markdown("""
        Practical ways to reduce water consumption at home:
        
        **In the Kitchen**
        * Fix leaking taps (a dripping tap can waste up to 15 liters per day)
        * Keep a bottle of drinking water in the refrigerator instead of running the tap until it's cold
        * Use a basin for washing vegetables instead of under running water
        
        **In the Bathroom**
        * Take shorter showers (a 5-minute shower uses 40-100 liters)
        * Install low-flow showerheads and toilet cisterns
        * Turn off taps while brushing teeth or shaving
        * Check for and repair toilet leaks
        
        **In the Garden**
        * Water during early morning or evening to reduce evaporation
        * Use mulch around plants to retain moisture
        * Install a rainwater harvesting system
        * Choose indigenous, water-wise plants
        """)
        
        st.subheader("Community Water Protection")
        st.markdown("""
        Actions communities can take to protect water resources:
        
        * Organize community clean-ups of local water bodies
        * Monitor and report pollution incidents to authorities
        * Create awareness about proper waste disposal to prevent water contamination
        * Participate in "adopt a river" programs
        * Support local water conservation initiatives
        * Form community water committees to address local water issues
        * Engage with local government on water service delivery
        """)
        
        st.subheader("Water Reuse Systems")
        st.markdown("""
        Systems for reusing household water:
        
        **Greywater Systems**
        * Redirect water from showers, baths, and washing machines
        * Use for garden irrigation or toilet flushing
        * Install simple diverter valves or comprehensive treatment systems
        * Consider using biodegradable soaps and detergents
        
        **Rainwater Harvesting**
        * Install rain barrels or tanks to collect roof runoff
        * Use for irrigation, car washing, or toilet flushing
        * First-flush diverters improve water quality
        * Consider filtration for certain uses
        
        **Condensate Recovery**
        * Collect water from air conditioners or dehumidifiers
        * Good for watering plants as it's essentially distilled water
        * Typical AC units can produce 5-20 liters per day
        """)
    
    with tab5:
        st.header("Downloadable Resources")
        
        st.subheader("Educational Materials")
        
        # These would be actual downloadable PDFs in a real implementation
        col1, col2 = st.columns(2)
        
        with col1:
            with st.expander("Water Quality Field Guide"):
                st.markdown("""
                **Water Quality Field Guide (PDF)**
                
                A comprehensive guide for identifying water quality issues in the field, including:
                - Visual assessment techniques
                - Simple test procedures
                - Common pollutants and their indicators
                - When to alert authorities
                - Emergency contacts
                
                *This guide is designed to be printed and carried during fieldwork or outdoor activities.*
                """)
                st.download_button(
                    label="Download Field Guide",
                    data="This would be a real PDF in actual implementation",
                    file_name="water_quality_field_guide.pdf",
                    mime="application/pdf"
                )
            
            with st.expander("Traditional Water Wisdom Handbook"):
                st.markdown("""
                **Traditional Water Wisdom Handbook (PDF)**
                
                Documentation of indigenous knowledge about water sources, including:
                - Traditional water finding methods
                - Natural water purification techniques
                - Cultural water practices and their significance
                - Seasonal water patterns
                - Traditional conservation methods
                
                *Created in consultation with indigenous knowledge holders across South Africa.*
                """)
                st.download_button(
                    label="Download Handbook",
                    data="This would be a real PDF in actual implementation",
                    file_name="traditional_water_wisdom.pdf",
                    mime="application/pdf"
                )
        
        with col2:
            with st.expander("Water Conservation Checklist"):
                st.markdown("""
                **Household Water Conservation Checklist (PDF)**
                
                A practical checklist to assess and improve water usage, including:
                - Room-by-room assessment guide
                - Water-saving techniques 
                - Calculation of potential water savings
                - DIY water-saving projects
                - Water-efficient appliance guide
                
                *Designed to help households reduce water consumption by up to 30%.*
                """)
                st.download_button(
                    label="Download Checklist",
                    data="This would be a real PDF in actual implementation",
                    file_name="water_conservation_checklist.pdf",
                    mime="application/pdf"
                )
            
            with st.expander("Emergency Water Treatment Guide"):
                st.markdown("""
                **Emergency Water Treatment Guide (PDF)**
                
                Comprehensive instructions for water treatment in emergencies:
                - Step-by-step purification methods
                - Materials needed for each method
                - Effectiveness against different contaminants
                - Shelf-stable treatment options
                - Storage guidelines for treated water
                
                *Keep printed copies with emergency supplies and in vehicles.*
                """)
                st.download_button(
                    label="Download Emergency Guide",
                    data="This would be a real PDF in actual implementation",
                    file_name="emergency_water_treatment.pdf",
                    mime="application/pdf"
                )
        
        st.subheader("Offline Mobile Resources")
        st.markdown("""
        The following resources are designed to work offline on mobile devices:
        
        **Water Systems Map App**
        * Download map data for offline navigation to water sources
        * Works without internet connection once downloaded
        * Includes information on water quality at each location
        * Available for Android and iOS
        
        **Water Testing Guides**
        * Instructional videos that can be downloaded for offline viewing
        * Step-by-step procedures for common water tests
        * Interpretation guides for test results
        * Available in multiple South African languages
        
        **Educational Audio Content**
        * Downloadable podcasts about water conservation and safety
        * Oral history recordings about traditional water knowledge
        * Audio guides for identifying water quality issues
        * Low data usage format suitable for all devices
        """)
        
        st.markdown("---")
        st.info("All resources can be downloaded once and used without requiring internet access. This makes them accessible in rural areas with limited connectivity.")
    
    # Add footer
    st.markdown("---")
    st.markdown("<div style='text-align: center; color: #616161; padding: 20px;'><p>© 2025 South African Water Systems Monitor. All rights reserved.</p><p>For water emergencies, contact: <a href='mailto:support@sawatermonitor.co.za'>support@sawatermonitor.co.za</a> | +27 800 123 456</p></div>", unsafe_allow_html=True)

if __name__ == "__main__":
    app()