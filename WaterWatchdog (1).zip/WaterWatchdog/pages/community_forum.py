import streamlit as st
import pandas as pd
import datetime
import os
import json

# File to store forum posts
FORUM_DATA_FILE = "forum_data.json"

def app():
    # Common header for all pages
    st.markdown("<h1 style='text-align: center; color: #1E88E5; background-color: #E3F2FD; padding: 20px; border-radius: 10px;'>SOUTH AFRICAN WATER SYSTEMS</h1>", unsafe_allow_html=True)
    st.markdown("<h2 style='text-align: center; font-size: 28px; color: #D81B60; background-color: #FCE4EC; padding: 15px; margin-top: 10px; border-radius: 10px;'>TOURISTS AND LOCALS</h2>", unsafe_allow_html=True)
    
    st.markdown("<h1 style='text-align: center; color: #1E88E5; padding: 20px;'>Community Forum</h1>", unsafe_allow_html=True)
    
    # Check if data file exists, create it if not
    if not os.path.exists(FORUM_DATA_FILE):
        initial_data = {
            "posts": [
                {
                    "id": 1,
                    "title": "Welcome to the Water Quality Community Forum",
                    "author": "Admin",
                    "content": "This is a space for community members to share observations and concerns about water quality in their areas. Please share your experiences and ask questions!",
                    "date": "2025-04-20",
                    "category": "Announcement",
                    "comments": [
                        {
                            "author": "WaterExpert",
                            "content": "Great to see this forum! Looking forward to the discussions.",
                            "date": "2025-04-21"
                        }
                    ]
                },
                {
                    "id": 2,
                    "title": "Unusual water color in Cape Town's Muizenberg Beach",
                    "author": "CapeTownResident",
                    "content": "Has anyone else noticed the strange greenish color of the water at Muizenberg lately? It seems to have started about a week ago and I'm concerned about safety for swimming.",
                    "date": "2025-04-22",
                    "category": "Observation",
                    "comments": [
                        {
                            "author": "MarineScientist",
                            "content": "This could be an algal bloom. It's best to avoid swimming until local authorities test the water. I'll check with the coastal management team.",
                            "date": "2025-04-22"
                        },
                        {
                            "author": "LocalSurfer",
                            "content": "I noticed this too! It seems to be spreading to St James as well.",
                            "date": "2025-04-23"
                        }
                    ]
                }
            ]
        }
        with open(FORUM_DATA_FILE, 'w') as f:
            json.dump(initial_data, f, indent=4)
    
    # Load forum data
    try:
        with open(FORUM_DATA_FILE, 'r') as f:
            forum_data = json.load(f)
    except:
        forum_data = {"posts": []}
    
    # Create tabs for viewing and creating posts
    tab1, tab2, tab3 = st.tabs(["Browse Posts", "Create Post", "My Posts"])
    
    with tab1:
        # Forum categories for filtering
        categories = ["All Categories", "Question", "Observation", "Alert", "Discussion", "Announcement"]
        selected_category = st.selectbox("Filter by Category", categories)
        
        # Search box
        search_query = st.text_input("Search Posts", "")
        
        # Display posts
        st.subheader("Recent Posts")
        
        filtered_posts = forum_data["posts"]
        
        # Filter by category if specified
        if selected_category != "All Categories":
            filtered_posts = [post for post in filtered_posts if post.get("category") == selected_category]
        
        # Filter by search query if provided
        if search_query:
            search_lower = search_query.lower()
            filtered_posts = [
                post for post in filtered_posts 
                if search_lower in post.get("title", "").lower() or search_lower in post.get("content", "").lower()
            ]
        
        # Sort posts by date (newest first)
        filtered_posts = sorted(filtered_posts, key=lambda x: x.get("date", ""), reverse=True)
        
        if not filtered_posts:
            st.info("No posts found. Be the first to create a post!")
        
        for post in filtered_posts:
            with st.expander(f"{post.get('title')} - {post.get('author')} ({post.get('date')})"):
                st.markdown(f"**Category:** {post.get('category')}")
                st.markdown(post.get('content'))
                
                # Display comments
                if "comments" in post and post["comments"]:
                    st.markdown("---")
                    st.markdown("**Comments:**")
                    for comment in post["comments"]:
                        st.markdown(f"**{comment.get('author')}** ({comment.get('date')}): {comment.get('content')}")
                
                # Add comment form
                with st.form(f"comment_form_{post.get('id')}"):
                    comment_author = st.text_input("Your Name", key=f"author_{post.get('id')}")
                    comment_content = st.text_area("Comment", key=f"content_{post.get('id')}")
                    submit_comment = st.form_submit_button("Post Comment")
                    
                    if submit_comment:
                        if not comment_author or not comment_content:
                            st.error("Please provide your name and a comment")
                        else:
                            # Find the post and add comment
                            for p in forum_data["posts"]:
                                if p.get("id") == post.get("id"):
                                    if "comments" not in p:
                                        p["comments"] = []
                                    
                                    p["comments"].append({
                                        "author": comment_author,
                                        "content": comment_content,
                                        "date": datetime.datetime.now().strftime("%Y-%m-%d")
                                    })
                                    
                                    # Save updated data
                                    with open(FORUM_DATA_FILE, 'w') as f:
                                        json.dump(forum_data, f, indent=4)
                                    
                                    st.success("Comment added successfully!")
                                    st.experimental_rerun()
    
    with tab2:
        # Create new post form
        st.subheader("Create a New Post")
        
        with st.form("new_post_form"):
            post_title = st.text_input("Title")
            post_author = st.text_input("Your Name")
            post_category = st.selectbox("Category", ["Question", "Observation", "Alert", "Discussion", "Announcement"])
            post_content = st.text_area("Content", height=200)
            
            submit_post = st.form_submit_button("Post")
            
            if submit_post:
                if not post_title or not post_author or not post_content:
                    st.error("Please fill in all fields")
                else:
                    # Create new post
                    new_post_id = len(forum_data["posts"]) + 1
                    
                    new_post = {
                        "id": new_post_id,
                        "title": post_title,
                        "author": post_author,
                        "content": post_content,
                        "date": datetime.datetime.now().strftime("%Y-%m-%d"),
                        "category": post_category,
                        "comments": []
                    }
                    
                    forum_data["posts"].append(new_post)
                    
                    # Save updated data
                    with open(FORUM_DATA_FILE, 'w') as f:
                        json.dump(forum_data, f, indent=4)
                    
                    st.success("Post created successfully!")
                    st.experimental_rerun()
    
    with tab3:
        # My posts section (future enhancement: tie to user authentication)
        st.subheader("My Posts")
        author_name = st.text_input("Enter your name to see your posts")
        
        if author_name:
            user_posts = [post for post in forum_data["posts"] if post.get("author") == author_name]
            
            if not user_posts:
                st.info(f"No posts found for {author_name}")
            
            for post in user_posts:
                with st.expander(f"{post.get('title')} ({post.get('date')})"):
                    st.markdown(f"**Category:** {post.get('category')}")
                    st.markdown(post.get('content'))
                    
                    # Display comments
                    if "comments" in post and post["comments"]:
                        st.markdown("---")
                        st.markdown("**Comments:**")
                        for comment in post["comments"]:
                            st.markdown(f"**{comment.get('author')}** ({comment.get('date')}): {comment.get('content')}")
    
    # Community guidelines
    st.markdown("---")
    with st.expander("Community Guidelines"):
        st.markdown("""
        ## Forum Guidelines
        
        1. **Be respectful:** Treat others with respect and kindness.
        2. **Stay on topic:** Keep discussions related to water quality and environmental issues.
        3. **Provide evidence:** When making claims about water quality, try to provide evidence or specific observations.
        4. **No spam:** Don't post promotional content or repeat the same message multiple times.
        5. **Protect privacy:** Don't share personal contact information publicly.
        6. **Report accurately:** When reporting water quality issues, be as specific as possible about location and time.
        7. **Follow up:** If you report an issue that gets resolved, please update the community.
        
        Thank you for helping build a supportive community focused on water quality!
        """)
    
    # Add footer
    st.markdown("---")
    st.markdown("<div style='text-align: center; color: #616161; padding: 20px;'><p>© 2025 South African Water Systems Monitor. All rights reserved.</p><p>For water emergencies, contact: <a href='mailto:support@sawatermonitor.co.za'>support@sawatermonitor.co.za</a> | +27 800 123 456</p></div>", unsafe_allow_html=True)

if __name__ == "__main__":
    app()