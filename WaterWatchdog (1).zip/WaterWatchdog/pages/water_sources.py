import streamlit as st
import pandas as pd
import plotly.express as px
from utils.data_processor import load_water_sources_data, filter_data_by_region, filter_data_by_water_type
from utils.visualization import create_map_visualization, create_pollution_chart, create_water_distribution_chart, create_pollution_trend_chart

def app():
    st.title("Water Sources Explorer")
    st.write("Explore detailed information about water sources around the world.")
    
    # Load data
    water_sources_df = load_water_sources_data()
    
    # Check if data is available
    if len(water_sources_df) == 0:
        st.warning("No water source data is currently available. Please check back later or contact support if this issue persists.")
        return
    
    # Sidebar filters
    st.sidebar.title("Filters")
    
    # Water type filter
    water_types = ["All", "Rivers", "Dams", "Oceans", "Tap Water", "Underground Water", "Spring Water", "Others"]
    selected_water_type = st.sidebar.selectbox("Water Type", water_types)
    
    # Region filter
    regions = ["All", "North America", "South America", "Europe", "Africa", "Asia", "Oceania"]
    selected_region = st.sidebar.selectbox("Region", regions)
    
    # Pollution level filter
    min_pollution, max_pollution = st.sidebar.slider(
        "Pollution Level Range", 
        min_value=0, 
        max_value=10, 
        value=(0, 10),
        step=1
    )
    
    # Search box
    search_query = st.sidebar.text_input("Search by name or country")
    
    # Apply filters
    filtered_df = water_sources_df.copy()
    
    if selected_water_type != "All":
        filtered_df = filtered_df[filtered_df["type"] == selected_water_type.lower()]
    
    if selected_region != "All":
        filtered_df = filtered_df[filtered_df["region"] == selected_region]
    
    filtered_df = filtered_df[
        (filtered_df["pollution_level"] >= min_pollution) & 
        (filtered_df["pollution_level"] <= max_pollution)
    ]
    
    if search_query:
        query_lower = search_query.lower()
        filtered_df = filtered_df[
            filtered_df["name"].str.lower().str.contains(query_lower) | 
            filtered_df["country"].str.lower().str.contains(query_lower)
        ]
    
    # Display filter summary
    st.write(f"Showing {len(filtered_df)} water sources")
    
    # Main content
    col1, col2 = st.columns([3, 1])
    
    with col1:
        # Map visualization
        st.subheader("Global Water Sources Map")
        map_layer = create_map_visualization(filtered_df)
        st.pydeck_chart(map_layer)
    
    with col2:
        # Statistics
        st.subheader("Statistics")
        st.metric("Total Water Sources", len(filtered_df))
        
        if len(filtered_df) > 0:
            avg_pollution = filtered_df["pollution_level"].mean()
            st.metric("Average Pollution Level", f"{avg_pollution:.1f}/10")
            
            high_pollution = len(filtered_df[filtered_df["pollution_level"] >= 7])
            st.metric("High Pollution Sources", high_pollution)
        
        # Water types distribution
        st.subheader("Water Types")
        if len(filtered_df) > 0:
            type_chart = create_water_distribution_chart(filtered_df)
            st.plotly_chart(type_chart, use_container_width=True)
    
    # Pollution levels by water type
    st.subheader("Pollution Levels by Water Type")
    if len(filtered_df) > 0:
        pollution_chart = create_pollution_chart(filtered_df)
        st.plotly_chart(pollution_chart, use_container_width=True)
    else:
        st.info("No data available for the selected filters.")
    
    # Detailed water sources table
    st.subheader("Water Sources Data")
    if len(filtered_df) > 0:
        display_df = filtered_df[["name", "type", "country", "region", "pollution_level", "last_updated"]]
        display_df.columns = ["Name", "Type", "Country", "Region", "Pollution Level", "Last Updated"]
        st.dataframe(display_df, use_container_width=True)
    else:
        st.info("No data available for the selected filters.")
    
    # Water source details
    st.subheader("Water Source Details")
    if len(filtered_df) > 0:
        selected_source = st.selectbox("Select a water source for detailed information", filtered_df["name"].tolist())
        
        if selected_source:
            source_data = filtered_df[filtered_df["name"] == selected_source].iloc[0]
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown(f"**Name:** {source_data['name']}")
                st.markdown(f"**Type:** {source_data['type'].capitalize()}")
                st.markdown(f"**Country:** {source_data['country']}")
                st.markdown(f"**Region:** {source_data['region']}")
            
            with col2:
                st.markdown(f"**Pollution Level:** {source_data['pollution_level']}/10")
                st.markdown(f"**pH Level:** {source_data['ph_level']}")
                st.markdown(f"**Size/Length:** {source_data['size']}")
                st.markdown(f"**Last Updated:** {source_data['last_updated']}")
            
            # Show pollution trend if available
            if "pollution_history" in source_data and len(source_data["pollution_history"]) > 0:
                st.subheader("Pollution Trend")
                history_chart = create_pollution_trend_chart(source_data["pollution_history"])
                st.plotly_chart(history_chart, use_container_width=True)
    else:
        st.info("No data available for the selected filters.")

if __name__ == "__main__":
    app()
