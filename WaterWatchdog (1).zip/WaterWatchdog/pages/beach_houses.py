import streamlit as st
import pandas as pd
import plotly.express as px

def app():
    st.title("Luxury Beach Houses & Marine Chemical Flows")
    
    # Create tabs for different views
    tab1, tab2, tab3, tab4 = st.tabs(["Global Beach Houses", "South African Beach Houses", "Location-Specific Pollutants", "Chemical & Health Impacts"])
    
    with tab1:
        st.header("World-Class Beach Houses")
        
        # Create expandable sections for different categories
        with st.expander("Luxury Properties", expanded=True):
            st.markdown("""
            * **Villa North Island (Seychelles)**
            * **The Beach House (Maldives)**
            * **Camelia Estate (Corfu, Greece)**
            * **Villa Keisa (Algarve, Portugal)**
            * **Malibu Estates (USA)**
            """)
            
        with st.expander("Architectural Standouts"):
            st.markdown("""
            * **Casa Atrevida (Costa Rica)**
            * **Bunker House (Sardinia, Italy)**
            * **Dune House (Fire Island, USA)**
            * **Castle Rock Beach House (New Zealand)**
            * **Tadao Ando villa (Malibu, USA)**
            """)
            
        with st.expander("Romantic Retreats"):
            st.markdown("""
            * **Oke Beach House (Bay of Islands, New Zealand)**
            * **The Kassiopia Estate (Corfu, Greece)**
            * **Urban Spa Residence (Malibu, USA)**
            * **Casa Ikal (Mexico)**
            """)
    
    with tab2:
        st.header("South Africa's Beach Houses")
        
        # Create expandable sections for different categories
        with st.expander("Luxury Properties", expanded=True):
            st.markdown("""
            * **Villa Misty Cliffs (Cape Town)**
            * **The Beach House (Salt Rock, KwaZulu-Natal)**
            * **Pearl Bay Beach Villa (Yzerfontein)**
            * **Cape Beach Villa (Noordhoek)**
            """)
            
        with st.expander("Charming Retreats"):
            st.markdown("""
            * **The Beach Hut (Paternoster)**
            * **Schrywershoek Beach House (West Coast National Park)**
            * **Thonga Beach Lodge (Maputaland)**
            * **Bekkie Holiday Home (Paternoster)**
            """)
            
        with st.expander("Contemporary Design"):
            st.markdown("""
            * **Modern Luxury Beach House (Ballito)**
            * **Coastal Haven (Scarborough)**
            """)
            
        # South African beach locations
        st.subheader("Beach House Regions")
        st.markdown("""
        * **Western Cape:** Cape Town (Camps Bay, Clifton, Llandudno), Hermanus, Plettenberg Bay
        * **Eastern Cape:** St. Francis Bay, Kenton-on-Sea, Port Alfred
        * **KwaZulu-Natal:** Umhlanga, Ballito, Salt Rock, Southbroom
        * **West Coast:** Paternoster, Langebaan, Yzerfontein
        """)
    
    with tab3:
        st.markdown("<h1 style='font-size:36px; color:#1E88E5;'>LOCATION-SPECIFIC POLLUTANTS</h1>", unsafe_allow_html=True)
        
        st.markdown("""
        <div style='font-size:18px; margin-bottom:20px;'>
        This section identifies potential water and air pollutants that may be present near specific beach house locations.
        Understanding these environmental concerns is crucial for property owners, visitors, and local communities.
        </div>
        """, unsafe_allow_html=True)
        
        # Create expandable sections for different regions
        with st.expander("ISLAND DESTINATIONS (Seychelles, Maldives)", expanded=True):
            st.markdown("""
            <div style='font-size:18px;'>
            <h3>Villa North Island (Seychelles)</h3>
            <p><strong>Water Pollutants:</strong></p>
            <ul>
                <li>Microplastics from ocean currents and tourism waste</li>
                <li>Sunscreen chemicals (oxybenzone, octinoxate) from tourism</li>
                <li>Petroleum hydrocarbons from boat traffic and shipping lanes</li>
                <li>Heavy metals (copper, zinc) from antifouling boat paints</li>
            </ul>
            <p><strong>Air Pollutants:</strong></p>
            <ul>
                <li>Salt spray (natural aerosol)</li>
                <li>Diesel emissions from power generators and marine vessels</li>
                <li>Limited industrial pollutants due to remote location</li>
            </ul>
            
            <h3>The Beach House (Maldives)</h3>
            <p><strong>Water Pollutants:</strong></p>
            <ul>
                <li>Sewage-related compounds from island infrastructure</li>
                <li>Microplastics from ocean currents (Indian Ocean garbage patches)</li>
                <li>Desalination plant discharge (brine with elevated salt concentration)</li>
                <li>Sunscreen chemicals (oxybenzone) threatening coral reefs</li>
            </ul>
            <p><strong>Air Pollutants:</strong></p>
            <ul>
                <li>Marine aerosols (sea salt)</li>
                <li>Emissions from tourist transport (seaplanes, boats)</li>
                <li>Diesel generator emissions (resorts and local power generation)</li>
            </ul>
            </div>
            """, unsafe_allow_html=True)
            
        with st.expander("MEDITERRANEAN LOCATIONS (Greece, Italy, Portugal)"):
            st.markdown("""
            <div style='font-size:18px;'>
            <h3>Camelia Estate (Corfu, Greece)</h3>
            <p><strong>Water Pollutants:</strong></p>
            <ul>
                <li>Agricultural runoff (pesticides, fertilizers) from nearby farms</li>
                <li>Untreated or partially treated sewage from coastal communities</li>
                <li>Microplastics and marine debris</li>
                <li>Heavy metals in sediments from historical industrial activities</li>
            </ul>
            <p><strong>Air Pollutants:</strong></p>
            <ul>
                <li>Particulate matter from seasonal wildfires</li>
                <li>Vehicle emissions during tourist season</li>
                <li>Shipping emissions (Mediterranean shipping routes)</li>
                <li>Ozone during summer months</li>
            </ul>
            
            <h3>The Kassiopia Estate (Corfu, Greece)</h3>
            <p><strong>Water Pollutants:</strong></p>
            <ul>
                <li>Similar to Camelia Estate with additional marina-related pollutants</li>
                <li>Antifouling paint compounds (copper, tributyltin (TBT))</li>
                <li>Petroleum hydrocarbons from recreational boating</li>
            </ul>
            <p><strong>Air Pollutants:</strong></p>
            <ul>
                <li>Similar to Camelia Estate</li>
                <li>Additional hydrocarbon emissions from marina operations</li>
            </ul>
            
            <h3>Villa Keisa (Algarve, Portugal)</h3>
            <p><strong>Water Pollutants:</strong></p>
            <ul>
                <li>Golf course runoff (fertilizers, pesticides, herbicides)</li>
                <li>Microplastics from tourism activities</li>
                <li>Sewage discharge during peak tourism periods</li>
                <li>Agricultural chemicals from inland farming</li>
            </ul>
            <p><strong>Air Pollutants:</strong></p>
            <ul>
                <li>Vehicle emissions from tourism traffic</li>
                <li>Maritime emissions from shipping and fishing vessels</li>
                <li>Ozone during summer months</li>
                <li>Seasonal wildfire smoke</li>
            </ul>
            
            <h3>Bunker House (Sardinia, Italy)</h3>
            <p><strong>Water Pollutants:</strong></p>
            <ul>
                <li>Industrial discharge from mainland Italy carried by currents</li>
                <li>Military/naval activity pollutants (historical)</li>
                <li>Tourism waste (microplastics, sunscreen chemicals)</li>
                <li>Agricultural runoff from inland farming</li>
            </ul>
            <p><strong>Air Pollutants:</strong></p>
            <ul>
                <li>Particulate matter from Saharan dust events</li>
                <li>Shipping emissions (Mediterranean shipping routes)</li>
                <li>Vehicle emissions during tourist season</li>
                <li>Industrial emissions from mainland Italy carried by prevailing winds</li>
            </ul>
            </div>
            """, unsafe_allow_html=True)
            
        with st.expander("NORTH AMERICAN COASTLINES (USA)"):
            st.markdown("""
            <div style='font-size:18px;'>
            <h3>Malibu Estates (USA)</h3>
            <p><strong>Water Pollutants:</strong></p>
            <ul>
                <li>Urban runoff from Los Angeles area (metals, oils, debris)</li>
                <li>Stormwater pollution (first flush phenomenon)</li>
                <li>Legacy DDT contamination in seafloor sediments</li>
                <li>Sewage spills during heavy rainfall events</li>
                <li>PFAS (per- and polyfluoroalkyl substances) from firefighting foams</li>
            </ul>
            <p><strong>Air Pollutants:</strong></p>
            <ul>
                <li>Photochemical smog (ozone, NOx) from Los Angeles Basin</li>
                <li>PM2.5 and PM10 from urban sources and wildfires</li>
                <li>Vehicle emissions from Pacific Coast Highway</li>
                <li>Wildfire smoke during fire season</li>
                <li>VOCs from multiple urban sources</li>
            </ul>
            
            <h3>Tadao Ando villa (Malibu, USA)</h3>
            <p><strong>Water Pollutants:</strong></p>
            <ul>
                <li>Similar to Malibu Estates</li>
                <li>Additional concern for cliff/slope erosion contributing sediments</li>
            </ul>
            <p><strong>Air Pollutants:</strong></p>
            <ul>
                <li>Similar to Malibu Estates</li>
            </ul>
            
            <h3>Urban Spa Residence (Malibu, USA)</h3>
            <p><strong>Water Pollutants:</strong></p>
            <ul>
                <li>Similar to Malibu Estates</li>
                <li>Potentially elevated levels of personal care product chemicals</li>
            </ul>
            <p><strong>Air Pollutants:</strong></p>
            <ul>
                <li>Similar to Malibu Estates</li>
            </ul>
            
            <h3>Dune House (Fire Island, USA)</h3>
            <p><strong>Water Pollutants:</strong></p>
            <ul>
                <li>Long Island Sound industrial contaminants</li>
                <li>Nitrogen loading from septic systems</li>
                <li>Microplastics from New York metropolitan area</li>
                <li>Historical PCBs and industrial contaminants in sediments</li>
            </ul>
            <p><strong>Air Pollutants:</strong></p>
            <ul>
                <li>Urban air pollution from New York metropolitan area</li>
                <li>Maritime shipping emissions</li>
                <li>Ozone during summer months</li>
                <li>PM2.5 from regional sources</li>
            </ul>
            </div>
            """, unsafe_allow_html=True)
            
        with st.expander("LATIN AMERICAN & CARIBBEAN LOCATIONS"):
            st.markdown("""
            <div style='font-size:18px;'>
            <h3>Casa Atrevida (Costa Rica)</h3>
            <p><strong>Water Pollutants:</strong></p>
            <ul>
                <li>Agricultural runoff (pesticides from banana and pineapple plantations)</li>
                <li>Mercury from regional gold mining operations</li>
                <li>Microplastics from coastal communities</li>
                <li>Sediment runoff during rainy season</li>
            </ul>
            <p><strong>Air Pollutants:</strong></p>
            <ul>
                <li>Relatively clean air due to prevailing ocean winds</li>
                <li>Seasonal wildfire smoke during dry periods</li>
                <li>Volcanic emissions (sulfur dioxide) depending on location</li>
                <li>Limited vehicle emissions in remote areas</li>
            </ul>
            
            <h3>Casa Ikal (Mexico)</h3>
            <p><strong>Water Pollutants:</strong></p>
            <ul>
                <li>Agricultural runoff from inland farming</li>
                <li>Sewage discharge from rapidly developing coastal areas</li>
                <li>Microplastics and marine debris</li>
                <li>Sunscreen chemicals impacting coral reefs</li>
            </ul>
            <p><strong>Air Pollutants:</strong></p>
            <ul>
                <li>Dust from inland desert regions</li>
                <li>Tourism-related vehicle emissions</li>
                <li>Construction dust from coastal development</li>
                <li>Relatively clean marine air in remote locations</li>
            </ul>
            </div>
            """, unsafe_allow_html=True)
            
        with st.expander("NEW ZEALAND & PACIFIC"):
            st.markdown("""
            <div style='font-size:18px;'>
            <h3>Castle Rock Beach House (New Zealand)</h3>
            <p><strong>Water Pollutants:</strong></p>
            <ul>
                <li>Agricultural runoff (livestock waste, fertilizers)</li>
                <li>Microplastics from local and distant sources</li>
                <li>Limited industrial contaminants</li>
                <li>Sediment from forest clearing and land development</li>
            </ul>
            <p><strong>Air Pollutants:</strong></p>
            <ul>
                <li>Clean air with limited industrial pollution</li>
                <li>Occasional wood smoke from residential heating</li>
                <li>Local vehicle emissions</li>
                <li>Natural sea spray aerosols</li>
            </ul>
            
            <h3>Oke Beach House (Bay of Islands, New Zealand)</h3>
            <p><strong>Water Pollutants:</strong></p>
            <ul>
                <li>Similar to Castle Rock with additional concerns for:</li>
                <li>Recreational boating pollutants (fuel, antifouling chemicals)</li>
                <li>Sewage discharge from boats and marinas</li>
                <li>Microplastics concentrated in bay environments</li>
            </ul>
            <p><strong>Air Pollutants:</strong></p>
            <ul>
                <li>Similar to Castle Rock</li>
                <li>Additional marina and boat engine emissions</li>
            </ul>
            </div>
            """, unsafe_allow_html=True)
            
        with st.expander("SOUTH AFRICAN COASTAL PROPERTIES"):
            st.markdown("""
            <div style='font-size:18px;'>
            <h3>Villa Misty Cliffs (Cape Town)</h3>
            <p><strong>Water Pollutants:</strong></p>
            <ul>
                <li>Urban stormwater runoff from Cape Town metropolitan area</li>
                <li>Microplastics from coastal communities and ocean currents</li>
                <li>Bacterial contamination from sewage infrastructure (especially after rainfall)</li>
                <li>Marine vessel discharge (shipping lanes nearby)</li>
                <li>Historical industrial pollutants in sediments</li>
            </ul>
            <p><strong>Air Pollutants:</strong></p>
            <ul>
                <li>Sea spray aerosols (natural but containing pollutants)</li>
                <li>Urban air pollution from Cape Town carried by prevailing winds</li>
                <li>Vehicle emissions from coastal roads</li>
                <li>Seasonal wildfire smoke during dry periods</li>
            </ul>
            
            <h3>The Beach House (Salt Rock, KwaZulu-Natal)</h3>
            <p><strong>Water Pollutants:</strong></p>
            <ul>
                <li>Agricultural runoff (fertilizers, pesticides from sugar cane plantations)</li>
                <li>Microplastics and marine debris</li>
                <li>Urban development runoff from growing coastal communities</li>
                <li>Elevated bacteria levels after heavy rainfall events</li>
            </ul>
            <p><strong>Air Pollutants:</strong></p>
            <ul>
                <li>Industrial emissions from Durban metropolitan area</li>
                <li>Vehicle emissions from N2 highway and coastal roads</li>
                <li>Sugar cane burning smoke during harvest season</li>
                <li>Marine aerosols</li>
            </ul>
            
            <h3>Pearl Bay Beach Villa (Yzerfontein)</h3>
            <p><strong>Water Pollutants:</strong></p>
            <ul>
                <li>Agricultural runoff from inland farming</li>
                <li>Microplastics carried by Benguela Current</li>
                <li>Fishing industry waste and gear</li>
                <li>Limited urban pollutants due to smaller community size</li>
            </ul>
            <p><strong>Air Pollutants:</strong></p>
            <ul>
                <li>Relatively clean air quality with strong ocean winds</li>
                <li>Limited local sources of air pollution</li>
                <li>Occasional dust from inland agricultural activities</li>
                <li>Seasonal wildfire smoke</li>
            </ul>
            
            <h3>Cape Beach Villa (Noordhoek)</h3>
            <p><strong>Water Pollutants:</strong></p>
            <ul>
                <li>Urban stormwater discharge from surrounding communities</li>
                <li>Wetland and river outflow (potentially carrying inland pollutants)</li>
                <li>Microplastics and marine debris</li>
                <li>Historical pollutants in sediments</li>
            </ul>
            <p><strong>Air Pollutants:</strong></p>
            <ul>
                <li>Vehicle emissions from Chapman's Peak Drive and surroundings</li>
                <li>Wood smoke from residential heating in winter</li>
                <li>Minimal industrial pollution due to distance from industrial zones</li>
                <li>Seasonal wildfire smoke</li>
            </ul>
            
            <h3>The Beach Hut (Paternoster)</h3>
            <p><strong>Water Pollutants:</strong></p>
            <ul>
                <li>Fishing industry waste and operational discharges</li>
                <li>Limited urban runoff due to small settlement size</li>
                <li>Agricultural pollutants from inland farms</li>
                <li>Microplastics from marine activities and ocean currents</li>
            </ul>
            <p><strong>Air Pollutants:</strong></p>
            <ul>
                <li>Very good air quality with minimal local pollution sources</li>
                <li>Natural marine aerosols</li>
                <li>Limited vehicle emissions</li>
                <li>Occasional dust from nearby agricultural activities</li>
            </ul>
            
            <h3>Thonga Beach Lodge (Maputaland)</h3>
            <p><strong>Water Pollutants:</strong></p>
            <ul>
                <li>Generally pristine water with minimal local pollution sources</li>
                <li>Limited development in the area results in less urban runoff</li>
                <li>Microplastics carried by ocean currents</li>
                <li>Potential agricultural runoff during rainy season</li>
            </ul>
            <p><strong>Air Pollutants:</strong></p>
            <ul>
                <li>Excellent air quality due to remote location</li>
                <li>Natural marine aerosols</li>
                <li>Minimal vehicle emissions</li>
                <li>Seasonal biomass burning from inland areas</li>
            </ul>
            </div>
            """, unsafe_allow_html=True)
            
        st.markdown("""
        <div style='font-size:18px; background-color:#f0f9ff; padding:15px; border-radius:10px; margin-top:20px;'>
        <h3>Important Notes:</h3>
        <ul>
            <li>Pollution levels vary seasonally and with changing weather conditions</li>
            <li>Luxury properties typically implement protective measures including filtration systems</li>
            <li>Local environmental monitoring provides the most accurate assessment</li>
            <li>Individual properties have minimal impact on large-scale ocean pollution</li>
            <li>Collective action and policy changes are needed to address marine pollution</li>
        </ul>
        </div>
        """, unsafe_allow_html=True)
        
    with tab4:
        # CHEMICALS FLOWING INTO OCEANS - Large font section
        st.markdown("<h1 style='font-size:36px; color:#1E88E5;'>CHEMICAL FLOWS INTO THE OCEAN</h1>", unsafe_allow_html=True)
        
        # Chemical cycle diagram using columns
        c1, c2, c3, c4 = st.columns(4)
        
        with c1:
            st.markdown("<div style='background-color:#89CFF0; padding:15px; border-radius:10px; text-align:center;'><h3 style='font-size:24px;'>SOURCE</h3><p style='font-size:18px;'>Industries<br>Agriculture<br>Urban Areas<br>Households</p></div>", unsafe_allow_html=True)
            
        with c2:
            st.markdown("<div style='background-color:#90EE90; padding:15px; border-radius:10px; text-align:center;'><h3 style='font-size:24px;'>TRANSPORT</h3><p style='font-size:18px;'>Sewage<br>Runoff<br>Air<br>Rivers</p></div>", unsafe_allow_html=True)
            
        with c3:
            st.markdown("<div style='background-color:#FFFF99; padding:15px; border-radius:10px; text-align:center;'><h3 style='font-size:24px;'>DESTINATION</h3><p style='font-size:18px;'>Ocean<br>Beaches<br>Marine Life<br>Sediment</p></div>", unsafe_allow_html=True)
            
        with c4:
            st.markdown("<div style='background-color:#FF9999; padding:15px; border-radius:10px; text-align:center;'><h3 style='font-size:24px;'>EXPOSURE</h3><p style='font-size:18px;'>Beach Activities<br>Seafood<br>Mist Inhalation<br>Skin Contact</p></div>", unsafe_allow_html=True)
        
        # Major Chemical Groups Section
        st.markdown("<h2 style='font-size:28px; margin-top:30px;'>MAJOR OCEAN POLLUTANTS</h2>", unsafe_allow_html=True)
        
        # Create chemical groups data
        chemical_data = {
            "Chemical Group": [
                "Heavy Metals", 
                "Persistent Organic Pollutants", 
                "Nutrients & Fertilizers", 
                "Pharmaceutical Compounds",
                "Petroleum Hydrocarbons",
                "Plastic Additives"
            ],
            "Main Sources": [
                "Industrial discharge, mining, e-waste",
                "Industrial processes, pesticides, flame retardants",
                "Agricultural runoff, sewage, detergents",
                "Human waste, hospital waste, livestock",
                "Oil spills, urban runoff, shipping",
                "Microplastics degradation, industrial waste"
            ],
            "Examples": [
                "Mercury, Lead, Cadmium, Arsenic",
                "PCBs, DDT, Dioxins, PFAS",
                "Nitrogen, Phosphorus, Ammonia",
                "Antibiotics, Hormones, Painkillers",
                "Benzene, PAHs, Crude oil components",
                "Phthalates, BPA, Flame retardants"
            ],
            "Health Impact Level": [9, 8, 6, 7, 7, 8],
        }
        
        chemical_df = pd.DataFrame(chemical_data)
        
        # Create sortable table for chemicals
        st.dataframe(
            chemical_df,
            column_config={
                "Chemical Group": st.column_config.TextColumn("Chemical Group", width="medium"),
                "Main Sources": st.column_config.TextColumn("Main Sources", width="large"),
                "Examples": st.column_config.TextColumn("Examples", width="large"),
                "Health Impact Level": st.column_config.ProgressColumn(
                    "Health Impact (1-10)",
                    min_value=0,
                    max_value=10,
                    format="%d",
                    help="Impact level on human health from 1 (low) to 10 (severe)"
                ),
            },
            use_container_width=True,
            hide_index=True,
        )
        
        # Comprehensive list of all specific chemicals
        st.markdown("<h2 style='font-size:28px; margin-top:30px;'>COMPREHENSIVE CHEMICAL LIST</h2>", unsafe_allow_html=True)
        
        # Create tabs for different chemical categories
        chem_tab1, chem_tab2, chem_tab3 = st.tabs(["Metals & Inorganics", "Organic Pollutants", "Emerging Contaminants"])
        
        with chem_tab1:
            st.markdown("<h3 style='font-size:22px;'>HEAVY METALS & INORGANIC COMPOUNDS</h3>", unsafe_allow_html=True)
            st.markdown("""
            <div style='font-size:18px;'>
            <p><strong>Mercury (Hg):</strong> Found in thermometers, dental amalgams, batteries, fluorescent bulbs</p>
            <p><strong>Lead (Pb):</strong> From old paints, batteries, electronics, ammunition, fishing weights</p>
            <p><strong>Cadmium (Cd):</strong> Present in batteries, pigments, plating, stabilizers</p>
            <p><strong>Arsenic (As):</strong> From pressure-treated wood, pesticides, mining activities</p>
            <p><strong>Chromium (Cr):</strong> Used in metal plating, leather tanning, wood preservation</p>
            <p><strong>Zinc (Zn):</strong> In galvanized metals, rubber, paint, batteries</p>
            <p><strong>Copper (Cu):</strong> Found in pipes, electronics, pesticides, antifouling paints</p>
            <p><strong>Nickel (Ni):</strong> Used in stainless steel, batteries, electronics</p>
            <p><strong>Selenium (Se):</strong> Present in electronics, glass, pigments</p>
            <p><strong>Antimony (Sb):</strong> Used in flame retardants, batteries, textiles</p>
            <p><strong>Cyanide Compounds:</strong> From mining, industrial processes</p>
            <p><strong>Asbestos:</strong> Construction materials, insulation</p>
            <p><strong>Radioactive Elements:</strong> Uranium, Plutonium, Radium, Caesium-137, Strontium-90</p>
            </div>
            """, unsafe_allow_html=True)
        
        with chem_tab2:
            st.markdown("<h3 style='font-size:22px;'>PERSISTENT ORGANIC POLLUTANTS & HYDROCARBONS</h3>", unsafe_allow_html=True)
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("""
                <div style='font-size:18px;'>
                <p><strong>PCBs (Polychlorinated Biphenyls):</strong> Industrial coolants, lubricants</p>
                <p><strong>Dioxins & Furans:</strong> Byproducts of industrial processes</p>
                <p><strong>DDT & Metabolites:</strong> Insecticide still used in some regions</p>
                <p><strong>Chlordane:</strong> Termite & insect control</p>
                <p><strong>Heptachlor:</strong> Insecticide for termites</p>
                <p><strong>Aldrin & Dieldrin:</strong> Insecticides</p>
                <p><strong>Endrin:</strong> Insecticide and rodenticide</p>
                <p><strong>HCB (Hexachlorobenzene):</strong> Fungicide, industrial chemical</p>
                <p><strong>Mirex:</strong> Insecticide, fire retardant</p>
                <p><strong>Toxaphene:</strong> Insecticide</p>
                <p><strong>PFAS (Per- and Polyfluoroalkyl Substances):</strong> PFOA, PFOS, GenX</p>
                <p><strong>PBDEs (Polybrominated Diphenyl Ethers):</strong> Flame retardants</p>
                </div>
                """, unsafe_allow_html=True)
            
            with col2:
                st.markdown("""
                <div style='font-size:18px;'>
                <p><strong>Petroleum Hydrocarbons:</strong></p>
                <p>• Benzene</p>
                <p>• Toluene</p>
                <p>• Ethylbenzene</p>
                <p>• Xylenes (BTEX)</p>
                <p>• PAHs (Polycyclic Aromatic Hydrocarbons):</p>
                <p>• Naphthalene</p>
                <p>• Anthracene</p>
                <p>• Phenanthrene</p>
                <p>• Benzo[a]pyrene</p>
                <p>• Benzo[b]fluoranthene</p>
                <p>• Chrysene</p>
                <p>• Fluoranthene</p>
                <p>• Indeno[1,2,3-cd]pyrene</p>
                </div>
                """, unsafe_allow_html=True)
        
        with chem_tab3:
            st.markdown("<h3 style='font-size:22px;'>PHARMACEUTICALS, NUTRIENTS & EMERGING CONTAMINANTS</h3>", unsafe_allow_html=True)
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("""
                <div style='font-size:18px;'>
                <p><strong>Pharmaceutical Compounds:</strong></p>
                <p>• Antibiotics (Ciprofloxacin, Tetracycline, Erythromycin)</p>
                <p>• Analgesics (Acetaminophen, Ibuprofen, Diclofenac)</p>
                <p>• Hormones (Estradiol, Ethinylestradiol, Testosterone)</p>
                <p>• Antidepressants (Fluoxetine, Sertraline)</p>
                <p>• Beta-blockers (Propranolol, Metoprolol)</p>
                <p>• Anticonvulsants (Carbamazepine, Lamotrigine)</p>
                <p>• Lipid regulators (Gemfibrozil, Bezafibrate)</p>
                
                <p><strong>Plastic Additives:</strong></p>
                <p>• Phthalates (DEHP, DBP, BBP)</p>
                <p>• Bisphenols (BPA, BPS, BPF)</p>
                <p>• Nonylphenols & Octylphenols</p>
                <p>• Organotins (Tributyltin)</p>
                </div>
                """, unsafe_allow_html=True)
            
            with col2:
                st.markdown("""
                <div style='font-size:18px;'>
                <p><strong>Nutrients & Agricultural Chemicals:</strong></p>
                <p>• Nitrates & Nitrites</p>
                <p>• Phosphates</p>
                <p>• Ammonia & Ammonium compounds</p>
                <p>• Urea</p>
                <p>• Herbicides (Atrazine, Glyphosate, 2,4-D)</p>
                <p>• Fungicides (Chlorothalonil, Mancozeb)</p>
                <p>• Insecticides (Neonicotinoids, Organophosphates)</p>
                
                <p><strong>Personal Care Products:</strong></p>
                <p>• UV filters (Oxybenzone, Octinoxate)</p>
                <p>• Fragrances (Synthetic musks)</p>
                <p>• Preservatives (Parabens, Triclosan)</p>
                <p>• Microbeads (Polyethylene microspheres)</p>
                </div>
                """, unsafe_allow_html=True)
        
        # Transmission mechanisms summary
        st.markdown("<h3 style='font-size:24px; margin-top:20px;'>TRANSMISSION TO MARINE ENVIRONMENT</h3>", unsafe_allow_html=True)
        
        trans_col1, trans_col2, trans_col3 = st.columns(3)
        
        with trans_col1:
            st.markdown("""
            <div style='background-color:#BBDEFB; padding:10px; border-radius:10px; text-align:center;'>
            <h4 style='font-size:20px;'>DIRECT DISCHARGE</h4>
            <p style='font-size:16px;'>• Industrial effluent<br>• Wastewater treatment plants<br>• Stormwater outfalls<br>• Shipping waste</p>
            </div>
            """, unsafe_allow_html=True)
            
        with trans_col2:
            st.markdown("""
            <div style='background-color:#DCEDC8; padding:10px; border-radius:10px; text-align:center;'>
            <h4 style='font-size:20px;'>RUNOFF & LEACHING</h4>
            <p style='font-size:16px;'>• Agricultural fields<br>• Urban surfaces<br>• Landfills<br>• Mining sites</p>
            </div>
            """, unsafe_allow_html=True)
            
        with trans_col3:
            st.markdown("""
            <div style='background-color:#FFECB3; padding:10px; border-radius:10px; text-align:center;'>
            <h4 style='font-size:20px;'>ATMOSPHERIC DEPOSITION</h4>
            <p style='font-size:16px;'>• Industrial emissions<br>• Vehicle exhaust<br>• Pesticide drift<br>• Incinerators</p>
            </div>
            """, unsafe_allow_html=True)
        
        # HEALTH IMPACTS - Large font section
        st.markdown("<h1 style='font-size:36px; color:#E53935; margin-top:30px;'>HEALTH IMPACTS ON HUMANS</h1>", unsafe_allow_html=True)
        
        # What happens to people who consume these chemicals
        st.markdown("<h2 style='font-size:28px;'>IMPACTS FROM CONSUMING MARINE POLLUTANTS</h2>", unsafe_allow_html=True)
        
        # Create tabs for different exposure pathways
        exp_tab1, exp_tab2, exp_tab3 = st.tabs(["Seafood Consumption", "Swimming & Beach Activities", "Coastal Living"])
        
        with exp_tab1:
            st.markdown("<h3 style='font-size:24px;'>CONSUMING CONTAMINATED SEAFOOD</h3>", unsafe_allow_html=True)
            
            # Create two columns for short and long term effects
            scol1, scol2 = st.columns(2)
            
            with scol1:
                st.markdown("<h4 style='font-size:20px;'>BIOACCUMULATION IN SEAFOOD</h4>", unsafe_allow_html=True)
                st.markdown("""
                <div style='font-size:18px;'>
                <p>Marine organisms absorb chemicals from their environment. As larger predators consume smaller organisms, toxins concentrate at higher levels of the food chain.</p>
                
                <p><strong>Most Affected Seafood:</strong></p>
                <ul>
                    <li>Large predatory fish (tuna, swordfish, shark, king mackerel)</li>
                    <li>Bottom-feeding fish and shellfish</li>
                    <li>Older and larger specimens contain higher concentrations</li>
                </ul>
                
                <p><strong>Highest Risk Chemicals in Seafood:</strong></p>
                <ul>
                    <li>Mercury - concentrates in muscle tissue</li>
                    <li>PCBs and dioxins - accumulate in fatty tissues</li>
                    <li>PFAS - "forever chemicals" that persist in tissues</li>
                    <li>Microplastics - now found in virtually all seafood</li>
                </ul>
                </div>
                """, unsafe_allow_html=True)
            
            with scol2:
                st.markdown("<h4 style='font-size:20px;'>HEALTH CONSEQUENCES</h4>", unsafe_allow_html=True)
                st.markdown("""
                <div style='font-size:18px;'>
                <p><strong>Immediate/Short-term:</strong></p>
                <ul>
                    <li>Gastrointestinal distress (diarrhea, vomiting, abdominal pain)</li>
                    <li>Allergic reactions or hypersensitivity responses</li>
                    <li>Acute neurological symptoms (headache, dizziness, coordination issues)</li>
                </ul>
                
                <p><strong>Long-term/Chronic:</strong></p>
                <ul>
                    <li><strong>Neurodevelopmental:</strong> Mercury exposure causes developmental delays, impaired cognition, and reduced IQ, especially in fetuses and young children</li>
                    <li><strong>Endocrine Disruption:</strong> PCBs and PFAS interfere with hormone systems, affecting fertility, metabolism, and development</li>
                    <li><strong>Cancer Risk:</strong> Increased rates of liver, kidney, and gastrointestinal cancers from prolonged exposure to organic pollutants</li>
                    <li><strong>Cardiovascular:</strong> Heavy metals and POPs contribute to hypertension, heart disease, and stroke</li>
                </ul>
                </div>
                """, unsafe_allow_html=True)
                
            # Add a vulnerability section
            st.markdown("<h4 style='font-size:20px;'>VULNERABLE POPULATIONS</h4>", unsafe_allow_html=True)
            st.markdown("""
            <div style='font-size:18px;'>
            <ul>
                <li><strong>Pregnant women and fetuses</strong> - Developing brains are highly susceptible to neurotoxins</li>
                <li><strong>Young children</strong> - Higher absorption rates and developing organ systems</li>
                <li><strong>Frequent seafood consumers</strong> - Higher exposure to bioaccumulated toxins</li>
                <li><strong>Subsistence fishers</strong> - Often catch from more polluted areas and consume more fish</li>
                <li><strong>Immunocompromised individuals</strong> - Reduced ability to detoxify harmful substances</li>
            </ul>
            </div>
            """, unsafe_allow_html=True)
        
        with exp_tab2:
            st.markdown("<h3 style='font-size:24px;'>SWIMMING & RECREATIONAL EXPOSURE</h3>", unsafe_allow_html=True)
            
            # Two columns for different exposure routes
            wcol1, wcol2 = st.columns(2)
            
            with wcol1:
                st.markdown("<h4 style='font-size:20px;'>INGESTION WHILE SWIMMING</h4>", unsafe_allow_html=True)
                st.markdown("""
                <div style='font-size:18px;'>
                <p>Swimmers typically accidentally swallow small amounts of water (average 27ml per 45 minutes for adults; 37ml for children).</p>
                
                <p><strong>Common Contaminants:</strong></p>
                <ul>
                    <li><strong>Microbial</strong> - Fecal bacteria (E. coli, Enterococci), viruses, parasites</li>
                    <li><strong>Chemical</strong> - Sewage overflow chemicals, pesticide runoff, disinfection byproducts</li>
                    <li><strong>Algal Toxins</strong> - From harmful algal blooms caused by nutrient pollution</li>
                </ul>
                
                <p><strong>Health Effects:</strong></p>
                <ul>
                    <li><strong>Gastrointestinal illness</strong> - Nausea, vomiting, diarrhea (most common outcome)</li>
                    <li><strong>Respiratory</strong> - Coughing, wheezing, asthma exacerbation from aerosolized toxins</li>
                    <li><strong>Neurological</strong> - Tingling, dizziness, confusion, headache (from certain algal toxins)</li>
                    <li><strong>Liver and kidney stress</strong> - From processing and filtering contaminants</li>
                </ul>
                </div>
                """, unsafe_allow_html=True)
            
            with wcol2:
                st.markdown("<h4 style='font-size:20px;'>SKIN & RESPIRATORY EXPOSURE</h4>", unsafe_allow_html=True)
                st.markdown("""
                <div style='font-size:18px;'>
                <p><strong>Skin Contact:</strong></p>
                <ul>
                    <li><strong>Irritant dermatitis</strong> - Redness, itching, burning from direct chemical contact</li>
                    <li><strong>Chemical burns</strong> - From high concentrations of industrial pollutants</li>
                    <li><strong>Infections</strong> - From bacteria/fungi entering through small cuts or abrasions</li>
                    <li><strong>Sensitization</strong> - Development of allergies from repeated exposure</li>
                </ul>
                
                <p><strong>Inhalation of Sea Spray/Mist:</strong></p>
                <ul>
                    <li><strong>Respiratory inflammation</strong> - Irritation of airways, coughing, bronchitis symptoms</li>
                    <li><strong>Aerosolized bacteria/viruses</strong> - Respiratory infections</li>
                    <li><strong>Brevetoxins</strong> - From red tide can cause respiratory distress and acute asthma attacks</li>
                    <li><strong>Metal-bearing aerosols</strong> - Mercury and lead particles can be inhaled from sea spray</li>
                </ul>
                </div>
                """, unsafe_allow_html=True)
            
            # Add high-risk conditions and signs section
            st.markdown("<h4 style='font-size:20px;'>WARNING SIGNS & HIGH-RISK CONDITIONS</h4>", unsafe_allow_html=True)
            
            rcol1, rcol2 = st.columns(2)
            
            with rcol1:
                st.markdown("""
                <div style='background-color:#FFEBEE; padding:15px; border-radius:10px;'>
                <h5 style='font-size:18px;'>When NOT to Swim:</h5>
                <ul style='font-size:16px;'>
                    <li>After heavy rainfall (48-72 hours)</li>
                    <li>Near stormwater outfalls or river mouths</li>
                    <li>During algal bloom advisories</li>
                    <li>When water has unusual color/smell</li>
                    <li>When beaches have posted advisories</li>
                </ul>
                </div>
                """, unsafe_allow_html=True)
            
            with rcol2:
                st.markdown("""
                <div style='background-color:#FFF9C4; padding:15px; border-radius:10px;'>
                <h5 style='font-size:18px;'>Signs of Exposure:</h5>
                <ul style='font-size:16px;'>
                    <li>Unexplained rash or skin irritation</li>
                    <li>Digestive issues starting 12-48 hours after swimming</li>
                    <li>Eye, ear, or respiratory irritation</li>
                    <li>Unusual fatigue, headache, or fever</li>
                </ul>
                </div>
                """, unsafe_allow_html=True)
        
        with exp_tab3:
            st.markdown("<h3 style='font-size:24px;'>COASTAL LIVING EXPOSURE</h3>", unsafe_allow_html=True)
            st.markdown("""
            <div style='font-size:18px;'>
            <p>People living in coastal areas, particularly near beach houses, face chronic low-level exposure to marine pollutants through:</p>
            
            <p><strong>Air/Mist Exposure:</strong></p>
            <ul>
                <li><strong>Sea spray aerosols</strong> - Contain concentrated pollutants ejected from ocean surface into air</li>
                <li><strong>Coastal fog</strong> - Can accumulate methylmercury and carry it inland</li>
                <li><strong>Microplastics</strong> - Airborne microplastic particles from ocean surface detected in coastal air</li>
            </ul>
            
            <p><strong>Cumulative Effects of Long-term Exposure:</strong></p>
            <ul>
                <li><strong>Subtle neurological impacts</strong> - Memory issues, cognitive decline, mood changes</li>
                <li><strong>Endocrine disruption</strong> - Thyroid disorders, metabolic changes, reproductive issues</li>
                <li><strong>Increased cancer risk</strong> - Particularly for hormonal and digestive system cancers</li>
                <li><strong>Immune system dysregulation</strong> - Increased allergies, autoimmune conditions, reduced resistance to infection</li>
                <li><strong>Developmental effects</strong> - Subtle impacts on children's neurological development</li>
            </ul>
            </div>
            """, unsafe_allow_html=True)
            
            # Add a specific section on special concern chemicals
            st.markdown("<h4 style='font-size:20px;'>CHEMICALS OF SPECIAL CONCERN FOR COASTAL RESIDENTS</h4>", unsafe_allow_html=True)
            
            ccol1, ccol2, ccol3 = st.columns(3)
            
            with ccol1:
                st.markdown("""
                <div style='background-color:#E8EAF6; padding:10px; border-radius:10px; height:100%;'>
                <h5 style='font-size:18px;'>Mercury & Methylmercury</h5>
                <p style='font-size:15px;'>Neurotoxic element that bioaccumulates in seafood and can be detected in coastal air. Causes neurological damage, especially during development.</p>
                </div>
                """, unsafe_allow_html=True)
                
            with ccol2:
                st.markdown("""
                <div style='background-color:#E8F5E9; padding:10px; border-radius:10px; height:100%;'>
                <h5 style='font-size:18px;'>PFAS Compounds</h5>
                <p style='font-size:15px;'>"Forever chemicals" that persist in the environment and body. Associated with cancer, liver damage, decreased fertility, and immune suppression.</p>
                </div>
                """, unsafe_allow_html=True)
                
            with ccol3:
                st.markdown("""
                <div style='background-color:#FFF3E0; padding:10px; border-radius:10px; height:100%;'>
                <h5 style='font-size:18px;'>Microplastics</h5>
                <p style='font-size:15px;'>Microscopic plastic particles that can enter the body through seafood, water, and air. May carry other toxins and cause inflammation and oxidative stress.</p>
                </div>
                """, unsafe_allow_html=True)
        
        # Key Facts section with larger text
        st.markdown("<div style='background-color:#FFCDD2; padding:20px; border-radius:10px; margin-top:30px;'>", unsafe_allow_html=True)
        st.markdown("<h2 style='font-size:26px; text-align:center;'>CRITICAL FACTS ON HUMAN EXPOSURE</h2>", unsafe_allow_html=True)
        st.markdown("""
        <ul style='font-size:18px;'>
            <li>Children who swim in polluted water are 3x more likely to develop gastrointestinal illness</li>
            <li>Mercury levels in frequent seafood consumers can be up to 7x higher than in non-consumers</li>
            <li>Microplastics have been detected in human blood, placenta, and lung tissue</li>
            <li>Beach closures due to bacterial contamination have increased 30% globally in the last decade</li>
            <li>Coastal residents have measurably higher levels of certain persistent organic pollutants</li>
            <li>Even "safe" levels of multiple chemicals can have synergistic effects, multiplying health risks</li>
        </ul>
        """, unsafe_allow_html=True)
        st.markdown("</div>", unsafe_allow_html=True)
        
        # Specific pathways for Cape Town
        st.markdown("<h2 style='font-size:28px; margin-top:30px;'>CAPE TOWN POLLUTION HOTSPOTS</h2>", unsafe_allow_html=True)
        st.markdown("""
        <ul style='font-size:18px;'>
            <li>Soet River Mouth (Strand)</li>
            <li>Saunders' Rocks</li>
            <li>Stormwater outlets on major beaches</li>
            <li>Areas near wastewater treatment plants</li>
        </ul>
        """, unsafe_allow_html=True)

if __name__ == "__main__":
    app()