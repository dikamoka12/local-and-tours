"""
Monitoring and Control Panel (MCP) Dashboard
-------------------------------------------
Live monitoring dashboard that connects to DeepSeek for real-time
pollution data on water, air, and other environmental metrics.
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import json
import os
import sys
from utils.deepseek_api import (
    test_api_connection,
    get_water_pollution_metrics,
    get_air_quality_metrics,
    get_pollution_alerts,
    get_trend_data,
    analyze_pollution_correlation,
    generate_pollution_report,
    get_pollution_analysis
)
from utils.common import display_common_messages
from utils.multilingual import get_text

def app():
    """MCP Dashboard main function"""
    # Set page title
    st.title("Monitoring & Control Panel (MCP)")
    st.markdown("<div style='background-color:#1E3B70; padding:10px; border-radius:5px; margin-bottom:20px;'><h2 style='color:white; text-align:center;'>SOUTH AFRICAN WATER SYSTEMS - TOURISTS AND LOCALS</h2></div>", unsafe_allow_html=True)
    
    # Add description
    st.write("Real-time monitoring dashboard for pollution data powered by DeepSeek API.")
    
    # API connection status indicator
    with st.expander("API Connection Status", expanded=False):
        status_col1, status_col2 = st.columns([1, 3])
        
        with status_col1:
            if st.button("Test Connection"):
                with st.spinner("Testing API connection..."):
                    is_connected, message = test_api_connection()
                    
                    if is_connected:
                        st.success(message)
                    else:
                        st.error(message)
        
        with status_col2:
            st.info("This dashboard connects to the DeepSeek API to retrieve real-time pollution data. Click 'Test Connection' to verify API availability.")
    
    # Location selection
    st.subheader("Select Location")
    
    location_col1, location_col2 = st.columns([2, 1])
    
    with location_col1:
        # Pre-defined locations
        locations = [
            "All Locations", 
            "Cape Town, South Africa", 
            "Johannesburg, South Africa", 
            "Durban, South Africa", 
            "Port Elizabeth, South Africa",
            "Pretoria, South Africa",
            "Add Custom Location..."
        ]
        
        selected_location = st.selectbox(
            "Choose location to monitor:",
            locations
        )
    
    # Initialize custom_location as None
    custom_location = None
    # Initialize monitoring_period with default value
    monitoring_period = "Last 7 days"
    
    with location_col2:
        if selected_location == "Add Custom Location...":
            custom_location = st.text_input("Enter location:")
            if custom_location:
                selected_location = custom_location
        else:
            # Date range selector
            monitoring_period = st.selectbox(
                "Time period:",
                ["Last 24 hours", "Last 7 days", "Last 30 days", "Last 90 days"],
                index=1  # Default to "Last 7 days"
            )
    
    # Display actual monitoring panels
    if selected_location != "Add Custom Location..." or (selected_location == "Add Custom Location..." and custom_location):
        # Use 'All Locations' as None for the API
        api_location = None if selected_location == "All Locations" else selected_location
        
        # Use the monitoring_period value we initialized earlier
        time_period = monitoring_period
        
        # Display live monitoring dashboard
        display_mcp_dashboard(api_location, time_period)
    
    # Add footer
    st.markdown("<div style='background-color:#1E3B70; padding:10px; border-radius:5px; margin-top:20px;'><h3 style='color:white; text-align:center;'>SOUTH AFRICAN WATER SYSTEMS - TOURISTS AND LOCALS</h3></div>", unsafe_allow_html=True)
    display_common_messages()

def display_mcp_dashboard(location, time_period):
    """
    Display the main MCP dashboard with multiple monitoring panels.
    
    Args:
        location (str): Location to display data for
        time_period (str): Time period to display
    """
    # Create main layout with tabs
    tab1, tab2, tab3, tab4 = st.tabs([
        "Overview", 
        "Water Pollution", 
        "Air Quality", 
        "Analysis & Reports"
    ])
    
    # Overview Tab
    with tab1:
        display_overview_panel(location, time_period)
    
    # Water Pollution Tab
    with tab2:
        display_water_pollution_panel(location, time_period)
    
    # Air Quality Tab
    with tab3:
        display_air_quality_panel(location, time_period)
    
    # Analysis Tab
    with tab4:
        display_analysis_panel(location, time_period)

def display_overview_panel(location, time_period):
    """Display overview panel with key metrics and alerts"""
    st.header("Pollution Monitoring Overview")
    
    if location:
        st.subheader(f"Location: {location}")
    else:
        st.subheader("All Monitored Locations")
    
    # Active alerts section
    st.markdown("### Active Alerts")
    
    with st.spinner("Loading alerts..."):
        success, alerts_data = get_pollution_alerts(min_severity=3)
        
        if success and alerts_data and len(alerts_data) > 0:
            # Display alerts in a table
            alert_df = pd.DataFrame(alerts_data)
            
            # Format the dataframe for display
            if 'timestamp' in alert_df.columns:
                alert_df['timestamp'] = pd.to_datetime(alert_df['timestamp']).dt.strftime('%Y-%m-%d %H:%M')
            
            if 'severity' in alert_df.columns:
                alert_df['severity'] = alert_df['severity'].apply(lambda x: '🔴 Critical' if x >= 5 else '🟠 High' if x >= 4 else '🟡 Medium')
            
            # Display styled table
            st.dataframe(
                alert_df[['timestamp', 'location', 'type', 'severity', 'message']].rename(
                    columns={
                        'timestamp': 'Time', 
                        'location': 'Location', 
                        'type': 'Type', 
                        'severity': 'Severity', 
                        'message': 'Details'
                    }
                ),
                use_container_width=True
            )
        elif success and (not alerts_data or len(alerts_data) == 0):
            st.info("No active alerts at this time.")
        else:
            st.error(f"Failed to load alerts: {alerts_data}")
    
    # Key metrics overview
    st.markdown("### Key Metrics")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("#### Water Quality")
        with st.spinner("Loading water data..."):
            success, water_data = get_water_pollution_metrics(location)
            
            if success:
                metrics_col1, metrics_col2 = st.columns(2)
                
                with metrics_col1:
                    st.metric(
                        label="pH Level", 
                        value=f"{water_data.get('ph_level', 'N/A')}"
                    )
                
                with metrics_col2:
                    st.metric(
                        label="Safety Index", 
                        value=f"{water_data.get('safety_index', 'N/A')}/10"
                    )
                
                # Show contaminants if available
                if 'contaminants' in water_data and water_data['contaminants']:
                    st.markdown("**Top Contaminants:**")
                    for contaminant in water_data['contaminants'][:3]:  # Show top 3
                        st.write(f"• {contaminant.get('name', 'Unknown')}: {contaminant.get('level', 'N/A')} {contaminant.get('unit', '')}")
            else:
                st.error(f"Failed to load water quality data: {water_data}")
    
    with col2:
        st.markdown("#### Air Quality")
        with st.spinner("Loading air data..."):
            success, air_data = get_air_quality_metrics(location)
            
            if success:
                metrics_col1, metrics_col2 = st.columns(2)
                
                with metrics_col1:
                    st.metric(
                        label="AQI", 
                        value=f"{air_data.get('aqi', 'N/A')}"
                    )
                
                with metrics_col2:
                    st.metric(
                        label="Health Risk", 
                        value=f"{air_data.get('health_risk', 'N/A')}"
                    )
                
                # Show pollutants if available
                if 'pollutants' in air_data and air_data['pollutants']:
                    st.markdown("**Top Pollutants:**")
                    for pollutant_name, pollutant_value in list(air_data['pollutants'].items())[:3]:  # Show top 3
                        if isinstance(pollutant_value, dict):
                            st.write(f"• {pollutant_name}: {pollutant_value.get('value', 'N/A')} {pollutant_value.get('unit', '')}")
                        else:
                            st.write(f"• {pollutant_name}: {pollutant_value}")
            else:
                st.error(f"Failed to load air quality data: {air_data}")
    
    # Display update time
    st.markdown("---")
    st.caption(f"Last updated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

def display_water_pollution_panel(location, time_period):
    """Display detailed water pollution monitoring panel"""
    st.header("Water Pollution Monitoring")
    
    if location:
        st.subheader(f"Location: {location}")
    else:
        st.subheader("All Monitored Locations")
    
    # Get detailed water metrics
    with st.spinner("Loading water pollution data..."):
        success, water_data = get_water_pollution_metrics(location)
        
        if success:
            # Main metrics display
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.metric(
                    label="pH Level", 
                    value=f"{water_data.get('ph_level', 'N/A')}"
                )
            
            with col2:
                st.metric(
                    label="Safety Index", 
                    value=f"{water_data.get('safety_index', 'N/A')}/10"
                )
            
            with col3:
                st.metric(
                    label="Last Updated", 
                    value=water_data.get('last_updated', 'N/A')
                )
            
            # Contaminants table
            st.markdown("### Detected Contaminants")
            
            if 'contaminants' in water_data and water_data['contaminants']:
                contaminants_df = pd.DataFrame(water_data['contaminants'])
                
                if not contaminants_df.empty:
                    # Add color coding based on levels
                    def highlight_level(val):
                        if isinstance(val, (int, float)):
                            if val > 80:
                                return 'background-color: #ffcccc'  # Red for high
                            elif val > 50:
                                return 'background-color: #ffffcc'  # Yellow for medium
                            else:
                                return 'background-color: #ccffcc'  # Green for low
                        return ''
                    
                    styled_df = contaminants_df.style.map(highlight_level, subset=['level'])
                    st.dataframe(styled_df, use_container_width=True)
                else:
                    st.info("No contaminant data available")
            else:
                st.info("No contaminant data available")
            
            # Trend analysis
            st.markdown("### Trend Analysis")
            
            # Get trend data for pH level
            tab1, tab2, tab3 = st.tabs(["pH Level", "Contaminants", "Safety Index"])
            
            with tab1:
                display_trend_chart(
                    "water", 
                    "ph_level", 
                    location, 
                    time_period,
                    "pH Level Trend",
                    "pH",
                    [6.5, 8.5]  # Normal range for pH
                )
            
            with tab2:
                if 'contaminants' in water_data and water_data['contaminants']:
                    # Get contaminant names
                    contaminant_names = [c.get('name', 'Unknown') for c in water_data['contaminants']]
                    if contaminant_names:
                        selected_contaminant = st.selectbox(
                            "Select contaminant to view trend:",
                            contaminant_names
                        )
                        
                        display_trend_chart(
                            "water", 
                            f"contaminants.{selected_contaminant}", 
                            location, 
                            time_period,
                            f"{selected_contaminant} Level Trend",
                            "Level"
                        )
                    else:
                        st.info("No contaminant data available")
                else:
                    st.info("No contaminant data available for trend analysis")
            
            with tab3:
                display_trend_chart(
                    "water", 
                    "safety_index", 
                    location, 
                    time_period,
                    "Water Safety Index Trend",
                    "Safety Index",
                    [0, 10]  # Range for safety index
                )
            
            # Critical alerts
            if 'critical_alerts' in water_data and water_data['critical_alerts']:
                st.markdown("### Critical Alerts")
                
                for alert in water_data['critical_alerts']:
                    st.warning(f"**{alert.get('title', 'Alert')}**: {alert.get('description', 'No details')}")
            
        else:
            st.error(f"Failed to load water pollution data: {water_data}")

def display_air_quality_panel(location, time_period):
    """Display detailed air quality monitoring panel"""
    st.header("Air Quality Monitoring")
    
    if location:
        st.subheader(f"Location: {location}")
    else:
        st.subheader("All Monitored Locations")
    
    # Get detailed air metrics
    with st.spinner("Loading air quality data..."):
        success, air_data = get_air_quality_metrics(location)
        
        if success:
            # Main metrics display
            col1, col2, col3 = st.columns(3)
            
            with col1:
                aqi = air_data.get('aqi', 'N/A')
                
                # Determine color based on AQI
                color = "#ccffcc"  # Green for good
                if isinstance(aqi, (int, float)):
                    if aqi > 200:
                        color = "#ff0000"  # Red for hazardous
                    elif aqi > 150:
                        color = "#ff9900"  # Orange for unhealthy
                    elif aqi > 100:
                        color = "#ffff00"  # Yellow for moderate
                
                st.markdown(
                    f"""
                    <div style="background-color:{color}; padding:10px; border-radius:5px; text-align:center;">
                        <h3 style="margin:0;">AQI</h3>
                        <h2 style="margin:0;">{aqi}</h2>
                    </div>
                    """,
                    unsafe_allow_html=True
                )
            
            with col2:
                st.metric(
                    label="Health Risk", 
                    value=f"{air_data.get('health_risk', 'N/A')}"
                )
            
            with col3:
                st.metric(
                    label="Last Updated", 
                    value=air_data.get('last_updated', 'N/A')
                )
            
            # Pollutant levels
            st.markdown("### Air Pollutant Levels")
            
            if 'pollutants' in air_data and air_data['pollutants']:
                # Convert pollutants to DataFrame
                pollutants_data = []
                
                for name, data in air_data['pollutants'].items():
                    if isinstance(data, dict):
                        pollutants_data.append({
                            'name': name,
                            'value': data.get('value', 'N/A'),
                            'unit': data.get('unit', ''),
                            'category': data.get('category', 'Unknown')
                        })
                    else:
                        pollutants_data.append({
                            'name': name,
                            'value': data,
                            'unit': '',
                            'category': 'Unknown'
                        })
                
                pollutants_df = pd.DataFrame(pollutants_data)
                
                if not pollutants_df.empty and 'value' in pollutants_df.columns:
                    # Create a horizontal bar chart
                    fig = px.bar(
                        pollutants_df,
                        y='name',
                        x='value',
                        labels={'value': 'Level', 'name': 'Pollutant'},
                        title='Current Pollutant Levels',
                        color='value',
                        color_continuous_scale=px.colors.sequential.Reds,
                        orientation='h'
                    )
                    
                    fig.update_layout(height=400)
                    st.plotly_chart(fig, use_container_width=True)
                
                # Also display as table with categories
                st.dataframe(pollutants_df, use_container_width=True)
            else:
                st.info("No pollutant data available")
            
            # Trend analysis
            st.markdown("### Trend Analysis")
            
            # Display AQI trend
            display_trend_chart(
                "air", 
                "aqi", 
                location, 
                time_period,
                "Air Quality Index Trend",
                "AQI"
            )
            
            # Allow selecting specific pollutant
            if 'pollutants' in air_data and air_data['pollutants']:
                pollutant_names = list(air_data['pollutants'].keys())
                
                if pollutant_names:
                    selected_pollutant = st.selectbox(
                        "Select pollutant to view trend:",
                        pollutant_names
                    )
                    
                    display_trend_chart(
                        "air", 
                        f"pollutants.{selected_pollutant}", 
                        location, 
                        time_period,
                        f"{selected_pollutant} Level Trend",
                        "Level"
                    )
            
            # Health recommendations
            if 'recommendations' in air_data and air_data['recommendations']:
                st.markdown("### Health Recommendations")
                
                for rec in air_data['recommendations']:
                    st.info(rec)
            
        else:
            st.error(f"Failed to load air quality data: {air_data}")

def display_analysis_panel(location, time_period):
    """Display analytics and reporting panel"""
    st.header("Analysis & Reports")
    
    if location:
        st.subheader(f"Location: {location}")
    else:
        st.subheader("All Monitored Locations")
    
    # Correlation analysis
    st.markdown("### Pollution Correlation Analysis")
    
    with st.spinner("Analyzing pollution correlation..."):
        success, correlation_data = analyze_pollution_correlation(location)
        
        if success:
            # Display correlation metrics
            col1, col2 = st.columns(2)
            
            with col1:
                st.metric(
                    label="Water-Air Correlation", 
                    value=f"{correlation_data.get('water_air_correlation', 'N/A'):.2f}"
                )
            
            with col2:
                st.metric(
                    label="Causality Confidence", 
                    value=f"{correlation_data.get('causality_confidence', 'N/A'):.2%}"
                )
            
            # Display correlation matrix if available
            if 'correlation_matrix' in correlation_data:
                matrix = correlation_data['correlation_matrix']
                
                if matrix:
                    # Convert matrix to DataFrame
                    matrix_df = pd.DataFrame(matrix)
                    
                    # Create heatmap
                    fig = px.imshow(
                        matrix_df,
                        labels=dict(x="Parameter", y="Parameter", color="Correlation"),
                        x=matrix_df.columns,
                        y=matrix_df.columns,
                        color_continuous_scale="RdBu_r",
                        title="Pollution Parameter Correlation Matrix"
                    )
                    
                    st.plotly_chart(fig, use_container_width=True)
            
            # Display insights if available
            if 'insights' in correlation_data and correlation_data['insights']:
                st.markdown("#### Key Insights")
                
                for insight in correlation_data['insights']:
                    st.write(f"• {insight}")
        else:
            st.error(f"Failed to analyze pollution correlation: {correlation_data}")
    
    # Generate comprehensive report
    st.markdown("### Pollution Reports")
    
    report_col1, report_col2 = st.columns([2, 1])
    
    with report_col1:
        report_types = st.multiselect(
            "Select data to include in report:",
            ["Water Quality", "Air Quality", "Health Impacts", "Recommendations"],
            default=["Water Quality", "Air Quality"]
        )
    
    with report_col2:
        if st.button("Generate Report"):
            if location:
                with st.spinner("Generating comprehensive pollution report..."):
                    # Convert selections to API format
                    data_types = []
                    if "Water Quality" in report_types:
                        data_types.append("water")
                    if "Air Quality" in report_types:
                        data_types.append("air")
                    if "Health Impacts" in report_types:
                        data_types.append("health")
                    if "Recommendations" in report_types:
                        data_types.append("recommendations")
                    
                    success, report_data = generate_pollution_report(location, data_types)
                    
                    if success:
                        st.markdown("#### Generated Report")
                        
                        # Display report sections
                        if 'summary' in report_data:
                            st.markdown("**Summary**")
                            st.write(report_data['summary'])
                        
                        if 'sections' in report_data:
                            for section in report_data['sections']:
                                st.markdown(f"**{section.get('title', 'Section')}**")
                                st.write(section.get('content', 'No content'))
                        
                        # Download option
                        st.download_button(
                            label="Download Report (JSON)",
                            data=json.dumps(report_data, indent=2),
                            file_name=f"pollution_report_{datetime.now().strftime('%Y%m%d')}.json",
                            mime="application/json"
                        )
                    else:
                        st.error(f"Failed to generate report: {report_data}")
            else:
                st.warning("Please select a specific location to generate a report.")
    
    # AI-powered analysis
    st.markdown("### DeepSeek AI Analysis")
    
    analysis_query = st.text_area(
        "Ask a question about pollution data:",
        placeholder="E.g., What are the likely health impacts of the current air quality in Cape Town?",
        height=100
    )
    
    if st.button("Analyze"):
        if analysis_query:
            with st.spinner("Analyzing with DeepSeek AI..."):
                # Gather context data from both water and air
                context_data = {}
                
                # Add water data if available
                water_success, water_data = get_water_pollution_metrics(location)
                if water_success:
                    context_data['water'] = water_data
                
                # Add air data if available
                air_success, air_data = get_air_quality_metrics(location)
                if air_success:
                    context_data['air'] = air_data
                
                # Get AI analysis
                success, analysis = get_pollution_analysis(analysis_query, context_data)
                
                if success:
                    st.markdown("#### Analysis Results")
                    st.write(analysis)
                else:
                    st.error(f"Failed to analyze query: {analysis}")
        else:
            st.warning("Please enter a question to analyze.")

def display_trend_chart(data_type, metric, location, time_period, title, y_label, reference_range=None):
    """
    Display a trend chart for a specific metric.
    
    Args:
        data_type (str): 'water' or 'air'
        metric (str): Metric to display
        location (str): Location
        time_period (str): Time period to display
        title (str): Chart title
        y_label (str): Y-axis label
        reference_range (list, optional): Normal range to highlight [min, max]
    """
    # Convert time period to days
    days = 7  # Default to a week
    
    if time_period == "Last 24 hours":
        days = 1
    elif time_period == "Last 7 days":
        days = 7
    elif time_period == "Last 30 days":
        days = 30
    elif time_period == "Last 90 days":
        days = 90
    
    # Get trend data
    success, trend_df = get_trend_data(data_type, metric, location, days)
    
    if success and not trend_df.empty:
        # Make sure we have date and value columns
        if 'date' in trend_df.columns and 'value' in trend_df.columns:
            # Convert date column to datetime if it's not already
            if not pd.api.types.is_datetime64_any_dtype(trend_df['date']):
                trend_df['date'] = pd.to_datetime(trend_df['date'])
            
            # Sort by date
            trend_df = trend_df.sort_values('date')
            
            # Create the base figure
            fig = px.line(
                trend_df,
                x='date',
                y='value',
                title=title,
                labels={'date': 'Date', 'value': y_label}
            )
            
            # Add reference range if provided
            if reference_range:
                min_val, max_val = reference_range
                
                # Add shading for normal range
                fig.add_shape(
                    type="rect",
                    x0=trend_df['date'].min(),
                    x1=trend_df['date'].max(),
                    y0=min_val,
                    y1=max_val,
                    fillcolor="lightgreen",
                    opacity=0.2,
                    layer="below",
                    line_width=0
                )
                
                # Add reference lines
                fig.add_hline(
                    y=min_val,
                    line_dash="dash",
                    line_color="green",
                    annotation_text=f"Min normal: {min_val}",
                    annotation_position="bottom right"
                )
                
                fig.add_hline(
                    y=max_val,
                    line_dash="dash",
                    line_color="green",
                    annotation_text=f"Max normal: {max_val}",
                    annotation_position="top right"
                )
            
            # Show the chart
            st.plotly_chart(fig, use_container_width=True)
            
            # Also display statistics
            with st.expander("Show statistics"):
                stats_col1, stats_col2, stats_col3 = st.columns(3)
                
                with stats_col1:
                    st.metric("Average", f"{trend_df['value'].mean():.2f}")
                
                with stats_col2:
                    st.metric("Minimum", f"{trend_df['value'].min():.2f}")
                
                with stats_col3:
                    st.metric("Maximum", f"{trend_df['value'].max():.2f}")
        else:
            st.error("Trend data is missing required columns (date and/or value)")
    else:
        st.info(f"No trend data available for {metric}")
        if not success:
            st.error(f"Error retrieving trend data: {trend_df}")