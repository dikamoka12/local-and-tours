import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from utils.multilingual import get_text, get_current_language

def app():
    """Air Pollution page with information about causes and dangerous chemicals"""
    st.title("Air Pollution: Causes and Harmful Chemicals")
    
    # Add South African Water Systems Header
    st.markdown("<div style='background-color:#1E3B70; padding:10px; border-radius:5px; margin-bottom:20px;'><h2 style='color:white; text-align:center;'>SOUTH AFRICAN WATER SYSTEMS - TOURISTS AND LOCALS</h2></div>", unsafe_allow_html=True)
    
    st.markdown("""
    ## Understanding Air Pollution
    
    Air pollution refers to the release of pollutants into the air that are detrimental to human health and the planet as a whole. 
    These pollutants can be in the form of gases or particles and can have natural or human-made (anthropogenic) sources.
    
    This page provides comprehensive information about the major causes of air pollution and the dangerous chemicals they produce.
    """)
    
    # Add a visualization for global air pollution sources
    st.subheader("Major Contributors to Global Air Pollution")
    
    col1, col2 = st.columns([3, 2])
    
    with col1:
        # Sample data for visualization
        pollution_sources = {
            "Industrial Emissions": 28,
            "Transportation": 25,
            "Power Generation": 22,
            "Agricultural Activities": 10,
            "Residential Heating & Cooking": 8,
            "Waste Management": 4,
            "Natural Sources": 3
        }
        
        # Create a bar chart
        source_df = pd.DataFrame({
            "Source": list(pollution_sources.keys()),
            "Percentage": list(pollution_sources.values())
        })
        
        fig = px.bar(
            source_df, 
            x="Percentage", 
            y="Source", 
            orientation='h',
            color="Percentage",
            color_continuous_scale=["green", "yellow", "orange", "red"],
            title="Global Air Pollution Sources (Estimated Contribution %)",
        )
        
        fig.update_layout(yaxis={'categoryorder':'total ascending'})
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        st.markdown("""
        ### Key Pollutant Types
        
        Air pollutants are typically classified into:
        
        - **Primary pollutants**: Emitted directly from a source
        - **Secondary pollutants**: Formed when primary pollutants react in the atmosphere
        
        Most harmful air pollutants are regulated by environmental agencies worldwide, with concentration limits established for public health protection.
        """)
        
        # Create a pie chart showing pollutant distribution by type
        pollutant_types = {
            "Particulate Matter": 35,
            "Nitrogen Oxides": 20,
            "Sulfur Dioxide": 15,
            "Volatile Organic Compounds": 15,
            "Carbon Monoxide": 8,
            "Heavy Metals": 4,
            "Others": 3
        }
        
        fig2 = px.pie(
            names=list(pollutant_types.keys()),
            values=list(pollutant_types.values()),
            title="Global Distribution of Major Air Pollutants",
            color_discrete_sequence=px.colors.qualitative.Set3
        )
        
        fig2.update_traces(textposition='inside', textinfo='percent+label')
        fig2.update_layout(legend=dict(orientation="h", yanchor="bottom", y=-0.2, xanchor="center", x=0.5))
        st.plotly_chart(fig2, use_container_width=True)
    
    # Add South Africa AQI visualization
    st.subheader("Air Quality Index (AQI) in Major South African Cities")
    
    # Sample AQI data for South African cities (WHO standards)
    sa_cities_aqi = {
        "Johannesburg": {"PM2.5": 32, "PM10": 48, "NO2": 21, "SO2": 18, "O3": 45, "Overall_AQI": 65},
        "Cape Town": {"PM2.5": 16, "PM10": 28, "NO2": 15, "SO2": 8, "O3": 38, "Overall_AQI": 38},
        "Durban": {"PM2.5": 22, "PM10": 35, "NO2": 18, "SO2": 12, "O3": 30, "Overall_AQI": 45},
        "Pretoria": {"PM2.5": 29, "PM10": 42, "NO2": 24, "SO2": 15, "O3": 48, "Overall_AQI": 58},
        "Port Elizabeth": {"PM2.5": 14, "PM10": 25, "NO2": 12, "SO2": 7, "O3": 25, "Overall_AQI": 31},
        "Bloemfontein": {"PM2.5": 19, "PM10": 34, "NO2": 14, "SO2": 9, "O3": 32, "Overall_AQI": 40},
        "Mpumalanga Highveld": {"PM2.5": 38, "PM10": 56, "NO2": 28, "SO2": 42, "O3": 52, "Overall_AQI": 85},
        "Vaal Triangle": {"PM2.5": 35, "PM10": 54, "NO2": 25, "SO2": 38, "O3": 50, "Overall_AQI": 78}
    }
    
    # Create dataframe for AQI
    aqi_df = pd.DataFrame({
        "City": list(sa_cities_aqi.keys()),
        "AQI": [city_data["Overall_AQI"] for city_data in sa_cities_aqi.values()]
    })
    
    # Add AQI categories
    def get_aqi_category(aqi):
        if aqi <= 50:
            return "Good"
        elif aqi <= 100:
            return "Moderate"
        elif aqi <= 150:
            return "Unhealthy for Sensitive Groups"
        elif aqi <= 200:
            return "Unhealthy"
        elif aqi <= 300:
            return "Very Unhealthy"
        else:
            return "Hazardous"
    
    aqi_df["Category"] = aqi_df["AQI"].apply(get_aqi_category)
    
    # Create AQI color map
    aqi_colors = {
        "Good": "green", 
        "Moderate": "yellow", 
        "Unhealthy for Sensitive Groups": "orange",
        "Unhealthy": "red", 
        "Very Unhealthy": "purple", 
        "Hazardous": "maroon"
    }
    
    aqi_df["Color"] = aqi_df["Category"].map(aqi_colors)
    
    # Create the bar chart
    fig3 = px.bar(
        aqi_df.sort_values("AQI", ascending=False),
        x="City",
        y="AQI",
        color="Category",
        color_discrete_map=aqi_colors,
        title="Air Quality Index in South African Cities",
        hover_data=["Category"]
    )
    
    # Add reference lines for AQI categories
    fig3.add_shape(type="line", x0=-0.5, x1=7.5, y0=50, y1=50, line=dict(color="green", width=1, dash="dash"))
    fig3.add_shape(type="line", x0=-0.5, x1=7.5, y0=100, y1=100, line=dict(color="orange", width=1, dash="dash"))
    fig3.add_shape(type="line", x0=-0.5, x1=7.5, y0=150, y1=150, line=dict(color="red", width=1, dash="dash"))
    
    # Annotations for AQI categories
    fig3.add_annotation(x=7, y=25, text="Good", showarrow=False, font=dict(color="green"))
    fig3.add_annotation(x=7, y=75, text="Moderate", showarrow=False, font=dict(color="orange"))
    fig3.add_annotation(x=7, y=125, text="Unhealthy for Sensitive Groups", showarrow=False, font=dict(color="red"))
    
    st.plotly_chart(fig3, use_container_width=True)
    
    # Add interpretation
    st.info("""
    **Air Quality Index (AQI) Interpretation**
    
    - **Good (0-50)**: Air quality is satisfactory with little or no risk to health
    - **Moderate (51-100)**: Acceptable air quality but may cause moderate health concerns for a small number of individuals
    - **Unhealthy for Sensitive Groups (101-150)**: Members of sensitive groups may experience health effects
    - **Unhealthy (151-200)**: Everyone may begin to experience health effects
    - **Very Unhealthy (201-300)**: Health alert - everyone may experience more serious health effects
    - **Hazardous (301+)**: Health warning of emergency conditions - entire population is likely to be affected
    """)
    
    # Create tabs for different sections
    tab1, tab2, tab3, tab4 = st.tabs(["Major Causes", "Harmful Chemicals", "Health Effects", "Environmental Impact"])
    
    with tab1:
        st.header("Major Causes of Air Pollution")
        
        causes = [
            {
                "category": "Industrial Activities",
                "sources": [
                    "Manufacturing facilities",
                    "Power plants (coal, oil, natural gas)",
                    "Mining operations",
                    "Oil refineries",
                    "Chemical production facilities",
                    "Cement production",
                    "Metal processing and smelting",
                    "Paper and pulp mills"
                ],
                "details": "Industrial processes release numerous pollutants through combustion, chemical reactions, and material processing. These facilities often have smokestacks that release pollutants directly into the atmosphere."
            },
            {
                "category": "Transportation",
                "sources": [
                    "Vehicles with internal combustion engines (cars, trucks, buses)",
                    "Aircraft emissions",
                    "Marine vessels and shipping",
                    "Trains (diesel-powered)",
                    "Off-road vehicles and equipment"
                ],
                "details": "The combustion of fossil fuels in vehicles produces significant amounts of air pollutants. Vehicle emissions are often concentrated in urban areas and along major transportation corridors."
            },
            {
                "category": "Agricultural Activities",
                "sources": [
                    "Livestock farming (methane from animal waste)",
                    "Application of fertilizers (ammonia)",
                    "Pesticide use",
                    "Agricultural waste burning",
                    "Soil management practices"
                ],
                "details": "Modern agricultural practices can release various pollutants, including ammonia from fertilizers, methane from livestock, and particulates from field burning."
            },
            {
                "category": "Residential Sources",
                "sources": [
                    "Household heating (wood, coal, oil)",
                    "Cooking with solid fuels (biomass, coal)",
                    "Use of consumer products (solvents, paints, cleaners)",
                    "Residential waste burning",
                    "Construction and demolition"
                ],
                "details": "In many regions, especially developing countries, residential activities like cooking and heating with solid fuels are major contributors to air pollution."
            },
            {
                "category": "Natural Sources",
                "sources": [
                    "Volcanic eruptions",
                    "Forest fires",
                    "Dust storms",
                    "Biological decay",
                    "Sea spray (salt aerosols)",
                    "Pollen and spores"
                ],
                "details": "Natural processes can release significant pollutants into the atmosphere, though these are generally considered part of Earth's natural cycles."
            },
            {
                "category": "Waste Management",
                "sources": [
                    "Landfills (methane emissions)",
                    "Waste incineration",
                    "Sewage treatment",
                    "Open waste burning"
                ],
                "details": "The decomposition of organic waste and burning of trash release methane, carbon dioxide, and various toxic compounds."
            },
            {
                "category": "Energy Production",
                "sources": [
                    "Coal-fired power plants",
                    "Oil and gas power generation",
                    "Biomass burning for energy",
                    "Fugitive emissions from fossil fuel extraction and processing"
                ],
                "details": "The generation of electricity through fossil fuel combustion is one of the largest contributors to air pollution globally."
            }
        ]
        
        for cause in causes:
            with st.expander(f"{cause['category']}"):
                st.subheader("Common Sources")
                for source in cause["sources"]:
                    st.markdown(f"- {source}")
                st.markdown(f"**Details**: {cause['details']}")
    
    with tab2:
        st.header("Harmful Chemicals and Pollutants")
        
        chemicals = [
            {
                "category": "Criteria Air Pollutants",
                "pollutants": [
                    {
                        "name": "Particulate Matter (PM2.5 and PM10)",
                        "sources": "Combustion (vehicles, power plants, industrial processes), construction, road dust, agricultural operations",
                        "description": "Microscopic solid or liquid particles suspended in air. PM2.5 (diameter < 2.5 μm) can penetrate deep into lungs and even enter bloodstream.",
                        "health_effects": "Respiratory and cardiovascular diseases, lung cancer, premature death",
                        "environmental_effects": "Reduced visibility (haze), acid deposition, plant damage, soil nutrient imbalance"
                    },
                    {
                        "name": "Ground-level Ozone (O₃)",
                        "sources": "Not directly emitted but formed by chemical reactions between NOx and VOCs in sunlight",
                        "description": "A secondary pollutant formed through photochemical reactions, main component of smog",
                        "health_effects": "Respiratory issues, reduced lung function, asthma attacks, inflammation of lung tissue",
                        "environmental_effects": "Damage to vegetation, reduced plant growth, decreased agricultural yields"
                    },
                    {
                        "name": "Nitrogen Oxides (NOx)",
                        "sources": "Vehicle emissions, power plants, industrial boilers, agricultural burning",
                        "description": "Group of gases including nitrogen dioxide (NO₂) and nitric oxide (NO)",
                        "health_effects": "Respiratory inflammation, reduced lung function, increased susceptibility to respiratory infections",
                        "environmental_effects": "Acid rain, nutrient pollution in water bodies, smog formation, ozone depletion"
                    },
                    {
                        "name": "Sulfur Dioxide (SO₂)",
                        "sources": "Fossil fuel combustion, smelting operations, volcanic activity",
                        "description": "Colorless gas with sharp odor, precursor to sulfuric acid and sulfate particles",
                        "health_effects": "Respiratory irritation, breathing difficulties, aggravated asthma",
                        "environmental_effects": "Acid rain, vegetation damage, regional haze"
                    },
                    {
                        "name": "Carbon Monoxide (CO)",
                        "sources": "Incomplete combustion (vehicles, heating systems, industrial processes)",
                        "description": "Colorless, odorless gas produced by incomplete combustion of carbon-containing fuels",
                        "health_effects": "Reduces oxygen delivery to body organs, particularly dangerous for heart patients",
                        "environmental_effects": "Contributes to ground-level ozone formation"
                    },
                    {
                        "name": "Lead (Pb)",
                        "sources": "Metal processing, leaded aviation fuel, waste incineration, historical use in paint and gasoline",
                        "description": "Heavy metal that accumulates in the environment and human body",
                        "health_effects": "Neurodevelopmental effects in children, cardiovascular effects in adults, kidney damage",
                        "environmental_effects": "Bioaccumulation in ecosystems, soil contamination, harm to aquatic life"
                    }
                ]
            },
            {
                "category": "Hazardous Air Pollutants (HAPs)/Toxic Air Pollutants",
                "pollutants": [
                    {
                        "name": "Benzene",
                        "sources": "Vehicle emissions, industrial processes, tobacco smoke, gasoline evaporation",
                        "description": "Colorless, sweet-smelling volatile organic compound (VOC)",
                        "health_effects": "Known human carcinogen (leukemia), blood disorders, immune system damage",
                        "environmental_effects": "Contributes to smog formation, toxic to aquatic life"
                    },
                    {
                        "name": "Formaldehyde",
                        "sources": "Building materials, combustion processes, vehicle exhaust, some consumer products",
                        "description": "Colorless gas with strong odor, used in many manufacturing processes",
                        "health_effects": "Respiratory irritation, eye irritation, classified as human carcinogen",
                        "environmental_effects": "Contributes to smog formation"
                    },
                    {
                        "name": "Mercury",
                        "sources": "Coal combustion, waste incineration, certain industrial processes, mining",
                        "description": "Heavy metal that exists in various forms (elemental, inorganic, organic)",
                        "health_effects": "Neurotoxicity, particularly during fetal development; affects brain, kidneys",
                        "environmental_effects": "Bioaccumulation in food chain, particularly in aquatic ecosystems"
                    },
                    {
                        "name": "Dioxins and Furans",
                        "sources": "Waste incineration, certain industrial processes, forest fires, backyard burning",
                        "description": "Group of chemically-related compounds, highly persistent in environment",
                        "health_effects": "Cancer, reproductive and developmental problems, immune system damage",
                        "environmental_effects": "Extremely persistent in environment, bioaccumulate in food chain"
                    },
                    {
                        "name": "Polycyclic Aromatic Hydrocarbons (PAHs)",
                        "sources": "Incomplete combustion (vehicle exhaust, wood burning, grilling, smoking)",
                        "description": "Group of chemicals formed during incomplete burning of organic matter",
                        "health_effects": "Several PAHs are known or suspected carcinogens, reproductive toxicity",
                        "environmental_effects": "Persistent in environment, toxic to aquatic organisms"
                    },
                    {
                        "name": "Cadmium",
                        "sources": "Metal production, battery manufacturing, pigment production, waste incineration",
                        "description": "Toxic heavy metal that accumulates in the body over time",
                        "health_effects": "Kidney damage, bone disease, lung damage, may cause cancer",
                        "environmental_effects": "Toxic to plants, animals, and microorganisms"
                    },
                    {
                        "name": "Arsenic",
                        "sources": "Metal smelting, coal combustion, pesticide use, wood preservatives",
                        "description": "Naturally occurring element that becomes concentrated through industrial activities",
                        "health_effects": "Known human carcinogen, cardiovascular disease, neurological effects",
                        "environmental_effects": "Toxic to plants and animals, can persist in soils"
                    }
                ]
            },
            {
                "category": "Greenhouse Gases",
                "pollutants": [
                    {
                        "name": "Carbon Dioxide (CO₂)",
                        "sources": "Fossil fuel combustion, deforestation, cement production, respiration",
                        "description": "Naturally occurring gas that is also a major byproduct of human activities",
                        "health_effects": "Not directly toxic at typical atmospheric concentrations",
                        "environmental_effects": "Primary greenhouse gas contributing to climate change"
                    },
                    {
                        "name": "Methane (CH₄)",
                        "sources": "Natural gas systems, livestock, landfills, wetlands, rice cultivation",
                        "description": "Potent greenhouse gas with 25+ times the global warming potential of CO₂ over 100 years",
                        "health_effects": "Not directly toxic at typical atmospheric concentrations",
                        "environmental_effects": "Significant contributor to climate change, precursor to ground-level ozone"
                    },
                    {
                        "name": "Nitrous Oxide (N₂O)",
                        "sources": "Agricultural soils, livestock waste, fossil fuel combustion, industrial processes",
                        "description": "Greenhouse gas with 298 times the global warming potential of CO₂ over 100 years",
                        "health_effects": "Not directly toxic at typical atmospheric concentrations",
                        "environmental_effects": "Significant contributor to climate change, ozone depletion in stratosphere"
                    },
                    {
                        "name": "Fluorinated Gases (HFCs, PFCs, SF₆)",
                        "sources": "Refrigeration, air conditioning, semiconductor manufacturing, electrical transmission",
                        "description": "Synthetic gases with extremely high global warming potentials (hundreds to thousands times that of CO₂)",
                        "health_effects": "Generally low toxicity at typical concentrations",
                        "environmental_effects": "Very potent greenhouse gases, extremely long atmospheric lifetimes"
                    }
                ]
            },
            {
                "category": "Volatile Organic Compounds (VOCs)",
                "pollutants": [
                    {
                        "name": "Toluene",
                        "sources": "Paints, paint thinners, fingernail polish, lacquers, adhesives, rubber, printing",
                        "description": "Colorless liquid with sweet, pungent odor",
                        "health_effects": "Neurological symptoms, respiratory irritation, reproductive effects",
                        "environmental_effects": "Contributes to ground-level ozone formation"
                    },
                    {
                        "name": "Xylenes",
                        "sources": "Gasoline, vehicle exhaust, paints, varnishes, shellac",
                        "description": "Sweet-smelling colorless liquids",
                        "health_effects": "Neurological effects, irritation, affects memory and concentration",
                        "environmental_effects": "Contributes to ground-level ozone formation"
                    },
                    {
                        "name": "Styrene",
                        "sources": "Plastic and rubber manufacturing, insulation, fiberglass, pipe resins, food containers",
                        "description": "Colorless to yellowish liquid with sweet odor at low concentrations",
                        "health_effects": "Nervous system effects, respiratory effects, possible carcinogen",
                        "environmental_effects": "Contributes to ground-level ozone formation"
                    },
                    {
                        "name": "Perchloroethylene (Tetrachloroethylene)",
                        "sources": "Dry cleaning, textile processing, metal degreasing",
                        "description": "Colorless liquid with mild, chloroform-like odor",
                        "health_effects": "Neurological, liver, and kidney effects; possible carcinogen",
                        "environmental_effects": "Persistent in environment, can contaminate groundwater"
                    }
                ]
            }
        ]
        
        for chem_category in chemicals:
            st.subheader(chem_category["category"])
            
            for pollutant in chem_category["pollutants"]:
                with st.expander(pollutant["name"]):
                    st.markdown(f"**Sources**: {pollutant['sources']}")
                    st.markdown(f"**Description**: {pollutant['description']}")
                    st.markdown(f"**Health Effects**: {pollutant['health_effects']}")
                    st.markdown(f"**Environmental Effects**: {pollutant['environmental_effects']}")
    
    with tab3:
        st.header("Health Effects of Air Pollution")
        
        st.markdown("""
        Air pollution exposure has both acute (short-term) and chronic (long-term) effects on human health, 
        affecting nearly every organ system in the human body.
        """)
        
        health_effects = {
            "Respiratory System": [
                "Asthma development and exacerbation",
                "Chronic obstructive pulmonary disease (COPD)",
                "Reduced lung function",
                "Increased respiratory infections",
                "Pulmonary inflammation",
                "Lung cancer"
            ],
            "Cardiovascular System": [
                "Increased risk of heart attacks",
                "Stroke",
                "Heart rhythm disturbances (arrhythmias)",
                "Vascular inflammation",
                "Atherosclerosis (hardening of arteries)",
                "Hypertension (high blood pressure)"
            ],
            "Nervous System": [
                "Cognitive decline and dementia",
                "Developmental delays in children",
                "Neurodegenerative diseases (Alzheimer's, Parkinson's)",
                "Behavioral problems",
                "Reduced IQ in children exposed during development"
            ],
            "Reproductive System": [
                "Reduced fertility",
                "Pregnancy complications",
                "Low birth weight",
                "Preterm birth",
                "Birth defects",
                "Impaired fetal growth"
            ],
            "Other Organ Systems": [
                "Kidney damage and increased risk of kidney disease",
                "Liver damage",
                "Metabolic disorders (including diabetes)",
                "Immune system dysregulation",
                "Eye irritation and increased risk of cataracts",
                "Skin aging and disorders"
            ],
            "Mental Health": [
                "Depression",
                "Anxiety",
                "Psychological stress",
                "Cognitive performance reduction"
            ],
            "Vulnerable Populations": [
                "Children: Developing organs particularly vulnerable",
                "Elderly: Decreased respiratory and immune functions",
                "Pregnant women: Risks to mother and developing fetus",
                "People with pre-existing conditions: Amplified health impacts",
                "Low-income communities: Often face higher exposure levels"
            ]
        }
        
        for system, effects in health_effects.items():
            with st.expander(system):
                for effect in effects:
                    st.markdown(f"- {effect}")
    
    with tab4:
        st.header("Environmental Impact of Air Pollution")
        
        environmental_effects = {
            "Ecosystem Effects": [
                "Acidification of lakes and streams (from acid deposition)",
                "Nutrient imbalances in soils and water bodies",
                "Damage to forests and other vegetation",
                "Reduced biodiversity",
                "Disruption of nitrogen cycle",
                "Eutrophication of water bodies"
            ],
            "Climate Change": [
                "Global warming from greenhouse gases",
                "Altered precipitation patterns",
                "Increased frequency and intensity of extreme weather events",
                "Rising sea levels",
                "Melting of polar ice caps and glaciers",
                "Ocean acidification"
            ],
            "Agricultural Impacts": [
                "Reduced crop yields and quality",
                "Changes in pest and disease patterns",
                "Damage to plant tissues from ozone and other pollutants",
                "Reduced photosynthesis efficiency",
                "Soil degradation"
            ],
            "Built Environment": [
                "Deterioration of building materials",
                "Corrosion of metals",
                "Discoloration of painted surfaces",
                "Damage to cultural heritage sites and monuments",
                "Reduced infrastructure lifespan"
            ],
            "Visibility Impairment": [
                "Reduced visibility in scenic areas (national parks, protected areas)",
                "Urban haze",
                "Disruption of transportation (air travel, road traffic)",
                "Aesthetic degradation of landscapes"
            ],
            "Stratospheric Ozone Depletion": [
                "Thinning of protective ozone layer in stratosphere",
                "Increased UV radiation reaching earth's surface",
                "Damage to marine ecosystems",
                "Effects on terrestrial plant growth",
                "Increased human health risks (skin cancer, cataracts)"
            ]
        }
        
        for category, effects in environmental_effects.items():
            with st.expander(category):
                for effect in effects:
                    st.markdown(f"- {effect}")
    
    st.header("Global Air Pollution Hotspots")
    st.markdown("""
    While air pollution affects the entire planet, certain regions experience particularly high levels due to 
    industrial activity, population density, geographical features, and regulatory environments:
    
    - **Northern India and Bangladesh**: Combination of industrial emissions, vehicle exhaust, crop burning, and geographical factors
    - **Northern China**: Heavy industry, coal power, winter heating, and topographical features trapping pollutants
    - **Central and Western Africa**: High levels of particulate matter from dust, biomass burning, and increasing industrialization
    - **Southeast Asia**: Rapid industrialization, vehicle emissions, and agricultural burning
    - **Eastern Europe**: Aging industrial infrastructure and coal dependence
    - **Major urban centers worldwide**: Megacities like Mexico City, Cairo, Jakarta, and São Paulo
    
    It's important to note that air pollution is a global issue, and even areas with relatively clean air 
    can experience significant pollution events and long-range transport of pollutants.
    """)
    
    st.header("Air Pollution in South Africa")
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.markdown("""
        ### Key Air Pollution Challenges in South Africa
        
        South Africa faces unique air pollution challenges related to its energy sector, mining industry, and socioeconomic conditions:
        
        1. **Coal-Based Energy Production**: 
           - South Africa relies heavily on coal for electricity generation
           - Eskom power stations in the Highveld region are major sources of SO₂, NOx, and particulate matter
           - The Mpumalanga province contains most of these facilities, creating a pollution hotspot
        
        2. **Mining Activity**:
           - Mining operations release dust containing heavy metals and other pollutants
           - Mine dumps and tailings create ongoing sources of windblown dust
           - Gold, platinum, and coal mining areas experience higher pollutant levels
        
        3. **Indoor Air Pollution**:
           - Use of biomass fuels (wood, dung, crop residues) for cooking and heating in rural areas
           - Disproportionately affects women and children who spend more time indoors
           - Contributes to respiratory diseases and other health issues
        
        4. **Urban Vehicle Emissions**:
           - Growing vehicle numbers in major cities like Johannesburg, Cape Town, and Durban
           - Aging transportation fleet with less efficient emission controls
           - Traffic congestion exacerbating the problem
        
        5. **Industrial Activities**:
           - Petrochemical facilities (particularly in areas like Sasolburg)
           - Manufacturing and processing plants
           - Heavy industry in certain industrial zones
        """)
    
    with col2:
        st.markdown("### Health Impact in South Africa")
        st.info("""
        - Respiratory diseases account for ~15% of deaths in children under 5
        - Areas near mining and industrial activities show higher rates of asthma, bronchitis, and other respiratory conditions
        - An estimated 20,000+ premature deaths annually are attributed to air pollution
        - Economic cost of air pollution estimated at 6% of GDP when accounting for healthcare and lost productivity
        """)
        
        st.markdown("### Priority Airsheds")
        st.warning("""
        The South African government has declared three priority areas due to poor air quality:
        
        - **Vaal Triangle Airshed** (including parts of Gauteng and Free State)
        - **Highveld Priority Area** (parts of Mpumalanga and Gauteng)
        - **Waterberg-Bojanala Priority Area** (parts of Limpopo and North West)
        """)
    
    st.subheader("Connection to Water Systems")
    st.markdown("""
    Air pollution directly impacts water quality in South Africa through various mechanisms:
    
    - **Acid rain** from sulfur dioxide and nitrogen oxides affects lakes, rivers, and soil pH
    - **Atmospheric deposition** of heavy metals and toxic compounds into water bodies
    - **Nutrient loading** (particularly nitrogen) from air pollutants can cause eutrophication
    - **Mercury** from coal burning eventually enters the water system and can bioaccumulate in fish
    
    These air-to-water pollution pathways highlight the interconnection between different environmental systems
    and the need for integrated approaches to pollution management.
    """)
    
    # Interactive section for users to check air pollution in their area
    st.header("Check Air Pollution in Your Area")
    
    st.markdown("""
    Use this section to check the approximate air quality in your area. This can help you understand the potential health risks 
    and take appropriate precautions.
    """)
    
    col1, col2 = st.columns([1, 1])
    
    with col1:
        location_options = [
            "Johannesburg", "Cape Town", "Durban", "Pretoria", "Bloemfontein", 
            "Port Elizabeth", "Mpumalanga Highveld", "Vaal Triangle", 
            "Other (South Africa)", "International Location"
        ]
        
        selected_location = st.selectbox("Select your location:", location_options)
        
        if selected_location == "Other (South Africa)" or selected_location == "International Location":
            custom_location = st.text_input("Enter your city or region:")
        
        pollution_concern = st.selectbox(
            "What's your main pollution concern?",
            ["General Air Quality", "Vehicle Emissions", "Industrial Pollution", 
             "Indoor Air Quality", "Allergens and Pollen", "Wildfire Smoke"]
        )
        
        vulnerable_groups = st.multiselect(
            "Do you have vulnerable individuals in your household?",
            ["Children under 12", "Elderly (65+)", "Pregnant women", 
             "People with asthma", "People with heart conditions", "People with respiratory conditions"]
        )
        
        submit_button = st.button("Check Air Quality")
    
    with col2:
        st.markdown("### Personalized Results")
        
        if 'submit_button' in locals() and submit_button:
            location_to_use = selected_location
            if selected_location == "Other (South Africa)" or selected_location == "International Location":
                if 'custom_location' in locals() and custom_location:
                    location_to_use = custom_location
                else:
                    location_to_use = "Unknown Location"
            
            # Get AQI for the selected location from our data or default to moderate if not available
            if location_to_use in sa_cities_aqi:
                aqi_value = sa_cities_aqi[location_to_use]["Overall_AQI"]
                aqi_category = get_aqi_category(aqi_value)
                
                # Specific pollutant details
                pm25_level = sa_cities_aqi[location_to_use]["PM2.5"]
                no2_level = sa_cities_aqi[location_to_use]["NO2"]
                o3_level = sa_cities_aqi[location_to_use]["O3"]
            else:
                # Default values for locations not in our database
                aqi_value = 65  # Default to moderate
                aqi_category = "Moderate"
                pm25_level = 25
                no2_level = 18
                o3_level = 40
            
            # Display the results with appropriate color coding
            aqi_color = aqi_colors.get(aqi_category, "gray")
            
            st.markdown(f"### Air Quality in {location_to_use}")
            st.markdown(f"**Current AQI:** <span style='color:{aqi_color};font-weight:bold;'>{aqi_value} ({aqi_category})</span>", unsafe_allow_html=True)
            
            # Display specific pollutant levels
            st.markdown("#### Key Pollutant Levels")
            st.markdown(f"- **PM2.5:** {pm25_level} μg/m³")
            st.markdown(f"- **NO₂:** {no2_level} ppb")
            st.markdown(f"- **Ozone:** {o3_level} ppb")
            
            # Recommendations based on AQI and user selections
            st.markdown("### Recommendations")
            
            if aqi_category == "Good":
                st.success("The air quality in your area is good. It's safe for outdoor activities.")
            elif aqi_category == "Moderate":
                st.warning("Air quality is acceptable but may cause moderate health concerns for sensitive individuals.")
                if any(group in ["People with asthma", "People with respiratory conditions"] for group in vulnerable_groups):
                    st.warning("⚠️ Sensitive individuals should consider limiting prolonged outdoor exertion.")
            else:
                st.error("⚠️ Air quality is unhealthy. Consider limiting outdoor activities.")
                if vulnerable_groups:
                    st.error("⚠️ Vulnerable individuals should stay indoors with windows closed if possible.")
            
            # Specific advice based on pollution concern
            if pollution_concern == "Indoor Air Quality":
                st.info("""
                **Indoor Air Quality Tips:**
                - Use air purifiers with HEPA filters
                - Ensure proper ventilation when cooking
                - Avoid smoking indoors
                - Clean regularly to reduce dust
                - Check for and address mold issues
                """)
            elif pollution_concern == "Vehicle Emissions":
                st.info("""
                **Vehicle Emission Protection:**
                - Use cabin air filters in your vehicle
                - Avoid exercising near busy roads
                - Consider using back streets for walking/cycling
                - Keep car windows closed in heavy traffic
                """)
        else:
            st.info("Select your location and click 'Check Air Quality' to see personalized air quality information and recommendations.")
            
            # Display general air quality protective measures
            st.markdown("### General Protective Measures")
            st.markdown("""
            - Use air purifiers with HEPA filters in your home
            - Wear appropriate masks (N95/KN95) during high pollution days
            - Check daily air quality forecasts
            - Plan outdoor activities for times when pollution levels are lower
            - Keep windows closed during pollution events
            - Stay hydrated as this helps your body process pollutants
            """)
    
    st.header("Solutions and Mitigation Strategies")
    
    solutions = {
        "Policy and Regulatory Approaches": [
            "Emission standards for industries and vehicles",
            "Air quality monitoring networks",
            "Cap-and-trade systems for pollutants",
            "Phase-out of highly polluting substances",
            "Urban planning regulations",
            "International agreements on transboundary pollution"
        ],
        "Technological Solutions": [
            "Clean energy technologies (renewable energy)",
            "Energy efficiency improvements",
            "Advanced emission control systems",
            "Electric vehicles and alternative fuels",
            "Green building technologies",
            "Carbon capture and storage"
        ],
        "Individual Actions": [
            "Reducing energy consumption",
            "Using public transportation, cycling, or walking",
            "Proper maintenance of vehicles and heating systems",
            "Avoiding open burning of waste",
            "Using environmentally friendly consumer products",
            "Supporting clean air policies and regulations"
        ],
        "Agricultural Practices": [
            "Improved manure management",
            "Precision fertilizer application",
            "Alternatives to burning agricultural waste",
            "Agroforestry and sustainable farming practices",
            "Conservation tillage"
        ]
    }
    
    for category, approaches in solutions.items():
        with st.expander(category):
            for approach in approaches:
                st.markdown(f"- {approach}")
    
    st.markdown("""
    ---
    ### References and Further Reading
    
    - World Health Organization (WHO) Air Quality Guidelines
    - United States Environmental Protection Agency (EPA) Air Quality resources
    - Intergovernmental Panel on Climate Change (IPCC) reports
    - The Lancet Commission on Pollution and Health
    - State of Global Air reports
    """)
    
    # Add footer with SOUTH AFRICAN WATER SYSTEMS
    st.markdown("<br><br>", unsafe_allow_html=True)
    st.markdown("<div style='background-color:#1E3B70; padding:10px; border-radius:5px; margin-top:20px;'><h3 style='color:white; text-align:center;'>SOUTH AFRICAN WATER SYSTEMS - TOURISTS AND LOCALS</h3></div>", unsafe_allow_html=True)