import streamlit as st
import pandas as pd
import os
from utils.data_processor import load_water_sources_data
from utils.visualization import (
    create_interactive_community_map, 
    display_community_reporting_interface, 
    get_community_reports,
    display_report_details,
    display_report_moderation_interface
)
from utils.multilingual import get_text
from utils.authentication import is_subscription_active, get_user_details
import plotly.express as px
from datetime import datetime

def app():
    """Community Map page for viewing and reporting water quality issues"""
    st.title("Community Water Quality Map")
    
    # Introduction section
    st.markdown("""
    ### 🌊 Crowdsourced Water Quality Monitoring
    
    Together, we can monitor water quality more effectively! This interactive map combines official water quality 
    data with reports from community members like you. Help us expand our monitoring network by reporting 
    water quality issues in your area.
    
    * **Purple markers**: Community-reported water quality issues
    * **Yellow/Red markers**: Official water quality monitoring points
    """)
    
    # Display traditional knowledge message
    from utils.common import display_traditional_water_knowledge
    display_traditional_water_knowledge()
    
    # Load official water data
    try:
        water_sources_df = load_water_sources_data()
    except Exception as e:
        st.error(f"Error loading water sources data: {str(e)}")
        water_sources_df = pd.DataFrame()
    
    # Create tabs for map, reporting, viewing reports, and moderation (if admin)
    tabs = ["Interactive Map", "Report Water Quality Issue", "Browse Reports"]
    
    # Add moderation tab for admins/moderators
    is_admin = False
    if 'authentication_status' in st.session_state and st.session_state['authentication_status']:
        user_details = get_user_details(st.session_state['username'])
        if user_details and user_details.get('role') in ['admin', 'moderator']:
            tabs.append("Moderation")
            is_admin = True
    
    main_tabs = st.tabs(tabs)
    
    with main_tabs[0]:  # Interactive Map
        st.subheader("Interactive Community Water Quality Map")
        
        # Filters for the map
        col1, col2, col3 = st.columns(3)
        with col1:
            show_official = st.checkbox("Show Official Data", value=True)
        with col2:
            show_community = st.checkbox("Show Community Reports", value=True)
        with col3:
            min_pollution = st.slider("Minimum Pollution Level", 1, 10, 1)
        
        # Additional filters for community reports
        region_filter = None
        water_type_filter = "All Types"
        status_filter = "All Reports"
        
        if show_community:
            st.subheader("Community Report Filters")
            col1, col2 = st.columns(2)
            with col1:
                region_filter = st.text_input("Filter by Region/Province")
            with col2:
                water_type_filter = st.selectbox(
                    "Filter by Water Type", 
                    options=["All Types", "Rivers", "Dams", "Oceans", "Tap Water", "Underground Water", "Spring Water", "Others"]
                )
            
            col1, col2 = st.columns(2)
            with col1:
                status_filter = st.selectbox(
                    "Filter by Status",
                    options=["All Reports", "Verified Only", "Pending", "Rejected"]
                )
        
        # Create the interactive map
        try:
            # Process filters for community data
            region = region_filter if show_community and region_filter else None
            water_type = water_type_filter.lower() if show_community and water_type_filter != "All Types" else None
            
            status = None
            if show_community and status_filter != "All Reports":
                if status_filter == "Verified Only":
                    status = "verified"
                elif status_filter == "Pending":
                    status = "pending"
                elif status_filter == "Rejected":
                    status = "rejected"
            
            # Get filtered official data
            if show_official:
                filtered_df = water_sources_df[water_sources_df["pollution_level"] >= min_pollution] if not water_sources_df.empty else None
            else:
                filtered_df = None
            
            # Create the map with appropriate filters
            map_view = create_interactive_community_map(
                df=filtered_df,
                enable_reporting=False, 
                show_community=show_community,
                region=region,
                water_type=water_type,
                min_pollution_level=min_pollution,
                status=status
            )
            
            # Display the map
            st.pydeck_chart(map_view)
        except Exception as e:
            st.error(f"Error creating or displaying the map: {str(e)}")
            st.info("If this error persists, please contact support.")
        
        # Legend
        st.markdown("""
        **Map Legend:**
        * <span style='color:purple'>●</span> Community-reported issues
        * <span style='color:green'>●</span> Official data (safe)
        * <span style='color:orange'>●</span> Official data (concerning)
        * <span style='color:red'>●</span> Official data (unsafe)
        """, unsafe_allow_html=True)
        
        # Attribution
        st.caption("Map data represents both verified official measurements and community reports. Community reports are shown as received and have not been independently verified unless marked as 'Verified'.")
    
    with main_tabs[1]:  # Report Water Quality Issue
        # Check if user is logged in
        if 'authentication_status' not in st.session_state or not st.session_state['authentication_status']:
            st.warning("Please login to report water quality issues.")
            st.info("Your contribution helps create a more complete picture of water quality across South Africa and globally.")
        else:
            # User is logged in, show the reporting interface
            display_community_reporting_interface()
    
    with main_tabs[2]:  # Browse Reports
        st.subheader("Browse Community Reports")
        
        # Filters for viewing reports
        st.markdown("### Filter Reports")
        col1, col2, col3 = st.columns(3)
        
        with col1:
            region_browse = st.text_input("Filter by Region", key="browse_region")
        with col2:
            water_type_browse = st.selectbox(
                "Filter by Water Type",
                options=["All Types", "Rivers", "Dams", "Oceans", "Tap Water", "Underground Water", "Spring Water", "Others"],
                key="browse_type"
            )
        with col3:
            status_browse = st.selectbox(
                "Filter by Status",
                options=["All Reports", "Verified Only", "Pending", "Rejected"],
                key="browse_status"
            )
        
        # Process browse filters
        region_filter = region_browse if region_browse else None
        water_type_filter = water_type_browse.lower() if water_type_browse != "All Types" else None
        
        status_filter = None
        if status_browse != "All Reports":
            if status_browse == "Verified Only":
                status_filter = "verified"
            elif status_browse == "Pending":
                status_filter = "pending"
            elif status_browse == "Rejected":
                status_filter = "rejected"
        
        # Get filtered reports
        reports = get_community_reports(
            region=region_filter,
            report_type=water_type_filter,
            min_pollution_level=1,  # Can be adjusted with another filter if needed
            status=status_filter
        )
        
        if not reports:
            st.info("No community reports match your filter criteria.")
        else:
            # Convert to DataFrame for statistics
            reports_df = pd.DataFrame(reports)
            
            # Sort by date (most recent first)
            if 'reported_date' in reports_df.columns:
                reports_df['reported_date'] = pd.to_datetime(reports_df['reported_date'])
                reports_df = reports_df.sort_values('reported_date', ascending=False)
            
            # Display number of reports
            st.write(f"Total reports: {len(reports_df)}")
            
            # Display charts in tabs
            charts_tab1, charts_tab2, charts_tab3 = st.tabs(["By Water Type", "By Pollution Level", "By Region"])
            
            with charts_tab1:
                if 'type' in reports_df.columns:
                    # Reports by water type
                    type_counts = reports_df['type'].value_counts().reset_index()
                    type_counts.columns = ['type', 'count']
                    
                    fig = px.pie(
                        type_counts,
                        values='count',
                        names='type',
                        title="Reports by Water Type",
                        hole=0.4,
                        color_discrete_sequence=px.colors.qualitative.Dark24
                    )
                    st.plotly_chart(fig, use_container_width=True)
                else:
                    st.info("No type data available for visualization.")
            
            with charts_tab2:
                if 'pollution_level' in reports_df.columns:
                    # Pollution level distribution
                    fig = px.histogram(
                        reports_df,
                        x='pollution_level',
                        nbins=10,
                        title="Distribution of Reported Pollution Levels",
                        labels={'pollution_level': 'Pollution Level (1-10)'},
                        color_discrete_sequence=['#ff6b6b']
                    )
                    fig.update_layout(bargap=0.1)
                    st.plotly_chart(fig, use_container_width=True)
                else:
                    st.info("No pollution level data available for visualization.")
            
            with charts_tab3:
                if 'region' in reports_df.columns:
                    # Reports by region
                    if reports_df['region'].nunique() <= 10:  # Only show if not too many regions
                        region_counts = reports_df['region'].value_counts().reset_index()
                        region_counts.columns = ['region', 'count']
                        
                        fig = px.bar(
                            region_counts,
                            x='region',
                            y='count',
                            title="Reports by Region",
                            labels={'region': 'Region', 'count': 'Number of Reports'},
                            color='count',
                            color_continuous_scale=px.colors.sequential.Viridis
                        )
                        st.plotly_chart(fig, use_container_width=True)
                    else:
                        st.info("Too many regions to display in a chart.")
                else:
                    st.info("No region data available for visualization.")
            
            # Display detailed list of reports 
            st.subheader("Report Details")
            
            # Switch between table and card view
            view_type = st.radio("View As:", ["Table", "Detailed Cards"], horizontal=True)
            
            if view_type == "Table":
                # Display table of reports
                
                # Filter columns for display
                if set(['name', 'type', 'country', 'region', 'pollution_level', 'reported_by', 'reported_date', 'status']).issubset(reports_df.columns):
                    display_cols = ['name', 'type', 'country', 'region', 'pollution_level', 
                                 'reported_by', 'reported_date', 'status']
                    
                    # Rename columns for better display
                    display_df = reports_df[display_cols].copy()
                    display_df.columns = ['Water Source', 'Type', 'Country', 'Region', 'Pollution Level',
                                       'Reported By', 'Report Date', 'Status']
                    
                    # Format dates nicely
                    if 'Report Date' in display_df.columns:
                        display_df['Report Date'] = display_df['Report Date'].dt.strftime('%Y-%m-%d %H:%M')
                    
                    # Display the table
                    st.dataframe(display_df, use_container_width=True)
                    
                    # Optional: Allow downloading the data
                    csv = reports_df[display_cols].to_csv(index=False)
                    st.download_button(
                        label="Download Report Data (CSV)",
                        data=csv,
                        file_name=f"community_water_reports_{datetime.now().strftime('%Y%m%d')}.csv",
                        mime="text/csv"
                    )
                else:
                    st.error("Some required columns are missing from the report data.")
            else:
                # Display detailed cards for each report
                st.write("Showing the most recent reports first:")
                
                # Pagination for large numbers of reports
                reports_per_page = 5
                num_pages = (len(reports) + reports_per_page - 1) // reports_per_page
                
                if num_pages > 1:
                    page = st.selectbox("Page", range(1, num_pages + 1), format_func=lambda x: f"Page {x} of {num_pages}")
                    start_idx = (page - 1) * reports_per_page
                    end_idx = min(start_idx + reports_per_page, len(reports))
                    page_reports = reports[start_idx:end_idx]
                else:
                    page_reports = reports
                
                for report in page_reports:
                    display_report_details(report)
                    st.markdown("---")
    
    # Add moderation tab for admins/moderators
    if is_admin and len(main_tabs) > 3:
        with main_tabs[3]:  # Moderation Interface
            st.subheader("Report Moderation")
            st.markdown("""
            As a moderator or administrator, you can review, verify, reject, or delete community reports.
            Verified reports are prominently displayed on the map and in reports listings.
            """)
            
            # Display the moderation interface
            display_report_moderation_interface()