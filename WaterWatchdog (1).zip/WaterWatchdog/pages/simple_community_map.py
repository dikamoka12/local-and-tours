import streamlit as st
import pandas as pd
import os
import json
from datetime import datetime
from utils.visualization import (
    display_community_reporting_interface, 
    get_community_reports, 
    display_report_details,
    verify_report,
    delete_report
)

def app():
    """A simple version of the community map page to identify errors"""
    try:
        st.title("Community Reporting - DEBUG VERSION")
        st.warning("This is a simplified debug version of the community reporting feature.")
        st.info("If you see this message, the basic page is loading correctly.")
        
        # Create tabs for reporting and viewing
        try:
            tab1, tab2, tab3 = st.tabs(["Report Water Issue", "View Reports", "Manage Reports"])
            
            with tab1:
                st.subheader("Test Reporting Form")
                display_community_reporting_interface()
            
            with tab2:
                st.subheader("View Test Reports")
                # Get community reports
                reports = get_community_reports()
                if not reports:
                    st.info("No reports found. Try submitting a report in the first tab.")
                else:
                    st.success(f"Found {len(reports)} reports.")
                    
                    # Display report count by status
                    status_counts = {}
                    for report in reports:
                        status = report.get('status', 'unknown')
                        if status in status_counts:
                            status_counts[status] += 1
                        else:
                            status_counts[status] = 1
                    
                    # Show counts
                    for status, count in status_counts.items():
                        st.write(f"{status.title()}: {count} reports")
                    
                    # Show a sample report
                    st.subheader("Sample Report Details")
                    sample_report = reports[0]
                    display_report_details(sample_report)
            
            with tab3:
                st.subheader("Test Report Management")
                # Get all reports
                reports = get_community_reports()
                if not reports:
                    st.info("No reports to manage.")
                else:
                    # Simple management interface
                    st.write(f"Managing {len(reports)} reports:")
                    for i, report in enumerate(reports):
                        st.write(f"Report #{i+1}: {report.get('name')} (Status: {report.get('status', 'pending')})")
                        
                        col1, col2, col3 = st.columns(3)
                        with col1:
                            if st.button(f"Verify #{i+1}", key=f"v_{i}"):
                                verify_report(report.get('report_id'), 'verified', 'Test Admin', 'Verified for testing')
                                st.success(f"Report #{i+1} verified.")
                                st.rerun()
                        
                        with col2:
                            if st.button(f"Reject #{i+1}", key=f"r_{i}"):
                                verify_report(report.get('report_id'), 'rejected', 'Test Admin', 'Rejected for testing')
                                st.error(f"Report #{i+1} rejected.")
                                st.rerun()
                        
                        with col3:
                            if st.button(f"Delete #{i+1}", key=f"d_{i}"):
                                delete_report(report.get('report_id'))
                                st.warning(f"Report #{i+1} deleted.")
                                st.rerun()
        
        except Exception as e:
            st.error(f"Error in tabs: {str(e)}")
            st.error(f"Error type: {type(e)}")
            
    except Exception as e:
        st.error(f"General error: {str(e)}")
        st.error(f"Error type: {type(e)}")