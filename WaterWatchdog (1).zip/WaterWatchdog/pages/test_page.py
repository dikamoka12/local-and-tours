import streamlit as st

def app():
    st.title("Test Page")
    st.write("This is a test page to see if it loads.")