import streamlit as st
from utils.common import display_apartheid_message, display_traditional_water_knowledge, display_common_messages

def app():
    """Simple Air Pollution page with essential information"""
    
    # Add header
    st.title("Air Pollution Information")
    
    # Add South African Water Systems Header
    st.markdown("<div style='background-color:#1E3B70; padding:10px; border-radius:5px; margin-bottom:20px;'><h2 style='color:white; text-align:center;'>SOUTH AFRICAN WATER SYSTEMS - TOURISTS AND LOCALS</h2></div>", unsafe_allow_html=True)
    
    # Display both traditional water knowledge and apartheid messages
    display_common_messages()
    
    st.write("This page provides comprehensive information about air pollution causes and dangerous chemicals.")
    
    # Major Causes Section
    st.header("Major Causes of Air Pollution")
    
    st.markdown("""
    ### Primary Sources of Air Pollution:
    
    1. **Industrial Activities**
       - Manufacturing facilities
       - Power plants
       - Mining operations
       - Oil refineries
       - Chemical production
    
    2. **Transportation**
       - Vehicle emissions
       - Aircraft emissions
       - Marine vessels
       - Diesel engines
    
    3. **Agricultural Activities**
       - Livestock farming
       - Fertilizer application
       - Pesticide use
       - Agricultural waste burning
    
    4. **Residential Sources**
       - Household heating (wood, coal)
       - Cooking with solid fuels
       - Consumer products (paints, cleaners)
       - Residential waste burning
    
    5. **Natural Sources**
       - Volcanic eruptions
       - Dust storms
       - Forest fires
       - Biological decay
    """)
    
    # Harmful Chemicals Section
    st.header("Harmful Chemicals and Pollutants")
    
    st.markdown("""
    ### Most Dangerous Air Pollutants:
    
    #### Criteria Air Pollutants
    - **Particulate Matter (PM2.5 and PM10)** - Causes respiratory issues, cardiovascular problems
    - **Ground-level Ozone (O₃)** - Triggers asthma, reduces lung function
    - **Nitrogen Oxides (NOx)** - Causes respiratory inflammation, contributes to acid rain
    - **Sulfur Dioxide (SO₂)** - Irritates breathing, damages vegetation
    - **Carbon Monoxide (CO)** - Reduces oxygen delivery to body organs
    - **Lead (Pb)** - Damages nervous system, particularly in children
    
    #### Hazardous Air Pollutants
    - **Benzene** - Known carcinogen, causes blood disorders
    - **Formaldehyde** - Irritates respiratory system, classified as carcinogen
    - **Mercury** - Neurotoxic, developmental impacts
    - **Dioxins and Furans** - Highly toxic, linked to cancer
    - **Polycyclic Aromatic Hydrocarbons (PAHs)** - Several are carcinogenic
    """)
    
    # South Africa Focus
    st.header("Air Pollution in South Africa")
    
    st.markdown("""
    ### Key Challenges in South Africa:
    
    1. **Coal-Based Energy Production**
       - South Africa relies heavily on coal for electricity
       - Eskom power stations in the Highveld release significant pollutants
       - Mpumalanga province contains most coal-fired power plants
    
    2. **Mining Activity**
       - Mining operations release dust with heavy metals
       - Mine dumps create ongoing sources of windblown dust
       - Gold, platinum, and coal mining areas have higher pollution
    
    3. **Industrial Activities**
       - Petrochemical facilities (particularly in areas like Sasolburg)
       - Manufacturing and heavy industry in certain zones
    
    4. **Priority Areas with Poor Air Quality**
       - Vaal Triangle Airshed
       - Highveld Priority Area
       - Waterberg-Bojanala Priority Area
    """)
    
    # Health Effects
    st.header("Health Effects of Air Pollution")
    
    st.markdown("""
    ### Health Impacts:
    
    - **Respiratory System**: Asthma, COPD, reduced lung function, respiratory infections
    - **Cardiovascular System**: Heart attacks, stroke, arrhythmias, hypertension
    - **Nervous System**: Cognitive decline, developmental delays, neurodegenerative diseases
    - **Reproductive System**: Reduced fertility, pregnancy complications, low birth weight
    - **Other Systems**: Kidney damage, liver damage, eye irritation, skin disorders
    
    ### Vulnerable Populations:
    - Children
    - Elderly
    - Pregnant women
    - People with existing health conditions
    """)
    
    # Environmental Effects
    st.header("Environmental Impact")
    
    st.markdown("""
    ### Environmental Effects:
    
    - **Ecosystem Damage**: Acidification of lakes, nutrient imbalances, damage to forests
    - **Climate Change**: Global warming, altered precipitation, extreme weather
    - **Agricultural Impacts**: Reduced crop yields, damage to plant tissues
    - **Built Environment**: Deterioration of buildings, corrosion of metals
    - **Visibility Impairment**: Urban haze, reduced visibility in scenic areas
    """)
    
    # Connection to Water
    st.header("Connection to Water Systems")
    
    st.markdown("""
    ### How Air Pollution Affects Water:
    
    - **Acid Rain**: Sulfur dioxide and nitrogen oxides create acidic precipitation
    - **Atmospheric Deposition**: Pollutants settle directly into water bodies
    - **Nutrient Loading**: Nitrogen compounds can cause eutrophication
    - **Mercury Contamination**: Airborne mercury eventually enters the water system
    
    These connections highlight why air and water pollution must be addressed together.
    """)
    
    # Solutions
    st.header("Solutions and Mitigation Strategies")
    
    st.markdown("""
    ### Key Approaches to Reducing Air Pollution:
    
    #### Policy Measures
    - Emission standards for industries and vehicles
    - Air quality monitoring networks
    - Clean air legislation and enforcement
    
    #### Technological Solutions
    - Renewable energy (solar, wind, hydroelectric)
    - Energy efficiency improvements
    - Advanced emission control systems
    - Electric vehicles
    
    #### Individual Actions
    - Reducing energy consumption
    - Using public transportation
    - Properly maintaining vehicles
    - Avoiding burning waste
    - Using environmentally friendly products
    """)
    
    # References
    st.markdown("""
    ---
    ### References and Further Reading
    
    - World Health Organization (WHO) Air Quality Guidelines
    - United States Environmental Protection Agency (EPA) Air Quality resources
    - South African Air Quality Information System (SAAQIS)
    - The Lancet Commission on Pollution and Health
    - State of Global Air reports
    """)
    
    # Add footer
    st.markdown("<br><br>", unsafe_allow_html=True)
    # Display both messages in the footer using the combined function
    display_common_messages()
    st.markdown("<div style='background-color:#1E3B70; padding:10px; border-radius:5px; margin-top:20px;'><h3 style='color:white; text-align:center;'>SOUTH AFRICAN WATER SYSTEMS - TOURISTS AND LOCALS</h3></div>", unsafe_allow_html=True)