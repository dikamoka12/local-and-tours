import streamlit as st
import pandas as pd
import plotly.express as px

def app():
    st.title("Toxic Chemicals in Cosmetics & Personal Care Products")
    st.write("A comparative analysis of chemicals approved in South Africa but banned or restricted elsewhere.")
    
    # Create tabs for different views
    tab1, tab2, tab3 = st.tabs(["Chemical Database", "Environmental Impact", "Regulatory Information"])
    
    with tab1:
        st.header("Comparative List of Toxic Chemicals")
        st.markdown("""
        The following chemicals are approved for use in cosmetics and personal care products in South Africa (under DTI and SABS regulations) 
        but banned or restricted in the EU, US, Canada, or other regions. This highlights regulatory gaps that endanger public health.
        """)
        
        # Filter options
        chemical_types = ["All Chemicals", "Carcinogens", "Hormone Disruptors", "Skin Irritants", "Heavy Metals", "Preservatives"]
        selected_type = st.selectbox("Filter by chemical type:", chemical_types)
        
        # Create chemicals dataframe
        chemicals_data = {
            "Chemical": [
                "Formaldehyde and Formaldehyde-Releasing Agents",
                "Parabens (Isobutylparaben, IsoPropylparaben)", 
                "Phthalates (DEHP, DBP, BBP)",
                "Coal Tar",
                "Hydroquinone",
                "Oxybenzone (Benzophenone-3)",
                "Resorcinol",
                "Lead Acetate",
                "Methylisothiazolinone (MIT)",
                "Talc (Asbestos-Contaminated)"
            ],
            "SA Status": [
                "Allowed in cosmetics (e.g., hair straighteners, nail polish) with no explicit concentration limits",
                "Permitted as preservatives (no specific bans)",
                "Allowed in fragrances, nail polish, and hair sprays",
                "Permitted in anti-dandruff shampoos (e.g., Psoriasis treatments)",
                "Allowed up to 2% in OTC products (higher concentrations require prescription)",
                "Permitted in sunscreens",
                "Allowed in hair dyes and acne treatments",
                "Permitted in hair dyes (e.g., gradual darkening products)",
                "Allowed in rinse-off products (shampoos, cleansers)",
                "Allowed in cosmetics (no mandatory asbestos testing)"
            ],
            "Banned/Restricted In": [
                "EU: Banned in aerosol products; restricted to 0.1% in others. Canada: Prohibited in leave-on products. California (US): Listed as a carcinogen under Prop 65",
                "EU: Banned 5 parabens (isobutyl-, isopropyl-) since 2015. ASEAN: Restricted in children's products",
                "EU: Banned in cosmetics (Annex II of Regulation EC 1223/2009). US: Banned in children's toys but allowed in cosmetics",
                "EU: Banned in cosmetics (classified as carcinogenic). Canada: Restricted to medicinal use only",
                "EU: Fully banned in cosmetics since 2000. Japan: Prohibited. Australia: Prescription-only",
                "Hawaii/Palau: Banned due to coral reef damage. EU: Restricted to 6% concentration",
                "EU: Restricted to 0.5% in hair dyes (banned in leave-on products). Japan: Limited to 0.1%",
                "EU, Canada, Japan: Banned. US: Banned in 2018",
                "EU: Banned in leave-on products (e.g., lotions) since 2016. Canada: Restricted to 0.01%",
                "EU: Requires asbestos-free certification. US: Legal but facing lawsuits (e.g., Johnson & Johnson)"
            ],
            "Health Risks": [
                "Carcinogenic (nasal cancer, leukemia), respiratory damage",
                "Hormone disruption, breast cancer links",
                "Infertility, birth defects, liver damage",
                "Skin/lung cancer, organ toxicity",
                "Skin disfigurement (ochronosis), kidney damage",
                "Hormone disruption, allergic reactions",
                "Thyroid dysfunction, skin irritation",
                "Neurotoxicity, developmental delays in children",
                "Severe allergic reactions, eczema",
                "Ovarian cancer, lung inflammation"
            ],
            "Type": [
                "Carcinogens",
                "Hormone Disruptors",
                "Hormone Disruptors",
                "Carcinogens",
                "Skin Irritants",
                "Hormone Disruptors",
                "Hormone Disruptors",
                "Heavy Metals",
                "Skin Irritants",
                "Carcinogens"
            ],
            "Common Products": [
                "Hair straighteners, nail polish",
                "Moisturizers, makeup",
                "Fragrances, nail polish",
                "Dandruff shampoos",
                "Skin-lightening creams",
                "Sunscreens",
                "Hair dyes, acne treatments",
                "Hair dyes",
                "Shampoos, cleansers",
                "Baby powder, makeup"
            ]
        }
        
        chemicals_df = pd.DataFrame(chemicals_data)
        
        # Filter chemicals based on selection
        if selected_type != "All Chemicals":
            filtered_chemicals = chemicals_df[chemicals_df["Type"] == selected_type]
        else:
            filtered_chemicals = chemicals_df
        
        # Display chemicals table
        st.subheader(f"{selected_type} - Regulatory Status")
        
        # Use Streamlit's built-in dataframe display with appropriate columns
        display_df = filtered_chemicals[["Chemical", "SA Status", "Banned/Restricted In", "Health Risks", "Common Products"]]
        st.dataframe(display_df, use_container_width=True)
        
        # Examples of specific products
        st.subheader("Examples of Products Sold in SA But Banned Abroad")
        
        product_data = {
            "Product": ["Dark & Lovely Relaxer", "Nair Hair Removal Cream", "Garnier Skin Naturals", "L'Oréal Preference Hair"],
            "Chemical": ["Formaldehyde", "Methylisothiazolinone", "Oxybenzone", "Resorcinol"],
            "Banned In": ["EU, Canada", "EU (leave-on)", "Hawaii, Palau", "EU (above 0.5%)"],
            "SA Retailers": ["Clicks, Dis-Chem", "Pick n Pay, Takealot", "Woolworths", "Salons nationwide"]
        }
        
        products_df = pd.DataFrame(product_data)
        st.table(products_df)
        
        # Chemical Details
        st.subheader("Chemical Details")
        selected_chemical = st.selectbox("Select a chemical for detailed information:", chemicals_df["Chemical"].tolist())
        
        if selected_chemical:
            chemical_data = chemicals_df[chemicals_df["Chemical"] == selected_chemical].iloc[0]
            
            # Create columns for layout
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown(f"**Chemical:** {chemical_data['Chemical']}")
                st.markdown(f"**Type:** {chemical_data['Type']}")
                st.markdown(f"**South Africa Status:** {chemical_data['SA Status']}")
            
            with col2:
                st.markdown(f"**Health Risks:** {chemical_data['Health Risks']}")
                st.markdown(f"**Common Products:** {chemical_data['Common Products']}")
                st.markdown(f"**Banned/Restricted In:** {chemical_data['Banned/Restricted In']}")
            
            # Health risk assessment
            st.subheader("Health Risk Assessment")
            
            if "Carcinogens" in chemical_data["Type"]:
                st.error("""
                **Cancer Risk - Serious Concern**
                - May cause cancer with prolonged exposure
                - Consider immediate switch to safer alternatives
                - Special concern for salon workers or frequent users
                """)
            elif "Hormone Disruptors" in chemical_data["Type"]:
                st.warning("""
                **Endocrine Disruption - Moderate to High Concern**
                - May interfere with hormone function
                - Particular concern for pregnant women and children
                - Can affect reproductive health and development
                """)
            elif "Heavy Metals" in chemical_data["Type"]:
                st.error("""
                **Heavy Metal Toxicity - Serious Concern**
                - Can accumulate in the body over time
                - May cause neurological damage
                - Especially harmful to children and developing fetuses
                """)
            else:
                st.warning("""
                **Skin and Respiratory Irritation - Moderate Concern**
                - May cause allergic reactions and skin sensitization
                - Can worsen existing skin conditions
                - May trigger asthma or breathing difficulties in sensitive individuals
                """)

    with tab2:
        st.header("Environmental Impact")
        st.markdown("""
        Toxic chemicals from cosmetics and personal care products cause significant environmental damage 
        through various pathways including wastewater discharge, industrial runoff, landfill leaching, 
        air pollution, and microplastic contamination.
        """)
        
        # Pathways of Environmental Pollution
        st.subheader("Pathways of Environmental Pollution")
        
        pollution_paths = {
            "Pathway": ["Wastewater Discharge", "Industrial Runoff", "Landfill Leaching", "Air Pollution", "Microplastics"],
            "Description": [
                "Chemicals from shampoos, lotions, and dyes (e.g., sulfates, parabens, formaldehyde) wash down drains into sewage systems. Many wastewater treatment plants (WWTPs) in South Africa lack the capacity to filter these toxins, releasing them into rivers and oceans.",
                "Factories producing cosmetics often discharge untreated waste containing heavy metals (mercury, lead) and solvents into waterways.",
                "Discarded products (e.g., aerosol cans, nail polish) break down in landfills, leaching volatile organic compounds (VOCs) and microplastics into soil and groundwater.",
                "Aerosols (hairsprays, deodorants) release VOCs and butane/propane, contributing to smog and ozone depletion.",
                "Exfoliating scrubs with polyethylene (microbeads) and synthetic fibers from wet wipes enter oceans, harming marine life."
            ],
            "Example Impact": [
                "The Umgeni River (KZN) has shown traces of phthalates from beauty products, harming aquatic life.",
                "Informal settlements near Durban's industrial zones report contaminated groundwater linked to nearby cosmetic factories.",
                "Toxins from cosmetic waste in landfills can persist for decades, contaminating soil and waterways.",
                "VOCs from aerosols contribute to poor air quality and respiratory problems.",
                "Microbeads have been found in fish and other marine life, eventually entering the human food chain."
            ],
            "Percentage": [35, 25, 20, 15, 5]  # Approximate distribution for visualization
        }
        
        paths_df = pd.DataFrame(pollution_paths)
        
        # Create visualization
        fig = px.pie(
            paths_df,
            values="Percentage",
            names="Pathway",
            title="Major Pathways of Cosmetic Chemical Pollution",
            hole=0.4,
            color_discrete_sequence=px.colors.qualitative.Bold
        )
        
        st.plotly_chart(fig, use_container_width=True)
        
        # Display pollution pathways in expandable sections
        for i, row in paths_df.iterrows():
            with st.expander(f"{row['Pathway']}"):
                st.write(f"**Description:** {row['Description']}")
                st.write(f"**Example Impact:** {row['Example Impact']}")
        
        # Key Chemicals and Their Environmental Impact
        st.subheader("Key Chemicals and Their Environmental Impact")
        
        env_impact_data = {
            "Chemical": ["Formaldehyde", "Mercury", "Phthalates (DBP, DEHP)", "Oxybenzone", "Sulfates (SLS/SLES)", "Parabens", "Coal Tar", "Microplastics"],
            "Environmental Damage": [
                "Aquatic toxicity: Kills fish and algae.",
                "Bioaccumulation: Enters food chain via fish, causing bird/reptile deformities.",
                "Endocrine disruption: Feminizes male fish, reduces fertility in marine species.",
                "Coral bleaching: Kills coral reefs by disrupting symbiotic algae (e.g., Soldana Bay).",
                "Eutrophication: Algae blooms deplete oxygen, creating \"dead zones\" in water bodies.",
                "Antibiotic resistance: Alters microbial communities in soil/water.",
                "Soil contamination: Toxic to earthworms and plants; persists for decades.",
                "Marine ingestion: Enters fish, seabirds, and humans via seafood."
            ],
            "Common Products": [
                "Hair straighteners, nail polish",
                "Skin-lightening creams",
                "Fragrances, nail polish",
                "Sunscreens",
                "Shampoos, cleansers",
                "Moisturizers, makeup",
                "Dandruff shampoos",
                "Exfoliating scrubs, glitter makeup"
            ]
        }
        
        env_impact_df = pd.DataFrame(env_impact_data)
        st.dataframe(env_impact_df, use_container_width=True)
        
        # Recommendations for Mitigation
        st.subheader("Recommendations for Mitigation")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("#### Policy Reforms")
            st.markdown("""
            - Ban oxybenzone, microplastics, and formaldehyde in cosmetics (align with EU's REACH regulations)
            - Enforce Extended Producer Responsibility (EPR) laws under NEMA to hold brands accountable for waste
            
            #### Infrastructure Upgrades
            - Invest in WWTPs with advanced filtration (e.g., activated carbon for phthalates)
            """)
            
        with col2:
            st.markdown("#### Public Awareness")
            st.markdown("""
            - Promote eco-labels (e.g., "Blue Flag" for reef-safe sunscreens) and campaigns like #PlasticFreeMzansi
            
            #### Research Funding
            - Support studies on SA-specific pollution (e.g., UCT's ongoing microplastic research in False Bay)
            """)
        
        st.warning("""
        Toxic chemicals in personal care products are poisoning South Africa's water, soil, and air, 
        with marginalized communities bearing the brunt. Urgent regulatory action, aligned with global standards, 
        is needed to curb this silent environmental crisis.
        """)

    with tab3:
        st.header("Regulatory Information")
        
        # Regulatory Gaps
        st.subheader("Regulatory Gaps in South Africa")
        
        st.markdown("""
        1. **SABS Standards (e.g., SANS 490:2013)**:
           - Does not ban formaldehyde, parabens, or coal tar
           - Lacks alignment with EU's REACH regulation (1,300+ chemicals banned)

        2. **DTI Enforcement**:
           - Relies on outdated Hazardous Substances Act (1973), which does not address modern cosmetic toxins
           - No mandatory pre-market safety testing for cosmetics (unlike pharmaceuticals under SAHPRA)

        3. **Consumer Protection Act (2008)**:
           - Fails to mandate full ingredient disclosure (e.g., fragrances can hide phthalates)
        """)
        
        # Comparative Regulation
        st.subheader("Global Regulatory Comparison")
        
        regulation_data = {
            "Region": ["South Africa", "European Union", "United States", "Canada", "Japan", "ASEAN"],
            "Banned Substances": ["Few specific bans", "1,300+ chemicals", "Limited bans (11 chemicals)", "500+ chemicals", "~30 chemicals", "Follows EU standards"],
            "Pre-Market Approval": ["Not required", "Safety assessments required", "Not required (except color additives)", "Required", "Required", "Varies by country"],
            "Testing Requirements": ["Minimal", "Robust, no animal testing", "Self-regulated", "Comprehensive", "Stringent", "Follows EU standards"],
            "Enforcement": ["Limited", "Stringent", "Post-market surveillance", "Proactive", "Rigorous", "Varies by country"]
        }
        
        reg_df = pd.DataFrame(regulation_data)
        st.dataframe(reg_df, use_container_width=True)
        
        # Legal Implications
        st.subheader("Legal Implications")
        
        st.markdown("""
        #### Criminal Law (South Africa)
        - Distributing products with undeclared banned substances (e.g., mercury) may violate Section 18 of the Hazardous Substances Act 
          (penalties: fines or 10-year imprisonment)
        - Fraudulent labeling (e.g., "natural" products with MIT) breaches Consumer Protection Act Section 41

        #### International Law
        - SA's lax regulation of mercury in cosmetics violates the Minamata Convention, ratified in 2017
        """)
        
        # Create a comparison slider between SA and EU regulations
        st.subheader("Regulatory Protection Comparison")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("South Africa", "~20 banned chemicals", "-1,280 vs EU")
            
        with col2:
            st.metric("United States", "11 banned chemicals", "-1,289 vs EU")
            
        with col3:
            st.metric("European Union", "1,300+ banned chemicals", "Gold standard")
            
        st.info("""
        South Africa's outdated cosmetic regulations allow dangerous chemicals banned globally to remain in products, 
        disproportionately harming low-income communities. Urgent reforms are needed to protect public health and 
        comply with international treaties.
        """)
        
        # Call to action
        st.error("""
        Failure to act on these regulatory gaps will compel civil society organizations to escalate this matter to the 
        South African Human Rights Commission and United Nations Special Rapporteurs on Toxics and Health.
        """)

if __name__ == "__main__":
    app()