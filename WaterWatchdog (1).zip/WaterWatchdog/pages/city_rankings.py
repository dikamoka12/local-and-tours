import streamlit as st
import pandas as pd
import plotly.express as px
from utils.data_processor import load_city_rankings_data
from utils.visualization import create_city_rankings_chart, create_correlation_chart

def app():
    st.title("City Friendliness Rankings")
    st.write("Discover which cities around the world are rated as most friendly, with data on their water quality.")
    
    # Load data
    city_rankings_df = load_city_rankings_data()
    
    # Check if data is available
    if len(city_rankings_df) == 0:
        st.warning("No city ranking data is currently available. Please check back later or contact support if this issue persists.")
        return
    
    # Sidebar filters
    st.sidebar.title("Filters")
    
    # Region filter
    regions = ["All"] + sorted(city_rankings_df["region"].unique().tolist())
    selected_region = st.sidebar.selectbox("Region", regions)
    
    # Friendliness score filter
    min_friendliness, max_friendliness = st.sidebar.slider(
        "Friendliness Score Range", 
        min_value=0, 
        max_value=10, 
        value=(0, 10),
        step=1
    )
    
    # Water quality score filter
    min_water_quality, max_water_quality = st.sidebar.slider(
        "Water Quality Score Range", 
        min_value=0, 
        max_value=10, 
        value=(0, 10),
        step=1
    )
    
    # Search box
    search_query = st.sidebar.text_input("Search by city or country")
    
    # Apply filters
    filtered_df = city_rankings_df.copy()
    
    if selected_region != "All":
        filtered_df = filtered_df[filtered_df["region"] == selected_region]
    
    filtered_df = filtered_df[
        (filtered_df["friendliness_score"] >= min_friendliness) & 
        (filtered_df["friendliness_score"] <= max_friendliness) &
        (filtered_df["water_quality_score"] >= min_water_quality) & 
        (filtered_df["water_quality_score"] <= max_water_quality)
    ]
    
    if search_query:
        query_lower = search_query.lower()
        filtered_df = filtered_df[
            filtered_df["city"].str.lower().str.contains(query_lower) | 
            filtered_df["country"].str.lower().str.contains(query_lower)
        ]
    
    # Display filter summary
    st.write(f"Showing {len(filtered_df)} cities")
    
    # Main content
    
    # Top cities chart
    st.subheader("Top 20 Friendliest Cities")
    if len(filtered_df) > 0:
        top_cities_chart = create_city_rankings_chart(filtered_df, top_n=min(20, len(filtered_df)))
        st.plotly_chart(top_cities_chart, use_container_width=True)
    else:
        st.info("No data available for the selected filters.")
    
    # Correlation analysis
    st.subheader("Correlation: Water Quality vs. City Friendliness")
    if len(filtered_df) > 0:
        correlation_chart = create_correlation_chart(filtered_df)
        st.plotly_chart(correlation_chart, use_container_width=True)
        
        # Calculate correlation coefficient
        correlation = filtered_df["water_quality_score"].corr(filtered_df["friendliness_score"])
        st.write(f"Correlation coefficient: {correlation:.2f}")
        
        if correlation > 0.7:
            st.write("There is a strong positive correlation between water quality and city friendliness.")
        elif correlation > 0.3:
            st.write("There is a moderate positive correlation between water quality and city friendliness.")
        elif correlation > 0:
            st.write("There is a weak positive correlation between water quality and city friendliness.")
        else:
            st.write("There is no positive correlation between water quality and city friendliness.")
    else:
        st.info("No data available for the selected filters.")
    
    # Full city rankings
    st.subheader("City Rankings Table")
    
    # Sort options
    sort_options = ["Friendliness (High to Low)", "Friendliness (Low to High)", 
                   "Water Quality (High to Low)", "Water Quality (Low to High)"]
    sort_by = st.selectbox("Sort by", sort_options)
    
    if len(filtered_df) > 0:
        sorted_df = filtered_df.copy()
        
        if sort_by == "Friendliness (High to Low)":
            sorted_df = sorted_df.sort_values("friendliness_score", ascending=False)
        elif sort_by == "Friendliness (Low to High)":
            sorted_df = sorted_df.sort_values("friendliness_score", ascending=True)
        elif sort_by == "Water Quality (High to Low)":
            sorted_df = sorted_df.sort_values("water_quality_score", ascending=False)
        elif sort_by == "Water Quality (Low to High)":
            sorted_df = sorted_df.sort_values("water_quality_score", ascending=True)
        
        # Display the table
        display_df = sorted_df[["city", "country", "region", "friendliness_score", "water_quality_score", "population"]]
        display_df.columns = ["City", "Country", "Region", "Friendliness Score", "Water Quality Score", "Population"]
        st.dataframe(display_df, use_container_width=True)
    else:
        st.info("No data available for the selected filters.")
    
    # City details
    st.subheader("City Details")
    if len(filtered_df) > 0:
        selected_city = st.selectbox("Select a city for detailed information", filtered_df["city"].tolist())
        
        if selected_city:
            city_data = filtered_df[filtered_df["city"] == selected_city].iloc[0]
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown(f"**City:** {city_data['city']}")
                st.markdown(f"**Country:** {city_data['country']}")
                st.markdown(f"**Region:** {city_data['region']}")
                st.markdown(f"**Population:** {city_data['population']:,}")
            
            with col2:
                st.markdown(f"**Friendliness Score:** {city_data['friendliness_score']}/10")
                st.markdown(f"**Water Quality Score:** {city_data['water_quality_score']}/10")
                st.markdown(f"**Primary Water Source:** {city_data['primary_water_source']}")
                st.markdown(f"**Last Updated:** {city_data['last_updated']}")
    else:
        st.info("No data available for the selected filters.")

if __name__ == "__main__":
    app()
