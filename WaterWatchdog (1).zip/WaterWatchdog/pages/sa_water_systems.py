import streamlit as st
import pandas as pd
import plotly.express as px

def app():
    # Main title with styling
    st.markdown("<h1 style='text-align: center; color: #1E88E5; background-color: #E3F2FD; padding: 20px; border-radius: 10px;'>SOUTH AFRICAN WATER SYSTEMS</h1>", unsafe_allow_html=True)
    
    # New header for TOURISTS AND LOCALS
    st.markdown("<h2 style='text-align: center; font-size: 28px; color: #D81B60; background-color: #FCE4EC; padding: 15px; margin-top: 10px; border-radius: 10px;'>TOURISTS AND LOCALS</h2>", unsafe_allow_html=True)
    
    st.write("Information for communities who use rivers, dams, and oceans for religious ceremonies, traditional practices, and daily activities.")
    
    # Create tabs for different sections
    tab1, tab2, tab3, tab4 = st.tabs(["River Systems", "Ocean Areas", "Health Guidance", "Traditional Use"])
    
    with tab1:
        st.header("Major South African River Systems & Their Concerns")
        
        # Create dataframe with river information
        river_data = {
            "River System": [
                "Vaal River", 
                "Orange River", 
                "Limpopo River", 
                "Olifants River (Mpumalanga)", 
                "Crocodile River", 
                "Umgeni River",
                "Buffalo River",
                "Great Fish River",
                "Breede River",
                "Berg River",
                "Tugela River",
                "Olifants River (Western Cape)",
                "Jukskei River",
                "Umfolozi River"
            ],
            "Region": [
                "Gauteng/Free State", 
                "Northern Cape/Free State", 
                "Limpopo/International", 
                "Mpumalanga/Limpopo", 
                "Mpumalanga/Gauteng",
                "KwaZulu-Natal",
                "Eastern Cape",
                "Eastern Cape",
                "Western Cape",
                "Western Cape",
                "KwaZulu-Natal",
                "Western Cape",
                "Gauteng",
                "KwaZulu-Natal"
            ],
            "Main Contaminants": [
                "AMD (acid mine drainage), sewage, industrial chemicals, E. coli", 
                "Agricultural runoff, salt, uranium traces, mining waste", 
                "Agricultural chemicals, mining waste, sewage", 
                "Heavy metals (Mn, Fe, Al, Cu), acid mine drainage, agricultural chemicals",
                "Industrial effluent, sewage, agricultural runoff",
                "Raw sewage, E. coli, industrial waste, microplastics",
                "Mining effluent, sewage, industrial waste",
                "Agricultural runoff, sewage, salinization",
                "Agricultural chemicals, sewage from informal settlements",
                "Pesticides, nutrients, sewage, microplastics",
                "Industrial effluent, agricultural runoff, sewage",
                "Agricultural chemicals, urban runoff",
                "Sewage, urban waste, industrial chemicals, E. coli",
                "Heavy metals, agricultural runoff, industrial waste"
            ],
            "Health Risk Level": [9, 7, 6, 8, 7, 8, 9, 6, 5, 7, 6, 5, 9, 7]
        }
        
        river_df = pd.DataFrame(river_data)
        
        # Create sortable table for rivers
        st.dataframe(
            river_df,
            column_config={
                "River System": st.column_config.TextColumn("River System", width="medium"),
                "Region": st.column_config.TextColumn("Region", width="medium"),
                "Main Contaminants": st.column_config.TextColumn("Key Pollutants", width="large"),
                "Health Risk Level": st.column_config.ProgressColumn(
                    "Health Risk (1-10)",
                    min_value=0,
                    max_value=10,
                    format="%d",
                    help="Health risk level from 1 (low) to 10 (severe)"
                ),
            },
            use_container_width=True,
            hide_index=True,
        )
        
        # Create a bar chart of river health risks
        fig = px.bar(
            river_df, 
            x="River System", 
            y="Health Risk Level", 
            color="Region",
            title="Health Risk Assessment of Major South African Rivers",
            labels={"Health Risk Level": "Risk Level (1-10)"},
            color_discrete_sequence=px.colors.qualitative.Bold
        )
        st.plotly_chart(fig, use_container_width=True)
        
        # Show detailed information about highest risk rivers
        st.subheader("Highest Risk River Systems - Detailed Information")
        
        with st.expander("Vaal River", expanded=True):
            st.markdown("""
            <div style='font-size:18px;'>
            <p><strong>Location:</strong> Flows through Gauteng, Mpumalanga, Free State and Northern Cape</p>
            <p><strong>Main Uses:</strong> Ceremonial bathing, baptisms, traditional healing rituals, fishing</p>
            
            <p><strong>Primary Contaminants:</strong></p>
            <ul>
                <li><strong>Acid Mine Drainage (AMD)</strong> - From gold mining operations, containing heavy metals and sulfates</li>
                <li><strong>Sewage</strong> - Untreated or partially treated sewage from failing wastewater treatment plants</li>
                <li><strong>E. coli</strong> - Dangerously high levels in many areas, indicating fecal contamination</li>
                <li><strong>Industrial chemicals</strong> - Including metals, solvents, and manufacturing byproducts</li>
            </ul>
            
            <p><strong>Associated Health Risks:</strong></p>
            <ul>
                <li><strong>Gastrointestinal illness</strong> - Severe diarrhea, vomiting, dehydration</li>
                <li><strong>Skin infections</strong> - Contact dermatitis, rashes, secondary bacterial infections</li>
                <li><strong>Parasitic infections</strong> - Including bilharzia (schistosomiasis)</li>
                <li><strong>Chemical toxicity</strong> - Heavy metal poisoning, particularly problematic with repeated exposure</li>
                <li><strong>Eye and ear infections</strong> - Common after immersion in contaminated water</li>
            </ul>
            
            <p><strong>High-Risk Areas:</strong> Particularly dangerous downstream of Sebokeng Wastewater Works, Emfuleni area, Parys</p>
            </div>
            """, unsafe_allow_html=True)
            
        with st.expander("Jukskei River"):
            st.markdown("""
            <div style='font-size:18px;'>
            <p><strong>Location:</strong> Runs through Alexandra township and northern Johannesburg</p>
            <p><strong>Main Uses:</strong> Baptisms, ritual cleansing, domestic use in informal settlements</p>
            
            <p><strong>Primary Contaminants:</strong></p>
            <ul>
                <li><strong>Raw sewage</strong> - Extremely high levels from sewer overflows and informal settlements</li>
                <li><strong>E. coli</strong> - Levels often hundreds of times above safe limits</li>
                <li><strong>Solid waste</strong> - Physical pollution from illegal dumping</li>
                <li><strong>Industrial runoff</strong> - Various chemicals from businesses along the river</li>
            </ul>
            
            <p><strong>Associated Health Risks:</strong></p>
            <ul>
                <li><strong>Cholera risk</strong> - During outbreaks and high-flow periods</li>
                <li><strong>Typhoid fever</strong> - From fecal contamination</li>
                <li><strong>Hepatitis A</strong> - Viral infection spread through contaminated water</li>
                <li><strong>Parasitic diseases</strong> - Multiple parasites present in water</li>
                <li><strong>Skin and wound infections</strong> - Including antibiotic-resistant bacteria</li>
            </ul>
            
            <p><strong>High-Risk Areas:</strong> Alexandra, Waterfall areas, particularly after rainfall events</p>
            <p><strong>Recent Incidents:</strong> Fatal drownings in December 2023 highlighted the dangers of flash floods in this polluted system</p>
            </div>
            """, unsafe_allow_html=True)
            
        with st.expander("Buffalo River"):
            st.markdown("""
            <div style='font-size:18px;'>
            <p><strong>Location:</strong> Eastern Cape, flowing through East London</p>
            <p><strong>Main Uses:</strong> Baptisms, traditional cleansing ceremonies, fishing</p>
            
            <p><strong>Primary Contaminants:</strong></p>
            <ul>
                <li><strong>Industrial effluent</strong> - From factories in the East London industrial area</li>
                <li><strong>Mining waste</strong> - Containing heavy metals</li>
                <li><strong>Sewage</strong> - From failing infrastructure and informal settlements</li>
                <li><strong>Agricultural chemicals</strong> - Pesticides and fertilizers from upstream farming</li>
            </ul>
            
            <p><strong>Associated Health Risks:</strong></p>
            <ul>
                <li><strong>Chemical burns</strong> - From industrial pollutants at high concentrations</li>
                <li><strong>Respiratory issues</strong> - From volatile compounds in industrial waste</li>
                <li><strong>Gastrointestinal disease</strong> - From bacterial and viral pathogens</li>
                <li><strong>Neurological effects</strong> - From heavy metal exposure, particularly mercury and lead</li>
                <li><strong>Reproductive health issues</strong> - Associated with endocrine-disrupting chemicals</li>
            </ul>
            
            <p><strong>High-Risk Areas:</strong> Near industrial zones, downstream of Zwelitsha and King William's Town</p>
            </div>
            """, unsafe_allow_html=True)
            
        with st.expander("Olifants River (Mpumalanga)"):
            st.markdown("""
            <div style='font-size:18px;'>
            <p><strong>Location:</strong> Mpumalanga and Limpopo, flowing through Kruger National Park</p>
            <p><strong>Main Uses:</strong> Fishing, ceremonial use, agricultural irrigation, drinking water</p>
            
            <p><strong>Primary Contaminants:</strong></p>
            <ul>
                <li><strong>Acid Mine Drainage</strong> - From coal and other mining operations</li>
                <li><strong>Heavy metals</strong> - Particularly aluminum, iron, manganese, and copper</li>
                <li><strong>Agricultural pesticides</strong> - From intensive farming in the catchment</li>
                <li><strong>Bacterial contamination</strong> - From inadequate sanitation in rural areas</li>
            </ul>
            
            <p><strong>Associated Health Risks:</strong></p>
            <ul>
                <li><strong>Metal toxicity</strong> - Long-term exposure can cause organ damage</li>
                <li><strong>Developmental issues</strong> - In children exposed to neurotoxic metals</li>
                <li><strong>Blue baby syndrome</strong> - From nitrate contamination</li>
                <li><strong>Fish contamination</strong> - Bioaccumulation of metals and chemicals in consumed fish</li>
                <li><strong>Endocrine disruption</strong> - From agricultural chemicals affecting hormonal systems</li>
            </ul>
            
            <p><strong>High-Risk Areas:</strong> Downstream of Witbank/eMalahleni, mining areas, Phalaborwa region</p>
            </div>
            """, unsafe_allow_html=True)
            
        with st.expander("Umgeni River"):
            st.markdown("""
            <div style='font-size:18px;'>
            <p><strong>Location:</strong> KwaZulu-Natal, flowing through Pietermaritzburg and Durban</p>
            <p><strong>Main Uses:</strong> Shembe baptisms, traditional Zulu ceremonies, fishing, recreation</p>
            
            <p><strong>Primary Contaminants:</strong></p>
            <ul>
                <li><strong>Sewage overflow</strong> - From failing infrastructure, particularly after floods</li>
                <li><strong>Microplastics</strong> - High concentration flowing to the Indian Ocean</li>
                <li><strong>Industrial waste</strong> - From numerous factories along the river</li>
                <li><strong>Stormwater runoff</strong> - Carrying urban pollutants</li>
            </ul>
            
            <p><strong>Associated Health Risks:</strong></p>
            <ul>
                <li><strong>Bilharzia</strong> - Widespread in warm sections of the river</li>
                <li><strong>Bacterial infections</strong> - Including E. coli and potentially cholera</li>
                <li><strong>Viral infections</strong> - Including hepatitis from fecal contamination</li>
                <li><strong>Parasitic infections</strong> - From various waterborne parasites</li>
                <li><strong>Chemical exposure</strong> - Skin and respiratory irritation from industrial contaminants</li>
            </ul>
            
            <p><strong>High-Risk Areas:</strong> Downstream of Pietermaritzburg, informal settlements, river mouth</p>
            </div>
            """, unsafe_allow_html=True)
        
    with tab2:
        st.header("Coastal Waters & Ocean Areas")
        
        # Create dataframe for coastal areas
        coast_data = {
            "Coastal Area": [
                "Durban Beaches", 
                "Cape Town Atlantic Seaboard", 
                "False Bay", 
                "Port Elizabeth Beaches", 
                "Richards Bay",
                "Saldanha Bay",
                "East London Beaches",
                "Mossel Bay",
                "St. Lucia Estuary",
                "Knysna Lagoon"
            ],
            "Province": [
                "KwaZulu-Natal", 
                "Western Cape", 
                "Western Cape", 
                "Eastern Cape", 
                "KwaZulu-Natal",
                "Western Cape",
                "Eastern Cape",
                "Western Cape",
                "KwaZulu-Natal",
                "Western Cape"
            ],
            "Main Contaminants": [
                "Sewage, E. coli, microplastics, industrial discharge", 
                "Sewage overflow, microplastics, stormwater runoff", 
                "Sewage, agricultural runoff, microplastics", 
                "Industrial discharge, harbor contaminants, sewage",
                "Industrial chemicals, port activities, dredging",
                "Heavy metals, industrial discharge, microplastics",
                "Sewage, urban runoff, industrial waste",
                "Shipping waste, urban runoff, agricultural chemicals",
                "Agricultural runoff, mining impacts upstream",
                "Urban runoff, sewage leaks, microplastics"
            ],
            "Health Risk Level": [8, 6, 7, 7, 9, 7, 7, 5, 6, 6]
        }
        
        coast_df = pd.DataFrame(coast_data)
        
        # Create sortable table for coastal areas
        st.dataframe(
            coast_df,
            column_config={
                "Coastal Area": st.column_config.TextColumn("Coastal Area", width="medium"),
                "Province": st.column_config.TextColumn("Province", width="medium"),
                "Main Contaminants": st.column_config.TextColumn("Key Pollutants", width="large"),
                "Health Risk Level": st.column_config.ProgressColumn(
                    "Health Risk (1-10)",
                    min_value=0,
                    max_value=10,
                    format="%d",
                    help="Health risk level from 1 (low) to 10 (severe)"
                ),
            },
            use_container_width=True,
            hide_index=True,
        )
        
        # Detailed information on high-risk coastal areas
        st.subheader("High-Risk Coastal Areas - Detailed Information")
        
        with st.expander("Durban Beaches", expanded=True):
            st.markdown("""
            <div style='font-size:18px;'>
            <p><strong>Location:</strong> KwaZulu-Natal coastline from Umhlanga to Amanzimtoti</p>
            <p><strong>Main Uses:</strong> Religious ceremonies (Shembe baptisms, Hindu ceremonies), traditional cleansing</p>
            
            <p><strong>Primary Contaminants:</strong></p>
            <ul>
                <li><strong>Sewage</strong> - Recurring contamination from damaged infrastructure, particularly after the 2022 floods</li>
                <li><strong>E. coli</strong> - Frequently exceeds safe levels, especially near river mouths</li>
                <li><strong>Industrial effluent</strong> - From South Durban Industrial Basin</li>
                <li><strong>Microplastics</strong> - High concentrations in sand and water</li>
                <li><strong>Port pollution</strong> - From Durban harbor (Africa's busiest port)</li>
            </ul>
            
            <p><strong>Associated Health Risks:</strong></p>
            <ul>
                <li><strong>Skin infections</strong> - Including MRSA (antibiotic-resistant bacteria)</li>
                <li><strong>Gastrointestinal illness</strong> - From ingestion during swimming/immersion</li>
                <li><strong>Respiratory irritation</strong> - From aerosolized toxins and bacteria</li>
                <li><strong>Eye/ear infections</strong> - Common after sea immersion in contaminated areas</li>
            </ul>
            
            <p><strong>High-Risk Areas:</strong> Blue Lagoon (Umgeni River mouth), Isipingo Beach, beaches near stormwater outflows</p>
            <p><strong>Status:</strong> Many beaches periodically closed due to contamination, especially after rainfall</p>
            </div>
            """, unsafe_allow_html=True)
            
        with st.expander("Richards Bay"):
            st.markdown("""
            <div style='font-size:18px;'>
            <p><strong>Location:</strong> Northern KwaZulu-Natal coast</p>
            <p><strong>Main Uses:</strong> Traditional fishing, ceremonial activities, recreational use</p>
            
            <p><strong>Primary Contaminants:</strong></p>
            <ul>
                <li><strong>Industrial chemicals</strong> - From the extensive Richards Bay Industrial Development Zone</li>
                <li><strong>Heavy metals</strong> - From mining operations and processing</li>
                <li><strong>Coal dust</strong> - From coal terminal operations</li>
                <li><strong>Port contaminants</strong> - Oil, fuel, and antifouling compounds</li>
                <li><strong>Dredging impacts</strong> - Resuspension of contaminated sediments</li>
            </ul>
            
            <p><strong>Associated Health Risks:</strong></p>
            <ul>
                <li><strong>Respiratory issues</strong> - From air pollution and industrial emissions</li>
                <li><strong>Heavy metal exposure</strong> - Through water contact and seafood consumption</li>
                <li><strong>Chemical burns</strong> - From direct contact with industrial contaminants</li>
                <li><strong>Endocrine disruption</strong> - From industrial chemicals</li>
            </ul>
            
            <p><strong>High-Risk Areas:</strong> Near industrial discharges, port facilities, and the coal terminal</p>
            </div>
            """, unsafe_allow_html=True)
        
    with tab3:
        st.header("Health Guidance for Water Users")
        
        # Create sections for health guidance
        st.subheader("Understanding Water-Related Health Risks")
        
        # Create expandable sections for different diseases
        with st.expander("Bilharzia (Schistosomiasis)", expanded=True):
            st.markdown("""
            <div style='font-size:18px;'>
            <p><strong>Cause:</strong> Parasite transmitted through freshwater snails, enters through skin</p>
            
            <p><strong>Common in:</strong> Warm freshwater bodies across eastern and northern SA, particularly:</p>
            <ul>
                <li>KwaZulu-Natal rivers and dams</li>
                <li>Mpumalanga water bodies</li>
                <li>Limpopo River system</li>
                <li>Parts of Eastern Cape</li>
            </ul>
            
            <p><strong>Symptoms:</strong></p>
            <ul>
                <li><strong>Early:</strong> Skin rash, itching, fever, chills, muscle aches (2-3 weeks after exposure)</li>
                <li><strong>Chronic:</strong> Abdominal pain, blood in urine or stool, liver/bladder damage</li>
            </ul>
            
            <p><strong>Prevention:</strong></p>
            <ul>
                <li>Avoid freshwater swimming in endemic areas</li>
                <li>If contact is necessary for ceremonies, minimize time in water</li>
                <li>Dry skin vigorously with towel immediately after exposure</li>
                <li>Consider praziquantel treatment if exposure was unavoidable</li>
            </ul>
            
            <p><strong>Safety note:</strong> Treatment is available at clinics and hospitals. Early treatment prevents serious complications.</p>
            </div>
            """, unsafe_allow_html=True)
            
        with st.expander("E. coli & Bacterial Infections"):
            st.markdown("""
            <div style='font-size:18px;'>
            <p><strong>Cause:</strong> Bacteria from sewage contamination, mainly human and animal waste</p>
            
            <p><strong>Common in:</strong></p>
            <ul>
                <li>Most urban rivers (Jukskei, Vaal, Umgeni)</li>
                <li>Areas downstream of informal settlements</li>
                <li>Rivers after heavy rainfall</li>
                <li>Coastal areas near river mouths</li>
            </ul>
            
            <p><strong>Symptoms:</strong></p>
            <ul>
                <li>Severe diarrhea (sometimes bloody)</li>
                <li>Abdominal cramps</li>
                <li>Vomiting</li>
                <li>Fever</li>
                <li>Kidney failure in severe cases (especially with E. coli O157:H7)</li>
            </ul>
            
            <p><strong>Prevention:</strong></p>
            <ul>
                <li>Avoid water contact when visible pollution (foaming, odor, discoloration)</li>
                <li>Don't perform ceremonies in water after rainfall</li>
                <li>Cover any cuts or wounds with waterproof dressings</li>
                <li>Avoid swallowing water</li>
                <li>Shower immediately after contact</li>
            </ul>
            </div>
            """, unsafe_allow_html=True)
            
        with st.expander("Chemical Contamination"):
            st.markdown("""
            <div style='font-size:18px;'>
            <p><strong>Cause:</strong> Industrial discharge, mining waste, agricultural runoff</p>
            
            <p><strong>Common in:</strong></p>
            <ul>
                <li>Rivers downstream of mining operations (Vaal, Olifants, Crocodile)</li>
                <li>Industrial areas (Durban South Basin, Vaal Triangle, Richards Bay)</li>
                <li>Agricultural regions (pesticide and fertilizer runoff)</li>
            </ul>
            
            <p><strong>Symptoms:</strong></p>
            <ul>
                <li><strong>Acute:</strong> Skin/eye irritation, nausea, vomiting, headaches, dizziness</li>
                <li><strong>Chronic:</strong> Organ damage, developmental issues, cancer risk, neurological problems</li>
            </ul>
            
            <p><strong>Prevention:</strong></p>
            <ul>
                <li>Avoid water with unusual colors, foaming, or chemical odors</li>
                <li>Research local water quality before ceremonies</li>
                <li>Seek alternative sites for religious practices when possible</li>
                <li>Wash thoroughly with clean water and soap after any contact</li>
                <li>Do not eat fish from heavily contaminated rivers</li>
            </ul>
            </div>
            """, unsafe_allow_html=True)
            
        with st.expander("Heavy Metal Poisoning"):
            st.markdown("""
            <div style='font-size:18px;'>
            <p><strong>Cause:</strong> Exposure to mercury, lead, arsenic, cadmium from mining and industrial activities</p>
            
            <p><strong>Common in:</strong></p>
            <ul>
                <li>Acid mine drainage affected rivers (Vaal, Olifants, Crocodile)</li>
                <li>Waters near gold mining operations</li>
                <li>Industrial zones with metal processing</li>
                <li>Fish and shellfish from contaminated waters</li>
            </ul>
            
            <p><strong>Symptoms:</strong></p>
            <ul>
                <li><strong>Mercury:</strong> Neurological issues, tremors, cognitive impairment</li>
                <li><strong>Lead:</strong> Developmental delays, anemia, kidney damage, neurological effects</li>
                <li><strong>Arsenic:</strong> Skin lesions, peripheral neuropathy, cancer risk</li>
                <li><strong>Cadmium:</strong> Kidney damage, bone disease, respiratory issues</li>
            </ul>
            
            <p><strong>Prevention:</strong></p>
            <ul>
                <li>Avoid performing rituals in waters near mining operations</li>
                <li>Be careful with fish consumption from affected waters</li>
                <li>Pregnant women and children should be especially cautious</li>
                <li>Consider alternative water sources for ceremonial use when possible</li>
            </ul>
            </div>
            """, unsafe_allow_html=True)
            
        # Guidance for safer practices
        st.subheader("Guidelines for Religious & Traditional Water Users")
        
        # Create two columns
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("""
            <div style='background-color:#E3F2FD; padding:15px; border-radius:10px;'>
            <h4 style='font-size:20px; text-align:center;'>Before Water Contact</h4>
            <ul style='font-size:16px;'>
                <li>Research water quality at intended site (check local health department)</li>
                <li>Consult updated maps of high-risk areas</li>
                <li>Avoid contact for 2-3 days after heavy rainfall</li>
                <li>Choose upstream locations away from urban areas when possible</li>
                <li>Consider alternatives for vulnerable people (children, elderly, pregnant women)</li>
                <li>Cover any open wounds with waterproof bandages</li>
                <li>Identify clean water source for washing afterward</li>
            </ul>
            </div>
            """, unsafe_allow_html=True)
            
        with col2:
            st.markdown("""
            <div style='background-color:#E8F5E9; padding:15px; border-radius:10px;'>
            <h4 style='font-size:20px; text-align:center;'>After Water Contact</h4>
            <ul style='font-size:16px;'>
                <li>Shower or wash with clean water and soap immediately</li>
                <li>Pay special attention to areas that were directly immersed</li>
                <li>Rinse mouth thoroughly if water entered (do not swallow)</li>
                <li>Change into clean clothing</li>
                <li>Monitor for symptoms (diarrhea, fever, rash, unusual fatigue)</li>
                <li>Seek medical attention if symptoms develop</li>
                <li>Inform healthcare providers about water exposure</li>
            </ul>
            </div>
            """, unsafe_allow_html=True)
            
        # Safer alternatives section
        st.markdown("""
        <div style='background-color:#FFF8E1; padding:20px; border-radius:10px; margin-top:20px;'>
        <h4 style='font-size:22px; text-align:center;'>Safer Alternatives for Ceremonies</h4>
        <p style='font-size:18px;'>When traditional water bodies are too contaminated, consider these alternatives while respecting religious significance:</p>
        <ul style='font-size:18px;'>
            <li><strong>Protected natural areas</strong> - Many nature reserves have cleaner water sources</li>
            <li><strong>Designated ceremonial pools</strong> - Some municipalities have created safer alternatives</li>
            <li><strong>Symbolic representations</strong> - Some communities use smaller amounts of purified water</li>
            <li><strong>Timing ceremonies</strong> - Performing rituals during drier seasons when contamination is lower</li>
            <li><strong>Community water monitoring</strong> - Working with scientists to identify safer locations</li>
            <li><strong>Advocacy for clean-up</strong> - Engaging with authorities to protect traditional sites</li>
        </ul>
        </div>
        """, unsafe_allow_html=True)
        
    with tab4:
        st.header("Guidance for Traditional & Cultural Practices")
        
        # Information on traditional water uses
        st.markdown("""
        <div style='font-size:18px;'>
        <p>South Africa's waters hold deep cultural and spiritual significance for many communities. Traditional and religious practices involving water include:</p>
        <ul>
            <li><strong>Baptism ceremonies</strong> - Christian denominations including Zionist, Shembe, and Apostolic churches</li>
            <li><strong>Cleansing rituals</strong> - Traditional healing ceremonies to remove spiritual impurities</li>
            <li><strong>Ancestral communication</strong> - Waters viewed as connection points to ancestors</li>
            <li><strong>Hindu ceremonies</strong> - Including immersion of sacred items</li>
            <li><strong>Initiation practices</strong> - Some cultures incorporate river cleansing during transitions</li>
            <li><strong>Traditional fishing</strong> - For both sustenance and cultural purposes</li>
            <li><strong>Collection of medicinal plants</strong> - Many grow near water bodies</li>
        </ul>
        </div>
        """, unsafe_allow_html=True)
        
        # Specific guidance for different traditions
        st.subheader("Guidance for Specific Practices")
        
        # Create expandable sections for different practices
        with st.expander("Baptism & Immersion Ceremonies", expanded=True):
            st.markdown("""
            <div style='font-size:18px;'>
            <p><strong>Concerns:</strong> Full-body immersion creates maximum exposure risk to contaminants</p>
            
            <p><strong>Guidance:</strong></p>
            <ul>
                <li>Consider moving ceremonies to safer water bodies (upper catchments, protected areas)</li>
                <li>Avoid immersion after rainfall when pollution levels peak</li>
                <li>Keep ceremonies brief to minimize exposure time</li>
                <li>Choose early morning for ceremonies (before water is disturbed)</li>
                <li>Consider adaptations such as partial rather than full immersion</li>
                <li>Rinse with clean water immediately after ceremony</li>
                <li>Keep clean clothing available for immediate change</li>
            </ul>
            
            <p><strong>Safer Locations:</strong></p>
            <ul>
                <li><strong>Western Cape:</strong> Upper reaches of Berg and Breede rivers</li>
                <li><strong>Eastern Cape:</strong> Upper Keiskamma, cleaner sections of Great Kei</li>
                <li><strong>KZN:</strong> Protected areas of Midmar Dam, upper Umgeni (above Midmar)</li>
                <li><strong>Gauteng:</strong> Designated areas of Hartbeespoort (away from algal blooms)</li>
                <li><strong>Free State:</strong> Upper sections of Caledon River</li>
            </ul>
            </div>
            """, unsafe_allow_html=True)
            
        with st.expander("Fishing & Food Collection"):
            st.markdown("""
            <div style='font-size:18px;'>
            <p><strong>Concerns:</strong> Bioaccumulation of toxins in fish and shellfish from contaminated waters</p>
            
            <p><strong>Guidance:</strong></p>
            <ul>
                <li>Be selective about fishing locations - research local pollution patterns</li>
                <li>Avoid fishing near industrial outflows, mining areas, and urban centers</li>
                <li>Be cautious with bottom-feeding fish which accumulate more toxins</li>
                <li>Remove skin and fatty tissues where many contaminants concentrate</li>
                <li>Limit consumption of fish from known contaminated waters</li>
                <li>Pregnant women and children should be especially careful with fish from urban rivers</li>
            </ul>
            
            <p><strong>High-Risk Species:</strong></p>
            <ul>
                <li><strong>Barbel/catfish</strong> - Bottom feeders that accumulate heavy metals</li>
                <li><strong>Carp</strong> - Concentrate pollutants in fatty tissues</li>
                <li><strong>Eels</strong> - High fat content and long lifespan leads to bioaccumulation</li>
                <li><strong>Shellfish</strong> - Filter feeders concentrate contaminants</li>
            </ul>
            
            <p><strong>Safer Options:</strong></p>
            <ul>
                <li>Smaller, younger fish generally contain lower contaminant levels</li>
                <li>Fish from flowing streams tend to have lower contamination than those from stagnant waters</li>
                <li>Upland waters typically have lower pollution levels</li>
            </ul>
            </div>
            """, unsafe_allow_html=True)
            
        with st.expander("Collection of Medicinal Plants"):
            st.markdown("""
            <div style='font-size:18px;'>
            <p><strong>Concerns:</strong> Plants can absorb and concentrate pollutants from water and soil</p>
            
            <p><strong>Guidance:</strong></p>
            <ul>
                <li>Avoid collecting water plants from known contaminated rivers</li>
                <li>Choose upstream locations away from urban and industrial areas</li>
                <li>Wash plants thoroughly with clean water before preparation</li>
                <li>Be cautious with plants known to accumulate toxins (water hyacinth, reeds)</li>
                <li>Consider cultivating important medicinal plants in controlled environments</li>
                <li>Document and share knowledge about safer collection areas</li>
            </ul>
            
            <p><strong>Plants of Concern:</strong></p>
            <ul>
                <li><strong>Impila (Callilepis laureola)</strong> - Can concentrate soil contaminants</li>
                <li><strong>Water lily species</strong> - Often grow in stagnant, potentially contaminated waters</li>
                <li><strong>Reeds and sedges</strong> - May absorb heavy metals from sediments</li>
                <li><strong>River pumpkin (Gunnera perpensa)</strong> - Often found in areas affected by agricultural runoff</li>
            </ul>
            </div>
            """, unsafe_allow_html=True)
        
        # ECOSYSTEM DESTRUCTION SECTION
        st.header("Ecosystem Destruction from Chemical Pollutants")
        st.write("Detergents, household chemicals, industrial effluent, medical waste, and sewage have devastated South African water ecosystems")
        
        # Create tabs for different types of pollutants
        pollutants_tab1, pollutants_tab2, pollutants_tab3, pollutants_tab4, pollutants_tab5 = st.tabs(["Detergents", "Household Chemicals", "Industrial Effluent", "Medical Waste", "Sewage"])
        
        with pollutants_tab1:
            st.markdown("<h3 style='font-size:24px; color:#D32F2F;'>DETERGENTS & SURFACTANTS</h3>", unsafe_allow_html=True)
            
            # Two columns for content
            p1_col1, p1_col2 = st.columns(2)
            
            with p1_col1:
                st.markdown("<h4 style='font-size:20px;'>Common Examples in SA Waters</h4>", unsafe_allow_html=True)
                st.markdown("""
                <ul style='font-size:18px;'>
                    <li><strong>Linear Alkylbenzene Sulfonates (LAS)</strong> - From laundry detergents</li>
                    <li><strong>Sodium Lauryl Sulfate (SLS)</strong> - Common in cleaning products</li>
                    <li><strong>Nonylphenol ethoxylates</strong> - Industrial cleaners and detergents</li>
                    <li><strong>Quaternary ammonium compounds</strong> - Fabric softeners, disinfectants</li>
                    <li><strong>Phosphates</strong> - Builders in washing powders (despite regulations)</li>
                </ul>
                """, unsafe_allow_html=True)
                
                st.markdown("<h4 style='font-size:20px;'>Most Affected SA Rivers</h4>", unsafe_allow_html=True)
                st.markdown("""
                <ul style='font-size:18px;'>
                    <li><strong>Jukskei River</strong> - Extreme detergent levels from informal settlements</li>
                    <li><strong>Hennops River</strong> - Visible foam banks up to 1 meter high</li>
                    <li><strong>Klip River</strong> - High surfactant concentrations from urban areas</li>
                    <li><strong>Lower Vaal</strong> - Agricultural and household detergent accumulation</li>
                </ul>
                """, unsafe_allow_html=True)
            
            with p1_col2:
                st.markdown("<h4 style='font-size:20px;'>Ecosystem Destruction</h4>", unsafe_allow_html=True)
                st.markdown("""
                <div style='font-size:18px;'>
                <p><strong>Fish Mortality:</strong> Detergents destroy the protective mucus layer on fish gills and skin, leading to mass die-offs in heavily contaminated areas like the Hennops River.</p>
                
                <p><strong>Algae Blooms:</strong> Phosphates in detergents trigger explosive algal growth, leading to oxygen depletion and dead zones in water bodies. The Hartbeespoort Dam is severely affected by this process.</p>
                
                <p><strong>Food Web Disruption:</strong> Surfactants kill small invertebrates and insects that form the base of the aquatic food chain, collapsing entire ecosystems. The lower Umgeni River has lost over 60% of its insect diversity due to detergent pollution.</p>
                
                <p><strong>Endocrine Disruption:</strong> Alkylphenols in detergents cause reproductive abnormalities in fish, including intersex conditions documented in the Vaal River system.</p>
                </div>
                
                <div style='background-color:#FFEBEE; padding:15px; border-radius:10px; margin-top:15px;'>
                <h5 style='font-size:18px;'>DOCUMENTED ECOSYSTEM COLLAPSE</h5>
                <p style='font-size:16px;'>The Hennops River system has experienced nearly complete ecosystem collapse in certain sections, with researchers documenting a 95% loss of fish species and 89% loss of macroinvertebrate diversity between 2000 and 2022.</p>
                </div>
                """, unsafe_allow_html=True)
        
        with pollutants_tab2:
            st.markdown("<h3 style='font-size:24px; color:#D32F2F;'>HOUSEHOLD CHEMICALS</h3>", unsafe_allow_html=True)
            
            # Two columns for content
            p2_col1, p2_col2 = st.columns(2)
            
            with p2_col1:
                st.markdown("<h4 style='font-size:20px;'>Common Examples in SA Waters</h4>", unsafe_allow_html=True)
                st.markdown("""
                <ul style='font-size:18px;'>
                    <li><strong>Bleach (Sodium Hypochlorite)</strong> - Laundry and household disinfectant</li>
                    <li><strong>Ammonia</strong> - Window and floor cleaners</li>
                    <li><strong>Triclosan</strong> - Antibacterial products</li>
                    <li><strong>Parabens</strong> - Preservatives in personal care products</li>
                    <li><strong>Phthalates</strong> - Fragrances, plasticizers in cleaning products</li>
                    <li><strong>Synthetic dyes</strong> - From clothing and textile washing</li>
                    <li><strong>PFAS compounds</strong> - From stain-resistant treatments</li>
                </ul>
                """, unsafe_allow_html=True)
                
                st.markdown("<h4 style='font-size:20px;'>Most Affected Water Bodies</h4>", unsafe_allow_html=True)
                st.markdown("""
                <ul style='font-size:18px;'>
                    <li><strong>Urban waterways</strong> - Especially in townships with inadequate sanitation</li>
                    <li><strong>Coastal lagoons</strong> - Saldanha Bay, parts of Knysna Lagoon</li>
                    <li><strong>Reservoirs</strong> - Vaal Dam, Hartbeespoort Dam</li>
                </ul>
                """, unsafe_allow_html=True)
            
            with p2_col2:
                st.markdown("<h4 style='font-size:20px;'>Ecosystem Destruction</h4>", unsafe_allow_html=True)
                st.markdown("""
                <div style='font-size:18px;'>
                <p><strong>Chlorine Toxicity:</strong> Bleach discharged into waterways creates chlorinated compounds that are highly toxic to aquatic life. These compounds have been detected at lethal levels for fish in parts of the Jukskei River.</p>
                
                <p><strong>Bioaccumulation:</strong> Phthalates and parabens concentrate in fish tissues, causing developmental abnormalities and reproductive failure. Studies of yellowfish in the Vaal showed 78% contained detectable levels of these compounds.</p>
                
                <p><strong>Antimicrobial Resistance:</strong> Triclosan and other antibacterials create selective pressure that develops resistant bacterial strains in water bodies, altering microbial communities essential for healthy ecosystems.</p>
                
                <p><strong>Amphibian Decline:</strong> Household chemicals have been implicated in the dramatic decline of frog populations around urban water bodies, with metamorphosis failure rates of over 70% documented in contaminated wetlands around Gauteng.</p>
                </div>
                
                <div style='background-color:#FFEBEE; padding:15px; border-radius:10px; margin-top:15px;'>
                <h5 style='font-size:18px;'>CASCADING ECOLOGICAL EFFECTS</h5>
                <p style='font-size:16px;'>The loss of amphibians from household chemical pollution has led to population explosions of their prey (mosquitoes, midges) while predators like certain birds and snakes have declined, demonstrating the cascading effects through the food web.</p>
                </div>
                """, unsafe_allow_html=True)
                
        with pollutants_tab3:
            st.markdown("<h3 style='font-size:24px; color:#D32F2F;'>INDUSTRIAL EFFLUENT</h3>", unsafe_allow_html=True)
            
            # Two columns for content
            p3_col1, p3_col2 = st.columns(2)
            
            with p3_col1:
                st.markdown("<h4 style='font-size:20px;'>Common Industrial Pollutants</h4>", unsafe_allow_html=True)
                st.markdown("""
                <ul style='font-size:18px;'>
                    <li><strong>Heavy metals</strong> - Mercury, lead, chromium, cadmium</li>
                    <li><strong>Acids & alkalis</strong> - From manufacturing processes</li>
                    <li><strong>Petroleum hydrocarbons</strong> - Oil, fuel, lubricants</li>
                    <li><strong>Phenols</strong> - From industrial processes</li>
                    <li><strong>PCBs</strong> - From electrical equipment</li>
                    <li><strong>Solvents</strong> - Toluene, benzene, xylenes</li>
                    <li><strong>Cyanide compounds</strong> - From mining operations</li>
                    <li><strong>Dyes & pigments</strong> - From textile industry</li>
                </ul>
                """, unsafe_allow_html=True)
                
                st.markdown("<h4 style='font-size:20px;'>Industrial Pollution Hotspots</h4>", unsafe_allow_html=True)
                st.markdown("""
                <ul style='font-size:18px;'>
                    <li><strong>Vaal River (Vanderbijlpark/Vereeniging)</strong> - Steel industry</li>
                    <li><strong>Olifants River</strong> - Mining activity (coal and other)</li>
                    <li><strong>Buffalo River (East London)</strong> - Manufacturing district</li>
                    <li><strong>Durban South Basin waterways</strong> - Petrochemical industry</li>
                    <li><strong>Blesbokspruit</strong> - Mining and industrial contamination</li>
                    <li><strong>Richards Bay</strong> - Heavy industry and port activities</li>
                </ul>
                """, unsafe_allow_html=True)
            
            with p3_col2:
                st.markdown("<h4 style='font-size:20px;'>Ecosystem Destruction</h4>", unsafe_allow_html=True)
                st.markdown("""
                <div style='font-size:18px;'>
                <p><strong>Heavy Metal Poisoning:</strong> Metals like mercury and lead from mining and industrial operations bioaccumulate through the food chain. In the Olifants River, crocodile populations crashed by 90% due to pansteatitis from contaminated fish consumption.</p>
                
                <p><strong>Acid Mine Drainage:</strong> Creates devastating acidification of waterways, dissolving more metals in the process. AMD has rendered entire stretches of the Blesbokspruit biologically dead, with pH levels recorded as low as 3.2.</p>
                
                <p><strong>Persistent Organic Pollutants:</strong> PCBs, dioxins, and furans from industrial processes remain in the environment for decades. Birds feeding in the Vaal River system show egg-shell thinning and nesting failure rates of up to 60% in heavily contaminated areas.</p>
                
                <p><strong>Thermal Pollution:</strong> Hot water discharge from industrial cooling processes disrupts temperature-sensitive aquatic life cycles. Abrupt temperature increases of up to 8°C have been recorded downstream of power stations on the Komati and Olifants Rivers.</p>
                </div>
                
                <div style='background-color:#FFEBEE; padding:15px; border-radius:10px; margin-top:15px;'>
                <h5 style='font-size:18px;'>DEGRADATION OF ESSENTIAL ECOSYSTEMS</h5>
                <p style='font-size:16px;'>The Blesbokspruit, once a RAMSAR wetland of international importance, has been so severely degraded by industrial pollution that it was placed on the Montreux Record of threatened wetlands, with an estimated 78% loss of its ecological functioning.</p>
                </div>
                """, unsafe_allow_html=True)
                
        with pollutants_tab4:
            st.markdown("<h3 style='font-size:24px; color:#D32F2F;'>MEDICAL WASTE & PHARMACEUTICALS</h3>", unsafe_allow_html=True)
            
            # Two columns for content
            p4_col1, p4_col2 = st.columns(2)
            
            with p4_col1:
                st.markdown("<h4 style='font-size:20px;'>Common Medical Pollutants</h4>", unsafe_allow_html=True)
                st.markdown("""
                <ul style='font-size:18px;'>
                    <li><strong>Antibiotics</strong> - Various classes including fluoroquinolones</li>
                    <li><strong>Analgesics</strong> - Painkillers including diclofenac</li>
                    <li><strong>Hormones</strong> - Estrogens from contraceptives</li>
                    <li><strong>Antidepressants</strong> - Various SSRIs</li>
                    <li><strong>Beta-blockers</strong> - Heart medications</li>
                    <li><strong>Antiretrovirals</strong> - HIV medications (high usage in SA)</li>
                    <li><strong>Disinfectants</strong> - From hospitals and clinics</li>
                    <li><strong>Contrast media</strong> - From imaging procedures</li>
                    <li><strong>Physical medical waste</strong> - Syringes, vials, packaging</li>
                </ul>
                """, unsafe_allow_html=True)
                
                st.markdown("<h4 style='font-size:20px;'>Problem Areas</h4>", unsafe_allow_html=True)
                st.markdown("""
                <ul style='font-size:18px;'>
                    <li><strong>Rivers downstream of major hospitals</strong> - Especially in Gauteng and urban KZN</li>
                    <li><strong>Receiving waters for WWTW</strong> - Many treatment plants cannot remove pharmaceuticals</li>
                    <li><strong>Informal dumping sites</strong> - Where medical waste is illegally disposed</li>
                </ul>
                """, unsafe_allow_html=True)
            
            with p4_col2:
                st.markdown("<h4 style='font-size:20px;'>Ecosystem Destruction</h4>", unsafe_allow_html=True)
                st.markdown("""
                <div style='font-size:18px;'>
                <p><strong>Endocrine Disruption:</strong> Hormones from contraceptives and other medications have caused widespread feminization of male fish in rivers downstream of wastewater treatment works. In the Roodeplaat Dam, studies found up to 45% of male Sharptooth Catfish showed intersex characteristics.</p>
                
                <p><strong>Antimicrobial Resistance:</strong> Antibiotics in waterways create reservoirs of resistant bacteria. Samples from the Umgeni River showed resistance genes present in 87% of bacterial isolates, threatening both wildlife and humans who contact the water.</p>
                
                <p><strong>Behavioral Changes:</strong> Antidepressants and other psychoactive drugs alter fish behavior, affecting feeding, reproduction, and predator avoidance. Tilapia exposed to water downstream from Johannesburg hospitals showed 30% reduction in predator response behaviors.</p>
                
                <p><strong>Bioaccumulation:</strong> Pharmaceuticals concentrate in aquatic organisms and transfer up food chains. Diclofenac has been found in muscle tissue of fish from the Hartbeespoort Dam at levels up to 72 μg/kg.</p>
                </div>
                
                <div style='background-color:#FFEBEE; padding:15px; border-radius:10px; margin-top:15px;'>
                <h5 style='font-size:18px;'>THE INVISIBLE THREAT</h5>
                <p style='font-size:16px;'>Unlike visible pollution, pharmaceutical contamination operates at extremely low concentrations (parts per billion) yet causes significant ecological damage. A 2020 survey of South African rivers found 37 different pharmaceutical compounds, with some having biological effects at just 1 ng/L (one part per trillion).</p>
                </div>
                """, unsafe_allow_html=True)
                
        with pollutants_tab5:
            st.markdown("<h3 style='font-size:24px; color:#D32F2F;'>SEWAGE & PATHOGENS</h3>", unsafe_allow_html=True)
            
            # Two columns for content
            p5_col1, p5_col2 = st.columns(2)
            
            with p5_col1:
                st.markdown("<h4 style='font-size:20px;'>Sewage Components</h4>", unsafe_allow_html=True)
                st.markdown("""
                <ul style='font-size:18px;'>
                    <li><strong>Organic matter</strong> - Human waste, food waste</li>
                    <li><strong>Nutrients</strong> - Nitrogen and phosphorus compounds</li>
                    <li><strong>Bacteria</strong> - E. coli, Salmonella, etc.</li>
                    <li><strong>Viruses</strong> - Hepatitis, norovirus, enteroviruses</li>
                    <li><strong>Protozoa</strong> - Cryptosporidium, Giardia</li>
                    <li><strong>Helminths (worms)</strong> - Various parasitic species</li>
                    <li><strong>Microplastics</strong> - From hygiene products and clothing</li>
                    <li><strong>Household chemicals</strong> - Everything poured down drains</li>
                </ul>
                """, unsafe_allow_html=True)
                
                st.markdown("<h4 style='font-size:20px;'>Crisis Areas</h4>", unsafe_allow_html=True)
                st.markdown("""
                <ul style='font-size:18px;'>
                    <li><strong>Vaal River System</strong> - Receiving sewage from failing Emfuleni infrastructure</li>
                    <li><strong>Umgeni River & Durban beaches</strong> - Sewage infrastructure failures</li>
                    <li><strong>Cape Town coastal areas</strong> - Storm overflow and infrastructure failures</li>
                    <li><strong>Informal settlements nationwide</strong> - Lack of adequate sanitation</li>
                    <li><strong>Lower Olifants River</strong> - Untreated sewage from growing towns</li>
                </ul>
                """, unsafe_allow_html=True)
                
                # Add a striking visual element - E. coli levels comparison
                st.markdown("""
                <div style='background-color:#EDE7F6; padding:15px; border-radius:10px; margin-top:15px;'>
                <h5 style='font-size:18px; text-align:center;'>E. COLI LEVELS IN CRISIS AREAS (CFU/100ml)</h5>
                <ul style='font-size:16px;'>
                    <li><strong>Safe swimming limit:</strong> 500</li>
                    <li><strong>Northern Vaal sections:</strong> 241,000</li>
                    <li><strong>Umgeni River mouth:</strong> 1,920,000</li>
                    <li><strong>Diepsloot informal area:</strong> 8,400,000</li>
                </ul>
                </div>
                """, unsafe_allow_html=True)
            
            with p5_col2:
                st.markdown("<h4 style='font-size:20px;'>Ecosystem Destruction</h4>", unsafe_allow_html=True)
                st.markdown("""
                <div style='font-size:18px;'>
                <p><strong>Oxygen Depletion:</strong> Decomposing sewage consumes oxygen, suffocating aquatic life. The middle Vaal has experienced fish kills affecting tens of thousands of fish when dissolved oxygen levels dropped below 2 mg/L due to sewage pollution.</p>
                
                <p><strong>Eutrophication:</strong> Nutrients from sewage cause explosive algal growth, creating toxic conditions. Hartbeespoort Dam is over 70% covered by toxic cyanobacterial blooms during summer, rendering the water unusable and eliminating native aquatic plant communities.</p>
                
                <p><strong>Pathogen Transmission to Wildlife:</strong> Bacteria and viruses from sewage infect wildlife populations. Significant die-offs of Cape clawless otters have been linked to infections from human sewage pathogens in the Western Cape.</p>
                
                <p><strong>Habitat Destruction:</strong> Sewage smothers river and lake beds with sludge, destroying breeding grounds and feeding areas. In parts of the Klip River, sediment oxygen demand has increased 600% due to accumulated organic matter from sewage.</p>
                </div>
                
                <div style='background-color:#FFEBEE; padding:15px; border-radius:10px; margin-top:15px;'>
                <h5 style='font-size:18px;'>SYSTEMIC COLLAPSE</h5>
                <p style='font-size:16px;'>The Middle Vaal River section has experienced what ecologists term "trophic cascade collapse" due to sewage pollution. The ecological community has simplified from 128 distinct species in 1960 to just 21 highly tolerant species today, representing a 84% loss of biodiversity.</p>
                </div>
                
                <div style='background-color:#E8F5E9; padding:15px; border-radius:10px; margin-top:15px;'>
                <h5 style='font-size:18px;'>TRADITIONAL USES AT RISK</h5>
                <p style='font-size:16px;'>Communities depending on rivers for religious ceremonies, traditional fishing, and medicinal plants have seen sacred waterways rendered unusable. In KwaZulu-Natal, approximately 60% of traditional healers report being unable to collect certain essential medicinal water plants that have disappeared from polluted areas they previously used.</p>
                </div>
                """, unsafe_allow_html=True)
        
        # FOOD SOURCE IMPACTS
        st.header("Destruction of Food Sources")
        
        # Create two columns for food impacts
        food_col1, food_col2 = st.columns(2)
        
        with food_col1:
            st.markdown("<h3 style='font-size:24px;'>Aquatic Food Source Collapse</h3>", unsafe_allow_html=True)
            st.markdown("""
            <div style='font-size:18px;'>
            <p><strong>Fish Population Decline:</strong></p>
            <ul>
                <li>Yellowfish populations in the Vaal River system have declined by approximately 90% since 1960</li>
                <li>Native tilapia species in the Olifants River basin are locally extinct in 46% of their historical range</li>
                <li>Commercial fishing operations at Hartbeespoort Dam reported 78% reduction in catch between 1980-2020</li>
                <li>Of 24 fish species native to the Upper Vaal, only 7 can still be found in surveys</li>
            </ul>
            
            <p><strong>Shellfish Contamination:</strong></p>
            <ul>
                <li>Mussels along KZN coast contain heavy metals exceeding safety limits at 37% of monitored sites</li>
                <li>Traditional shellfish harvesting has been prohibited at 22 previously productive coastal sites</li>
                <li>Subsistence harvesting of freshwater mussels in the Lower Vaal declared unsafe due to metal contamination</li>
            </ul>
            
            <p><strong>Edible Plants Affected:</strong></p>
            <ul>
                <li>Water lotus (<i>Nelumbo nucifera</i>) - Traditional food source now contains unsafe levels of metals at 12 major sites</li>
                <li>Water chestnuts - Disappeared from 68% of traditional harvesting areas</li>
                <li>Wild rice species - Shows toxic accumulation of mercury and arsenic in contaminated wetlands</li>
            </ul>
            </div>
            """, unsafe_allow_html=True)
        
        with food_col2:
            st.markdown("<h3 style='font-size:24px;'>Impacts on Traditional Communities</h3>", unsafe_allow_html=True)
            st.markdown("""
            <div style='font-size:18px;'>
            <p><strong>Loss of Subsistence Resources:</strong></p>
            <ul>
                <li>An estimated 300,000 South Africans historically relied on freshwater fish as a protein source</li>
                <li>Approximately 70% of traditional fishing grounds are now contaminated beyond safe consumption levels</li>
                <li>Rural communities in Limpopo reported 85% reduction in available fish protein from local sources</li>
                <li>Food security surveys indicate 35% reduction in protein intake among riverside communities due to fish contamination</li>
            </ul>
            
            <p><strong>Cultural Impact:</strong></p>
            <ul>
                <li>Traditional fishing knowledge and practices being lost as waterways become unusable</li>
                <li>Ceremonial uses of specific fish species impossible due to population collapses</li>
                <li>Intergenerational transmission of harvesting practices interrupted by contamination</li>
                <li>Sacred water bodies used for centuries no longer viable for ceremonies</li>
            </ul>
            
            <p><strong>Economic Consequences:</strong></p>
            <ul>
                <li>Small-scale commercial fishers in coastal communities have lost estimated R85 million in annual income</li>
                <li>Tourism income from recreational fishing has declined by 50-70% in heavily polluted regions</li>
                <li>Healthcare costs from consuming contaminated fish estimated at R125 million annually</li>
            </ul>
            </div>
            """, unsafe_allow_html=True)
        
        # Add a visual impact section with before/after description
        st.markdown("<h3 style='font-size:24px; text-align:center; margin-top:20px;'>ECOSYSTEM TRANSFORMATION</h3>", unsafe_allow_html=True)
        
        # Create three columns for before/after
        then_col1, then_col2, then_col3 = st.columns([1,2,1])
        
        with then_col2:
            st.markdown("""
            <div style='border:2px solid #1565C0; border-radius:10px; padding:15px; margin-bottom:15px;'>
            <h4 style='font-size:20px; color:#1565C0; text-align:center;'>HISTORICAL ECOSYSTEM - VAAL RIVER (1950s)</h4>
            <ul style='font-size:16px;'>
                <li>Clear water with visibility to 3 meters depth</li>
                <li>Abundant yellowfish, largemouth bream, and indigenous catfish</li>
                <li>Diverse aquatic vegetation supporting complex food webs</li>
                <li>Regular fish harvesting by local communities for subsistence</li>
                <li>Water suitable for direct consumption with minimal treatment</li>
                <li>Sandbank breeding areas for multiple fish species</li>
                <li>Abundant waterbirds including fish eagles and kingfishers</li>
                <li>Thriving recreational fishing industry</li>
            </ul>
            </div>
            
            <div style='border:2px solid #D32F2F; border-radius:10px; padding:15px;'>
            <h4 style='font-size:20px; color:#D32F2F; text-align:center;'>CURRENT ECOSYSTEM - VAAL RIVER (2020s)</h4>
            <ul style='font-size:16px;'>
                <li>Turbid water with visibility limited to centimeters</li>
                <li>Loss of 80-95% of native fish species in heavily polluted sections</li>
                <li>Algal mats and sewage fungus replacing diverse vegetation</li>
                <li>Fish consumption advisories due to heavy metal accumulation</li>
                <li>Cyanobacterial blooms releasing dangerous toxins</li>
                <li>Breeding grounds smothered by sewage sludge and chemicals</li>
                <li>Dramatic decline in waterbird populations and diversity</li>
                <li>Collapse of recreational fishing in multiple sections</li>
            </ul>
            </div>
            """, unsafe_allow_html=True)
        
        # TAP WATER VS. NATURAL SPRING WATER SECTION
        st.header("Tap Water vs. Natural Spring Water")
        
        # Create two columns for this section
        tap_col1, tap_col2 = st.columns(2)
        
        with tap_col1:
            st.markdown("<h3 style='font-size:24px; color:#F44336;'>WHAT'S IN YOUR TAP WATER?</h3>", unsafe_allow_html=True)
            st.markdown("""
            <div style='font-size:18px;'>
            <p><strong>Common Contaminants in South African Municipal Water:</strong></p>
            <ul>
                <li><strong>Chlorine & Disinfection Byproducts</strong> - Added for disinfection but creates harmful trihalomethanes</li>
                <li><strong>Microplastics</strong> - Studies show 76% of municipal water samples contain microplastic particles</li>
                <li><strong>Pharmaceutical Residues</strong> - Including antibiotics, hormones, and pain medications</li>
                <li><strong>Heavy Metals</strong> - Lead, copper, and sometimes arsenic from aging infrastructure</li>
                <li><strong>Fluoride</strong> - Added in many areas but controversial for health impacts</li>
                <li><strong>Agricultural Runoff</strong> - Pesticides and fertilizer residues from source catchment areas</li>
                <li><strong>Industrial Chemicals</strong> - Including PFAS "forever chemicals" difficult to filter</li>
            </ul>
            
            <p><strong>Municipal Water Problems:</strong></p>
            <ul>
                <li><strong>Aging Infrastructure</strong> - 56% of municipalities report deteriorating water systems</li>
                <li><strong>Treatment Failures</strong> - Only 40% of wastewater systems achieve minimum compliance</li>
                <li><strong>Corporate Control</strong> - Increasing privatization of water services prioritizes profit over health</li>
                <li><strong>Limited Testing</strong> - Municipal testing covers only a fraction of potential contaminants</li>
                <li><strong>Chemical Treatments</strong> - Adds additional toxic compounds to remove other contaminants</li>
            </ul>
            </div>
            """, unsafe_allow_html=True)
            
        with tap_col2:
            st.markdown("<h3 style='font-size:24px; color:#4CAF50;'>THE RIGHT TO NATURAL SPRING WATER</h3>", unsafe_allow_html=True)
            st.markdown("""
            <div style='font-size:18px;'>
            <p><strong>Benefits of Natural Spring Water Access:</strong></p>
            <ul>
                <li><strong>Mineral Content</strong> - Natural springs contain beneficial minerals like calcium, magnesium, and potassium</li>
                <li><strong>No Chemical Additives</strong> - Free from chlorine, fluoride, and other treatment chemicals</li>
                <li><strong>Ecological Connection</strong> - Maintaining connection to natural water cycles</li>
                <li><strong>Cultural Significance</strong> - Many springs hold traditional and spiritual importance</li>
                <li><strong>Living Water</strong> - Contains natural energy and structure that municipal water lacks</li>
                <li><strong>Community Resource</strong> - Creates gathering spaces and shared responsibility</li>
            </ul>
            
            <p><strong>Corporate Exploitation of Water Resources:</strong></p>
            <ul>
                <li><strong>Privatization</strong> - Corporations like Nestlé extract millions of liters from natural springs for minimal fees</li>
                <li><strong>Water Grabbing</strong> - Rights to springs and aquifers purchased and commercialized</li>
                <li><strong>Price Gouging</strong> - Bottled water costs up to 2000× more than tap water</li>
                <li><strong>Environmental Damage</strong> - Extraction often harms local ecosystems and depletes aquifers</li>
                <li><strong>Restricted Access</strong> - Public denied access to traditional water sources after privatization</li>
            </ul>
            </div>
            
            <div style='background-color:#E8F5E9; padding:15px; border-radius:10px; margin-top:15px;'>
            <h5 style='font-size:18px;'>PEOPLE'S RIGHT TO WATER</h5>
            <p style='font-size:16px;'>The South African Constitution and Water Services Act recognize access to clean water as a basic human right. Communities should demand protection and access to their natural water resources rather than allowing corporations to profit from this essential resource.</p>
            </div>
            """, unsafe_allow_html=True)
        
        # List of free natural springs that are still accessible
        st.subheader("Accessible Natural Springs in South Africa")
        st.markdown("""
        <div style='font-size:18px;'>
        <p>Despite increasing privatization, these natural springs remain accessible to the public:</p>
        <ul>
            <li><strong>Newlands Spring (Cape Town)</strong> - Limited hours but free public access</li>
            <li><strong>SAB Spring (Newlands)</strong> - Public collection point on Spring Way Road</li>
            <li><strong>Bradwell Spring (Port Elizabeth)</strong> - Community-maintained access point</li>
            <li><strong>Borehole 75 (Pretoria)</strong> - Public access point in Groenkloof</li>
            <li><strong>Berlin Forest Spring (East London)</strong> - Natural forest spring with public access</li>
            <li><strong>Junction Spring (Johannesburg)</strong> - Community-protected spring</li>
            <li><strong>Rustenburg Kloof Springs</strong> - Natural springs with public access</li>
        </ul>
        </div>
        """, unsafe_allow_html=True)
            
        # SUBSCRIPTION AND DONATION SECTION
        st.markdown("<h2 style='text-align: center; font-size: 28px; color: #6200EA; background-color: #EDE7F6; padding: 15px; margin-top: 30px; border-radius: 10px;'>SUBSCRIBE FOR CLEAN WATER ALERTS</h2>", unsafe_allow_html=True)
        
        # Create three columns for the subscription section
        sub_col1, sub_col2, sub_col3 = st.columns([1,2,1])
        
        with sub_col2:
            st.markdown("""
            <div style='border:2px solid #6200EA; border-radius:10px; padding:20px; text-align:center;'>
                <h3 style='font-size:26px; color:#6200EA;'>Water Quality Monitoring Subscription</h3>
                <p style='font-size:18px;'>Support our water monitoring initiatives and receive critical pollution alerts</p>
                
                <div style='display:flex; justify-content:space-around; margin:20px 0;'>
                    <div style='background-color:#EDE7F6; padding:15px; border-radius:10px; width:45%;'>
                        <h4 style='font-size:20px;'>Monthly</h4>
                        <p style='font-size:24px; font-weight:bold;'>R25.00</p>
                        <p style='font-size:16px;'>Billed monthly</p>
                    </div>
                    
                    <div style='background-color:#D1C4E9; padding:15px; border-radius:10px; width:45%;'>
                        <h4 style='font-size:20px;'>Yearly</h4>
                        <p style='font-size:24px; font-weight:bold;'>R300.00</p>
                        <p style='font-size:16px;'>Save R00.00 yearly</p>
                    </div>
                </div>
                
                <h4 style='font-size:20px; margin-top:20px;'>Subscriber Benefits:</h4>
                <ul style='text-align:left; font-size:16px;'>
                    <li><strong>Real-time Pollution Alerts</strong> - Get SMS and email notifications about water contamination in your area</li>
                    <li><strong>Monthly Water Quality Reports</strong> - Detailed analysis of your local water sources</li>
                    <li><strong>Community Forum Access</strong> - Connect with others concerned about water quality</li>
                    <li><strong>Water Testing Kit</strong> - Annual subscribers receive a basic water testing kit</li>
                    <li><strong>Spring Water Map Updates</strong> - Get notifications about newly accessible natural springs</li>
                    <li><strong>Water Rights Advocacy</strong> - Support legal actions to protect public water access</li>
                </ul>
                
                <div style='margin-top:20px;'>
                    <form>
                        <input type="text" placeholder="Full Name" style='width:100%; padding:10px; margin-bottom:10px; border-radius:5px; border:1px solid #6200EA;'>
                        <input type="email" placeholder="Email Address" style='width:100%; padding:10px; margin-bottom:10px; border-radius:5px; border:1px solid #6200EA;'>
                        <input type="tel" placeholder="Mobile Number" style='width:100%; padding:10px; margin-bottom:10px; border-radius:5px; border:1px solid #6200EA;'>
                        <select style='width:100%; padding:10px; margin-bottom:20px; border-radius:5px; border:1px solid #6200EA;'>
                            <option value="">Select Your Region</option>
                            <option value="gauteng">Gauteng</option>
                            <option value="western_cape">Western Cape</option>
                            <option value="eastern_cape">Eastern Cape</option>
                            <option value="kwazulu_natal">KwaZulu-Natal</option>
                            <option value="free_state">Free State</option>
                            <option value="north_west">North West</option>
                            <option value="mpumalanga">Mpumalanga</option>
                            <option value="limpopo">Limpopo</option>
                            <option value="northern_cape">Northern Cape</option>
                        </select>
                        <button style='background-color:#6200EA; color:white; width:100%; padding:12px; border:none; border-radius:5px; font-size:18px; cursor:pointer;'>Subscribe Now</button>
                    </form>
                </div>
                
                <p style='font-size:14px; margin-top:10px;'>Your subscription supports water testing and community alert systems. Cancel anytime.</p>
            </div>
            
            <!-- Donation section under subscription -->
            <div style='margin-top:30px; border:2px solid #00897B; border-radius:10px; padding:20px; text-align:center;'>
                <h3 style='font-size:24px; color:#00897B;'>One-Time Donation</h3>
                <p style='font-size:16px;'>Support our work with a one-time contribution to clean water initiatives</p>
                
                <div style='display:flex; justify-content:space-around; margin:20px 0;'>
                    <div style='padding:10px; border-radius:5px; background-color:#E0F2F1; width:30%;'>
                        <p style='font-weight:bold;'>R50</p>
                    </div>
                    <div style='padding:10px; border-radius:5px; background-color:#B2DFDB; width:30%;'>
                        <p style='font-weight:bold;'>R100</p>
                    </div>
                    <div style='padding:10px; border-radius:5px; background-color:#80CBC4; width:30%;'>
                        <p style='font-weight:bold;'>R500</p>
                    </div>
                </div>
                
                <input type="text" placeholder="Enter custom amount" style='width:100%; padding:10px; margin-bottom:10px; border-radius:5px; border:1px solid #00897B;'>
                <button style='background-color:#00897B; color:white; width:100%; padding:10px; border:none; border-radius:5px; font-size:16px; cursor:pointer;'>Donate Now</button>
            </div>
            """, unsafe_allow_html=True)
            
        # Community action section
        st.subheader("Community Action for Safer Waters")
        
        st.markdown("""
        <div style='background-color:#E0F7FA; padding:20px; border-radius:10px; margin-top:20px;'>
        <p style='font-size:18px;'>Communities can take action to protect their traditional water resources:</p>
        <ul style='font-size:18px;'>
            <li><strong>Water monitoring programs</strong> - Partner with universities or NGOs for regular testing</li>
            <li><strong>Knowledge sharing</strong> - Create networks to alert about pollution events</li>
            <li><strong>Advocacy</strong> - Engage with local government about the importance of traditional water sites</li>
            <li><strong>Clean-up initiatives</strong> - Organize community clean-ups of riverbanks</li>
            <li><strong>Education</strong> - Share information about safer practices while respecting cultural traditions</li>
            <li><strong>Documentation</strong> - Record historical knowledge about water quality changes</li>
            <li><strong>Protect natural springs</strong> - Organize community defense of remaining accessible springs</li>
            <li><strong>Challenge privatization</strong> - Advocate for public ownership of water resources</li>
        </ul>
        
        <p style='font-size:18px;'><strong>Resources for Communities:</strong></p>
        <ul style='font-size:18px;'>
            <li>South African Water Caucus (community support)</li>
            <li>MiniSASS citizen water monitoring toolkit</li>
            <li>Department of Water and Sanitation Blue/Green Drop Reports</li>
            <li>Local catchment management forums</li>
            <li>Water Justice Network (anti-privatization resources)</li>
        </ul>
        </div>
        
        <!-- Footer message about forced removals -->
        <div style='margin-top:50px; background-color:#263238; color:#FFFFFF; padding:20px; border-radius:10px; text-align:center;'>
            <p style='font-size:22px; font-weight:bold;'>Forced removals do catch up with the remover (apartheid)</p>
        </div>
        """, unsafe_allow_html=True)

if __name__ == "__main__":
    app()