import streamlit as st
import pandas as pd
from utils.common import display_apartheid_message, display_traditional_water_knowledge, display_common_messages

def app():
    # Common header for all pages
    st.markdown("<h1 style='text-align: center; color: #1E88E5; background-color: #E3F2FD; padding: 20px; border-radius: 10px;'>SOUTH AFRICAN WATER SYSTEMS</h1>", unsafe_allow_html=True)
    st.markdown("<h2 style='text-align: center; font-size: 28px; color: #D81B60; background-color: #FCE4EC; padding: 15px; margin-top: 10px; border-radius: 10px;'>TOURISTS AND LOCALS</h2>", unsafe_allow_html=True)
    
    # Display the traditional water knowledge and apartheid messages
    display_traditional_water_knowledge()
    display_apartheid_message()
    
    # Page title
    st.markdown("<h1 style='text-align: center; color: #1E88E5; background-color: #E3F2FD; padding: 20px; border-radius: 10px;'>SUBSCRIPTION & DONATIONS</h1>", unsafe_allow_html=True)
    
    # Subscription section
    st.markdown("<h2 style='text-align: center; font-size: 28px; color: #6200EA; background-color: #EDE7F6; padding: 15px; margin-top: 30px; border-radius: 10px;'>SUBSCRIBE FOR CLEAN WATER ALERTS</h2>", unsafe_allow_html=True)

    # Column layout for subscription options
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        <div style='background-color:#D1C4E9; padding:15px; border-radius:10px; text-align:center;'>
            <h4 style='font-size:20px;'>Monthly</h4>
            <p style='font-size:24px; font-weight:bold;'>R25.00</p>
            <p style='font-size:16px;'>Cancel anytime</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown("""
        <div style='background-color:#D1C4E9; padding:15px; border-radius:10px; text-align:center;'>
            <h4 style='font-size:20px;'>Yearly</h4>
            <p style='font-size:24px; font-weight:bold;'>R300.00</p>
            <p style='font-size:16px;'>Save R00.00 yearly</p>
        </div>
        """, unsafe_allow_html=True)
    
    # Subscriber benefits section
    st.subheader("Subscriber Benefits:")
    st.markdown("""
    - **Real-time Pollution Alerts** - Get SMS and email notifications about water contamination in your area
    - **Monthly Water Quality Reports** - Detailed analysis of your local water sources
    - **Community Forum Access** - Connect with others concerned about water quality
    - **Water Testing Kit** - Annual subscribers receive a basic water testing kit
    - **Spring Water Map Updates** - Get notifications about newly accessible natural springs
    - **Water Rights Advocacy** - Support legal actions to protect public water access
    """)
    
    # Subscription form
    st.subheader("Sign Up Now")
    
    with st.form("subscription_form"):
        name = st.text_input("Full Name")
        email = st.text_input("Email Address")
        phone = st.text_input("Mobile Number")
        region = st.selectbox("Select Your Region", [
            "Select Your Region",
            "Gauteng", 
            "Western Cape", 
            "Eastern Cape", 
            "KwaZulu-Natal", 
            "Free State", 
            "North West", 
            "Mpumalanga", 
            "Limpopo", 
            "Northern Cape"
        ])
        
        subscription_type = st.radio("Choose Your Plan", ["Monthly (R25.00)", "Yearly (R300.00)"])
        
        subscribe_button = st.form_submit_button("Subscribe Now")
        
        if subscribe_button:
            st.success("Thank you for subscribing! You will receive a confirmation email shortly.")
    
    st.markdown("<p style='font-size:14px;'>Your subscription supports water testing and community alert systems. Cancel anytime.</p>", unsafe_allow_html=True)
    
    # Donation section
    st.markdown("<h3 style='text-align: center; font-size: 24px; color: #00897B; margin-top: 30px;'>One-Time Donation</h3>", unsafe_allow_html=True)
    st.markdown("<p style='text-align: center;'>Support our work with a one-time contribution to clean water initiatives</p>", unsafe_allow_html=True)
    
    # Donation amount options
    donation_amount = st.radio("Select Amount", ["R50", "R100", "R500", "Custom Amount"])
    
    if donation_amount == "Custom Amount":
        custom_amount = st.text_input("Enter Custom Amount (R)")
    
    if st.button("Donate Now"):
        st.success("Thank you for your donation! You will receive a confirmation email shortly.")
    
    # What your support enables section
    st.subheader("What Your Support Enables")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        - Regular water testing at religious and traditional sites
        - Early warning systems for communities at risk
        - Legal support for water access rights
        - Educational programs about water safety
        - Community-based water monitoring initiatives
        """)
    
    with col2:
        st.markdown("""
        - Research on emerging water contaminants
        - Advocacy for stricter pollution regulations
        - Development of affordable water quality testing kits
        - Support for communities fighting water privatization
        - Public awareness campaigns about water pollution
        """)
        
    # Add footer
    st.markdown("---")
    # Display both messages in the footer using the combined function
    display_common_messages()
    st.markdown("<div style='text-align: center; color: #616161; padding: 20px;'><p>© 2025 South African Water Systems Monitor. All rights reserved.</p><p>For water emergencies, contact: <a href='mailto:support@sawatermonitor.co.za'>support@sawatermonitor.co.za</a> | +27 800 123 456</p></div>", unsafe_allow_html=True)

if __name__ == "__main__":
    app()