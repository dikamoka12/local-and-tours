import streamlit as st
import pandas as pd
import plotly.express as px

def app():
    st.title("Global Pollution Database")
    st.write("A comprehensive database of polluted water bodies and systems worldwide, categorized by type.")
    
    # Create tabs for different views
    tab1, tab2, tab3 = st.tabs(["Polluted Water Bodies", "Pollution by Region", "Pollution Types & Sources"])
    
    with tab1:
        st.header("Comprehensive List of Polluted Water Bodies")
        
        # Allow filtering by water body type
        water_body_types = ["All Types", "Rivers", "Dams and Reservoirs", "Groundwater", "Natural Springs", "Ocean Pollution", "Other Systems"]
        selected_type = st.selectbox("Filter by water body type:", water_body_types)
        
        if selected_type == "Rivers" or selected_type == "All Types":
            st.subheader("Polluted Rivers")
            st.markdown("""
            1. **Citarum River (Indonesia)**  
               - Severely contaminated by industrial waste (textile factories), releasing 20,000 tons of waste daily, including lead and mercury. Called the "world's most polluted river" by the Asian Development Bank.  
            
            2. **Ganges River (India)**  
               - Sacred but heavily polluted by fecal coliform bacteria (100x safety limits near Varanasi) and industrial waste due to failed cleanup initiatives like the Ganga Action Plan.  
            
            3. **Ravi River (India/Pakistan)**  
               - Ranked the most polluted globally in 2022 due to pharmaceutical residues (e.g., antibiotics, caffeine) from industrial and agricultural runoff.  
            
            4. **Pasig River (Philippines)**  
               - Declared biologically dead by 1990 due to untreated sewage and industrial waste; a top contributor to ocean plastic pollution.  
            
            5. **Buriganga River (Bangladesh)**  
               - Polluted by chemical waste, medical waste, and sewage from Dhaka's industries, rendering it unsafe for aquatic life or human use.  
            
            6. **Techa River (Russia)**  
               - Radioactive contamination from the Mayak nuclear complex, displacing thousands and causing long-term health risks.  
            
            7. **Osun River (Nigeria)**  
               - Contaminated by cyanide and heavy metals from illegal gold mining, threatening cultural heritage sites like the Osun Osogbo Sacred Grove.  
            
            8. **Kishon River (Israel)**  
               - Polluted for decades by mercury and chemicals from industrial plants, linked to cancer in military personnel and DNA damage in aquatic species.  
            
            9. **Musi River (India)**  
               - High concentrations of pharmaceuticals (12,000 ng/L) causing antibiotic resistance and ecological harm.  
            
            10. **Jordan River (Middle East)**  
                - Ecosystem collapse in its lower stretches due to sewage dumping and lack of regional cooperation.
                
            11. **Nairobi River (Kenya)**  
                - Contaminated by agricultural runoff, slum waste, and industrial discharges. Recent cleanup efforts show partial recovery.
            
            12. **Yamuna River (India)**  
                - Delhi's stretch is critically polluted; 80% of contamination occurs in 1.5% of its length due to untreated sewage.
            
            13. **Yellow River (Iowa, USA)**  
                - Impaired by feedlot runoff and fertilizer, limiting recreation and aquatic life.
            """)

        if selected_type == "Dams and Reservoirs" or selected_type == "All Types":
            st.subheader("Dams and Reservoirs")
            st.markdown("""
            1. **Kruger National Park Dams (South Africa)**  
               - 42 dams were removed after causing overgrazing, cyanobacteria outbreaks, and biodiversity loss.  
            
            2. **Mekong River Dams (Southeast Asia)**  
               - Planned dams threaten to reduce sediment flow to the delta by 97% by 2040, risking food security and land loss.  
            
            3. **Grand Ethiopian Renaissance Dam (Ethiopia)**  
               - Controversial dam on the Nile threatens downstream water access for Egypt, risking regional conflict.
               
            4. **Farmington River (Connecticut, USA)**  
               - Threatened by a hydropower dam causing toxic algae outbreaks, endangering drinking water for 400,000 people.
            
            5. **Trinity River (California, USA)**  
               - Impacted by outdated water management and diversions, affecting biodiversity and cold water supply.
            
            6. **Kobuk River (Alaska, USA)**  
               - At risk from proposed road construction and mining near critical habitats.
            """)
            
        if selected_type == "Groundwater" or selected_type == "All Types":
            st.subheader("Groundwater Contamination")
            st.markdown("""
            1. **Ogallala Aquifer (USA)**  
               - Over-pumped for agriculture, with 70% depletion projected within 50 years; contamination from fracking in overlapping regions.  
            
            2. **Gaza Coastal Aquifer (Palestine)**  
               - 97% of groundwater is undrinkable due to over-extraction, saltwater intrusion, and nitrate pollution.  
            
            3. **Tulare Lake Basin (USA)**  
               - Nitrate contamination from agricultural runoff, leaving communities without safe drinking water.  
            
            4. **Floridan Aquifer (USA)**  
               - Saltwater intrusion and reduced flows in Florida's springs due to overuse and rising sea levels.  
            
            5. **Permian Basin (USA)**  
               - Fracking activities poison groundwater in a region critical for U.S. agriculture.
               
            6. **Iowa's Groundwater (USA)**  
               - Polluted by agricultural runoff (nitrates, E. coli) from industrial farms, with 80% of river segments impaired for over a decade.
            
            7. **PFAS Contamination (USA)**  
               - "Forever chemicals" from firefighting foam and industrial waste infiltrate groundwater in states like California, Florida, and Texas, linked to cancer risks.
            
            8. **Techa River Basin (Russia)**  
               - Radioactive groundwater contamination from Soviet-era nuclear waste dumping.
            """)
            
        if selected_type == "Natural Springs" or selected_type == "All Types":
            st.subheader("Natural Springs")
            st.markdown("""
            1. **Florida Springs (USA)**  
               - Declining flows (60% reduction) and pollution threaten one of the world's largest spring systems.  
            
            2. **Jordan River Springs (Middle East)**  
               - Polluted by sewage and industrial runoff, exacerbating regional water scarcity.  
            
            3. **Sahibi River Springs (India)**  
               - Contaminated by untreated sewage from Delhi, affecting groundwater and local ecosystems.
            """)
            
        if selected_type == "Ocean Pollution" or selected_type == "All Types":
            st.subheader("Ocean Pollution")
            st.markdown("""
            1. **Indus River (Pakistan)**  
               - Second-largest contributor of plastic waste to oceans globally.  
            
            2. **Tijuana River (USA/Mexico)**  
               - Carries raw sewage and industrial waste into the Pacific Ocean, causing beach closures.  
            
            3. **Nonpoint Source Runoff (Global)**  
               - Agricultural and urban runoff creates dead zones (e.g., Gulf of Mexico) via nutrient overload.
            """)
            
        if selected_type == "Other Systems" or selected_type == "All Types":
            st.subheader("Other Polluted Systems")
            st.markdown("""
            1. **Buckingham Canal (India)**  
               - Receives 55 million liters of untreated sewage daily, contributing to malaria outbreaks.  
            
            2. **Artesian Aquifers (Global)**  
               - Overused for agriculture (70% of withdrawals) and industries, leading to irreversible depletion.  
            
            3. **Murray River Basin (Australia)**  
               - Increasing salinity in groundwater and surface water due to drought and overuse.
            """)
    
    with tab2:
        st.header("Pollution by Region")
        
        # Create regional charts and information
        regions = ["Asia", "North America", "South America", "Europe", "Africa", "Middle East", "Oceania"]
        
        # Create water pollution count data by region (approximated from the list)
        region_data = {
            "Region": regions,
            "Polluted Water Bodies": [12, 10, 3, 4, 6, 4, 2],
            "Average Pollution Severity (1-10)": [8.5, 6.2, 5.8, 5.5, 7.0, 7.2, 5.0]
        }
        
        region_df = pd.DataFrame(region_data)
        
        # Create chart
        fig = px.bar(
            region_df,
            x="Region",
            y="Polluted Water Bodies",
            color="Average Pollution Severity (1-10)",
            color_continuous_scale=["green", "yellow", "orange", "red"],
            title="Polluted Water Bodies by Region"
        )
        
        st.plotly_chart(fig, use_container_width=True)
        
        # Regional details
        selected_region = st.selectbox("Select a region for details:", regions)
        
        region_details = {
            "Asia": {
                "Most Polluted": "Citarum River (Indonesia), Ganges River (India), Buriganga River (Bangladesh)",
                "Main Pollutants": "Industrial waste, untreated sewage, heavy metals, pharmaceuticals",
                "Key Challenges": "Rapid industrialization without proper waste management, high population density"
            },
            "North America": {
                "Most Polluted": "Tijuana River (USA/Mexico), Ogallala Aquifer (USA), PFAS contamination sites",
                "Main Pollutants": "Agricultural runoff, PFAS chemicals, urban sewage, fracking waste",
                "Key Challenges": "Aging infrastructure, agricultural practices, industrial legacy pollutants"
            },
            "South America": {
                "Most Polluted": "Amazon River tributaries, Riachuelo River (Argentina)",
                "Main Pollutants": "Mining waste, agricultural runoff, untreated sewage",
                "Key Challenges": "Illegal mining, deforestation, inadequate sanitation systems"
            },
            "Europe": {
                "Most Polluted": "Volga River (Russia), Sarno River (Italy), Techa River (Russia)",
                "Main Pollutants": "Industrial waste, radioactive contamination, agricultural runoff",
                "Key Challenges": "Legacy pollution, transboundary issues, agricultural intensification"
            },
            "Africa": {
                "Most Polluted": "Nairobi River (Kenya), Osun River (Nigeria), Niger Delta",
                "Main Pollutants": "Mining waste, oil spills, untreated sewage, agricultural runoff",
                "Key Challenges": "Limited wastewater infrastructure, informal settlements, resource extraction"
            },
            "Middle East": {
                "Most Polluted": "Jordan River, Tigris-Euphrates Basin, Gaza Coastal Aquifer",
                "Main Pollutants": "Saline intrusion, untreated sewage, agricultural chemicals",
                "Key Challenges": "Water scarcity, political conflict, transboundary water management"
            },
            "Oceania": {
                "Most Polluted": "Murray River Basin (Australia), Manukau Harbour (New Zealand)",
                "Main Pollutants": "Agricultural runoff, salinity, urban stormwater",
                "Key Challenges": "Drought, climate change impacts, agricultural intensification"
            }
        }
        
        st.subheader(f"{selected_region} - Regional Pollution Profile")
        st.markdown(f"**Most Polluted Water Bodies:** {region_details[selected_region]['Most Polluted']}")
        st.markdown(f"**Primary Pollutants:** {region_details[selected_region]['Main Pollutants']}")
        st.markdown(f"**Key Regional Challenges:** {region_details[selected_region]['Key Challenges']}")

    with tab3:
        st.header("Pollution Types & Sources")
        
        # Create donut chart of pollution types
        pollution_types = {
            "Type": ["Industrial Waste", "Urban Sewage", "Agricultural Runoff", "Plastic Waste", "Radioactive Contamination", "Mining Waste", "Other"],
            "Percentage": [35, 25, 20, 10, 5, 3, 2]
        }
        
        type_df = pd.DataFrame(pollution_types)
        
        fig = px.pie(
            type_df,
            values="Percentage",
            names="Type",
            title="Major Sources of Water Pollution Globally",
            hole=0.4,
            color_discrete_sequence=px.colors.qualitative.Bold
        )
        
        st.plotly_chart(fig, use_container_width=True)
        
        # Detailed information on key pollution sources
        st.subheader("Key Sources of Pollution")
        st.markdown("""
        - **Industrial Waste**: Textiles, pharmaceuticals, and mining (e.g., Citarum, Osun)
            - Contains heavy metals, chemicals, and other toxins
            - Often released untreated in developing countries
            - Leads to bioaccumulation in food chains
        
        - **Agricultural Runoff**: Nitrates, pesticides, and manure (e.g., Ogallala, Tulare)
            - Creates algal blooms and dead zones
            - Contaminates drinking water supplies
            - Often results from fertilizer overuse and CAFOs (Concentrated Animal Feeding Operations)
        
        - **Urban Sewage**: Untreated wastewater in developing regions (e.g., Buriganga, Sahibi)
            - Contains pathogens and disease-causing organisms
            - Often combines with stormwater in combined sewer systems
            - Leads to public health threats and ecological damage
        
        - **Plastic Waste**: Pasig, Indus, and Ravi rivers
            - Breaks down into microplastics entering food chains
            - Entangles and harms wildlife
            - Persists in environment for hundreds of years
        """)
        
        # Urgent global challenges
        st.subheader("Urgent Water Pollution Challenges")
        st.markdown("""
        - **Transboundary Conflicts**: Nile, Mekong, and Indus basins face disputes over water sharing and pollution control
        
        - **Climate Change Impacts**: 
            - Glacial melt and altered precipitation worsen scarcity and concentrate pollutants
            - Rising temperatures increase harmful algal blooms
            - Extreme weather events overwhelm water treatment systems
        
        - **Infrastructure Gaps**: 
            - Poor wastewater treatment in regions like Gaza and sub-Saharan Africa
            - Aging infrastructure in developed nations leading to combined sewer overflows
            - Limited monitoring and enforcement capabilities
        
        - **Emerging Contaminants**:
            - PFAS "forever chemicals" in groundwater
            - Pharmaceutical residues affecting aquatic life
            - Microplastics infiltrating water supplies
        """)

if __name__ == "__main__":
    app()