import streamlit as st
import pandas as pd
import json
import base64
from datetime import datetime
import os
import logging

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def get_binary_file_downloader_html(bin_file, file_label='File', file_description=''):
    """
    Generate HTML for download button
    """
    with open(bin_file, 'rb') as f:
        data = f.read()
    
    bin_str = base64.b64encode(data).decode()
    href = f'<a href="data:application/octet-stream;base64,{bin_str}" download="{os.path.basename(bin_file)}" class="download-btn">{file_label}</a>'
    return href

def get_table_download_link(df, filename, text='Download CSV'):
    """
    Generate a link to download the DataFrame as a CSV
    """
    csv = df.to_csv(index=False)
    # Create a UTF-8 encoded string
    b64 = base64.b64encode(csv.encode()).decode()
    href = f'<a href="data:file/csv;base64,{b64}" download="{filename}" class="download-btn">{text}</a>'
    return href

def create_pdf_download_link(pdf_content, filename, link_text="Download PDF"):
    """
    Generate a link to download a PDF
    """
    b64 = base64.b64encode(pdf_content.encode()).decode()
    href = f'<a href="data:application/pdf;base64,{b64}" download="{filename}" class="download-btn">{link_text}</a>'
    return href

def generate_static_html_version(app_content):
    """
    Generate a static HTML version of the app content for offline use
    """
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    html_content = f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>South African Water Systems - Offline Version</title>
        <style>
            body {{
                font-family: Arial, sans-serif;
                line-height: 1.6;
                margin: 0;
                padding: 0;
                color: #333;
            }}
            .container {{
                max-width: 1200px;
                margin: 0 auto;
                padding: 20px;
            }}
            .header {{
                text-align: center;
                background-color: #E3F2FD;
                color: #1E88E5;
                padding: 20px;
                border-radius: 10px;
                margin-bottom: 20px;
            }}
            .subheader {{
                text-align: center;
                background-color: #FCE4EC;
                color: #D81B60;
                padding: 15px;
                border-radius: 10px;
                margin-bottom: 30px;
            }}
            .section {{
                margin-bottom: 30px;
                padding: 20px;
                background-color: #f9f9f9;
                border-radius: 10px;
            }}
            .footer {{
                text-align: center;
                margin-top: 50px;
                padding: 20px;
                background-color: #f5f5f5;
                border-top: 1px solid #ddd;
            }}
            table {{
                width: 100%;
                border-collapse: collapse;
                margin: 20px 0;
            }}
            table, th, td {{
                border: 1px solid #ddd;
            }}
            th, td {{
                padding: 12px;
                text-align: left;
            }}
            th {{
                background-color: #f2f2f2;
            }}
            .alert {{
                padding: 15px;
                background-color: #f8d7da;
                color: #721c24;
                border-radius: 5px;
                margin-bottom: 15px;
            }}
            .info {{
                padding: 15px;
                background-color: #d1ecf1;
                color: #0c5460;
                border-radius: 5px;
                margin-bottom: 15px;
            }}
            /* Mobile responsive styles */
            @media (max-width: 768px) {{
                .container {{
                    padding: 10px;
                }}
                .header {{
                    font-size: 1.8rem;
                    padding: 15px;
                }}
                .subheader {{
                    font-size: 1.3rem;
                    padding: 10px;
                }}
                table {{
                    font-size: 0.9rem;
                }}
                th, td {{
                    padding: 8px;
                }}
            }}
            @media (max-width: 480px) {{
                .header {{
                    font-size: 1.4rem;
                    padding: 10px;
                }}
                .subheader {{
                    font-size: 1.1rem;
                    padding: 8px;
                }}
                .section {{
                    padding: 15px;
                }}
                table {{
                    font-size: 0.8rem;
                }}
                th, td {{
                    padding: 5px;
                }}
            }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>SOUTH AFRICAN WATER SYSTEMS</h1>
            </div>
            <div class="subheader">
                <h2>TOURISTS AND LOCALS</h2>
            </div>
            
            <div class="info">
                This is an offline version of the South African Water Systems app, generated on {timestamp}.
            </div>
            
            {app_content}
            
            <div class="footer">
                <p>© 2025 South African Water Systems Monitor. All rights reserved.</p>
                <p>For water emergencies, contact: support@sawatermonitor.co.za | +27 800 123 456</p>
            </div>
        </div>
    </body>
    </html>
    """
    
    return html_content

def create_offline_water_quality_guide():
    """
    Generate a comprehensive offline guide for water quality and safety
    """
    content = """
    <div class="section">
        <h2>Water Quality Guide</h2>
        
        <div class="section">
            <h3>Understanding Water Pollution</h3>
            <p>Water pollution refers to the contamination of water bodies, including lakes, rivers, oceans, and groundwater. It occurs when pollutants are directly or indirectly discharged into water bodies without adequate treatment to remove harmful compounds.</p>
            
            <h4>Common Pollutants</h4>
            <ul>
                <li><strong>Physical pollutants:</strong> Plastic waste, sediments, etc.</li>
                <li><strong>Chemical pollutants:</strong> Pesticides, heavy metals, detergents, etc.</li>
                <li><strong>Biological pollutants:</strong> Bacteria, viruses, parasites, etc.</li>
            </ul>
        </div>
        
        <div class="section">
            <h3>South African Water Systems</h3>
            <p>South Africa has diverse water systems, including:</p>
            <ul>
                <li>Major rivers: Orange, Vaal, Limpopo</li>
                <li>Dams: Gariep, Vaal, Sterkfontein</li>
                <li>Coastal waters: Atlantic and Indian Oceans</li>
                <li>Groundwater resources</li>
            </ul>
            
            <h4>Current Challenges</h4>
            <ul>
                <li>Water scarcity in many regions</li>
                <li>Pollution from industrial activities</li>
                <li>Agricultural runoff</li>
                <li>Municipal wastewater issues</li>
                <li>Mining impacts on water quality</li>
            </ul>
        </div>
        
        <div class="section">
            <h3>Traditional Water Management</h3>
            <p>Traditional South African communities have developed various methods for water management:</p>
            
            <h4>Water Collection</h4>
            <ul>
                <li>Clay pots (izinkamba) for water collection and storage</li>
                <li>Woven baskets treated with natural waterproofing</li>
                <li>Rock cisterns for rainwater harvesting</li>
            </ul>
            
            <h4>Water Purification</h4>
            <ul>
                <li>Sand filtration through layers of different materials</li>
                <li>Use of specific plant materials like moringa seeds</li>
                <li>Clay pot filtering systems</li>
                <li>Boiling with specific herbs for purification</li>
            </ul>
        </div>
        
        <div class="section">
            <h3>Water Safety Tips</h3>
            
            <h4>For Tap Water</h4>
            <ul>
                <li>If water appears discolored, let it run until clear</li>
                <li>Consider using a certified water filter in areas with known contamination</li>
                <li>Store water in clean, covered containers</li>
                <li>If advised by local authorities, boil water before consumption</li>
            </ul>
            
            <h4>For Natural Water Sources</h4>
            <ul>
                <li>Never drink directly from rivers, dams, or lakes without treatment</li>
                <li>Look for signs of pollution: unusual color, odor, or dead fish</li>
                <li>Filter and boil water from natural sources before use</li>
                <li>Consider portable water purification tablets or devices when traveling</li>
            </ul>
            
            <h4>Emergency Water Purification</h4>
            <ul>
                <li><strong>Boiling:</strong> Bring water to a rolling boil for at least 1 minute</li>
                <li><strong>Chlorination:</strong> Use unscented household bleach (5 drops per liter), stir and let stand for 30 minutes</li>
                <li><strong>Solar disinfection:</strong> Fill clear plastic bottles and expose to direct sunlight for at least 6 hours</li>
            </ul>
        </div>
        
        <div class="section">
            <h3>Emergency Contacts</h3>
            <p>Keep these numbers available in case of water emergencies:</p>
            <ul>
                <li>National Water Services: 0800 200 200</li>
                <li>Department of Water Affairs: 0800 200 200</li>
                <li>Blue Drop Call Centre: 0800 200 200</li>
                <li>Local Municipality Water Services: Check your city's website</li>
                <li>Emergency Services: 10111</li>
            </ul>
        </div>
    </div>
    """
    
    return content

def create_offline_chemical_reference():
    """
    Generate a reference guide for common water pollutants and chemicals
    """
    content = """
    <div class="section">
        <h2>Common Water Pollutants Reference Guide</h2>
        
        <div class="section">
            <h3>Industrial Chemicals</h3>
            <table>
                <tr>
                    <th>Pollutant</th>
                    <th>Sources</th>
                    <th>Health Effects</th>
                    <th>Environmental Impact</th>
                </tr>
                <tr>
                    <td>Lead</td>
                    <td>Mining, old pipes, paint</td>
                    <td>Developmental issues, kidney damage, high blood pressure</td>
                    <td>Toxic to aquatic life, bioaccumulates in food chain</td>
                </tr>
                <tr>
                    <td>Mercury</td>
                    <td>Mining, fossil fuels, industrial waste</td>
                    <td>Neurological damage, developmental issues</td>
                    <td>Highly toxic to marine life, bioaccumulates</td>
                </tr>
                <tr>
                    <td>PCBs</td>
                    <td>Industrial coolants, electrical equipment</td>
                    <td>Cancer risk, immune system damage</td>
                    <td>Persistent in environment, affects reproduction in wildlife</td>
                </tr>
                <tr>
                    <td>PFAS</td>
                    <td>Non-stick cookware, waterproof materials</td>
                    <td>Hormone disruption, cancer risk</td>
                    <td>"Forever chemicals" - extremely persistent in environment</td>
                </tr>
            </table>
        </div>
        
        <div class="section">
            <h3>Agricultural Pollutants</h3>
            <table>
                <tr>
                    <th>Pollutant</th>
                    <th>Sources</th>
                    <th>Health Effects</th>
                    <th>Environmental Impact</th>
                </tr>
                <tr>
                    <td>Nitrates</td>
                    <td>Fertilizers, animal waste</td>
                    <td>Blue baby syndrome, potential cancer risk</td>
                    <td>Algal blooms, dead zones in water bodies</td>
                </tr>
                <tr>
                    <td>Phosphates</td>
                    <td>Fertilizers, detergents</td>
                    <td>Indirect health effects via algal toxins</td>
                    <td>Eutrophication, oxygen depletion in water</td>
                </tr>
                <tr>
                    <td>Pesticides</td>
                    <td>Crop spraying, pest control</td>
                    <td>Varies by chemical - can include neurological issues, cancer</td>
                    <td>Toxic to beneficial insects, fish, and wildlife</td>
                </tr>
            </table>
        </div>
        
        <div class="section">
            <h3>Biological Contaminants</h3>
            <table>
                <tr>
                    <th>Contaminant</th>
                    <th>Sources</th>
                    <th>Health Effects</th>
                    <th>Treatment</th>
                </tr>
                <tr>
                    <td>E. coli</td>
                    <td>Sewage, animal waste</td>
                    <td>Diarrhea, urinary tract infections</td>
                    <td>Boiling, chlorination</td>
                </tr>
                <tr>
                    <td>Giardia</td>
                    <td>Animal feces, untreated water</td>
                    <td>Giardiasis - diarrhea, abdominal cramps</td>
                    <td>Filtration, UV treatment</td>
                </tr>
                <tr>
                    <td>Cryptosporidium</td>
                    <td>Animal waste, contaminated water</td>
                    <td>Cryptosporidiosis - severe diarrhea</td>
                    <td>Special filters, UV treatment</td>
                </tr>
                <tr>
                    <td>Vibrio</td>
                    <td>Coastal waters, shellfish</td>
                    <td>Gastrointestinal illness, wound infections</td>
                    <td>Cooking seafood thoroughly</td>
                </tr>
            </table>
        </div>
    </div>
    """
    
    return content

def generate_offline_package():
    """
    Generate a complete offline package with all necessary information
    """
    # Create the main content
    water_quality_guide = create_offline_water_quality_guide()
    chemical_reference = create_offline_chemical_reference()
    
    # Combine all content
    complete_content = f"""
    <div class="section">
        <h2>South African Water Systems - Offline Guide</h2>
        <p>This comprehensive guide contains essential information about water quality, safety, and traditional practices in South Africa. This information can be accessed without an internet connection.</p>
    </div>
    
    {water_quality_guide}
    
    {chemical_reference}
    """
    
    # Generate the complete HTML file
    html_content = generate_static_html_version(complete_content)
    
    # Save the file
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"sa_water_systems_offline_{timestamp}.html"
    
    try:
        with open(filename, "w", encoding="utf-8") as f:
            f.write(html_content)
        logger.info(f"Successfully created offline package: {filename}")
        return filename
    except Exception as e:
        logger.error(f"Error creating offline package: {str(e)}")
        return None

def get_offline_package_download_link():
    """
    Generate a download link for the offline package
    """
    try:
        # Generate the offline package
        filename = generate_offline_package()
        
        if filename is None:
            return "<p>Failed to create offline package. Please try again later.</p>"
        
        # Create a download link
        with open(filename, "r", encoding="utf-8") as f:
            html_content = f.read()
        
        b64 = base64.b64encode(html_content.encode()).decode()
        download_filename = "SA_Water_Systems_Offline_Guide.html"
        href = f'<a href="data:text/html;base64,{b64}" download="{download_filename}" class="offline-content-btn">Download Offline Guide</a>'
        
        # Clean up the temporary file
        try:
            os.remove(filename)
        except:
            pass
        
        return href
    
    except Exception as e:
        logger.error(f"Error creating download link: {str(e)}")
        return "<p>Error creating download link. Please try again later.</p>"