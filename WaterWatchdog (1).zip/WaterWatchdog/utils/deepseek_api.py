"""
DeepSeek API Integration Module
-------------------------------
This module handles the integration with the DeepSeek API
for retrieving live pollution data.
"""

import os
import requests
import json
import pandas as pd
from datetime import datetime, timedelta
import streamlit as st

# API Constants
DEEPSEEK_API_KEY = os.environ.get("DEEPSEEK_API_KEY")
DEEPSEEK_BASE_URL = "https://api.deepseek.com/v1"  # Base URL for DeepSeek API

def test_api_connection():
    """Test if the DeepSeek API connection is working properly."""
    try:
        url = f"{DEEPSEEK_BASE_URL}/ping"
        headers = {
            "Authorization": f"Bearer {DEEPSEEK_API_KEY}",
            "Content-Type": "application/json"
        }
        response = requests.get(url, headers=headers)
        
        if response.status_code == 200:
            return True, "Connection successful!"
        else:
            return False, f"Connection failed: Status code {response.status_code}"
    except Exception as e:
        return False, f"Connection error: {str(e)}"

def get_pollution_data(data_type="water", location=None, start_date=None, end_date=None):
    """
    Retrieve pollution data from DeepSeek API.
    
    Args:
        data_type (str): Type of pollution data - 'water', 'air', or 'combined'
        location (str, optional): Specific location name or coordinates
        start_date (datetime, optional): Start date for data range
        end_date (datetime, optional): End date for data range
        
    Returns:
        Tuple: (success (bool), data or error message (dict or str))
    """
    try:
        # Set default dates if not provided
        if not end_date:
            end_date = datetime.now()
        if not start_date:
            start_date = end_date - timedelta(days=7)  # Default to past week
            
        # Format dates for API
        start_str = start_date.strftime("%Y-%m-%d")
        end_str = end_date.strftime("%Y-%m-%d")
        
        # Build request
        url = f"{DEEPSEEK_BASE_URL}/pollution/{data_type}"
        headers = {
            "Authorization": f"Bearer {DEEPSEEK_API_KEY}",
            "Content-Type": "application/json"
        }
        
        params = {
            "start_date": start_str,
            "end_date": end_str
        }
        
        if location:
            params["location"] = location
            
        # Make API request
        response = requests.get(url, headers=headers, params=params)
        
        if response.status_code == 200:
            return True, response.json()
        else:
            return False, f"API error: {response.status_code} - {response.text}"
            
    except Exception as e:
        return False, f"Error retrieving pollution data: {str(e)}"

def get_water_pollution_metrics(location=None):
    """
    Get specific water pollution metrics for a location.
    
    Args:
        location (str, optional): Location name
        
    Returns:
        Tuple: (success (bool), data or error message (dict or str))
    """
    success, result = get_pollution_data(data_type="water", location=location)
    
    if not success:
        return False, result
        
    try:
        # Process into useful metrics
        metrics = {
            "ph_level": result.get("average_ph", "N/A"),
            "contaminants": result.get("contaminants", []),
            "safety_index": result.get("safety_index", "N/A"),
            "last_updated": result.get("timestamp", "N/A"),
            "critical_alerts": result.get("critical_alerts", [])
        }
        
        return True, metrics
    except Exception as e:
        return False, f"Error processing water metrics: {str(e)}"

def get_air_quality_metrics(location=None):
    """
    Get specific air quality metrics for a location.
    
    Args:
        location (str, optional): Location name
        
    Returns:
        Tuple: (success (bool), data or error message (dict or str))
    """
    success, result = get_pollution_data(data_type="air", location=location)
    
    if not success:
        return False, result
        
    try:
        # Process into useful metrics
        metrics = {
            "aqi": result.get("aqi", "N/A"),
            "pollutants": result.get("pollutants", {}),
            "health_risk": result.get("health_risk", "N/A"),
            "last_updated": result.get("timestamp", "N/A"),
            "recommendations": result.get("recommendations", [])
        }
        
        return True, metrics
    except Exception as e:
        return False, f"Error processing air metrics: {str(e)}"

def get_pollution_alerts(min_severity=3):
    """
    Get active pollution alerts from DeepSeek.
    
    Args:
        min_severity (int): Minimum severity level (1-5)
        
    Returns:
        Tuple: (success (bool), alerts or error message (list or str))
    """
    try:
        url = f"{DEEPSEEK_BASE_URL}/alerts"
        headers = {
            "Authorization": f"Bearer {DEEPSEEK_API_KEY}",
            "Content-Type": "application/json"
        }
        
        params = {
            "min_severity": min_severity,
            "active_only": True
        }
        
        response = requests.get(url, headers=headers, params=params)
        
        if response.status_code == 200:
            alerts = response.json().get("alerts", [])
            # Filter to include only alerts that match our min_severity criteria
            filtered_alerts = [
                alert for alert in alerts 
                if alert.get("severity", 0) >= min_severity
            ]
            return True, filtered_alerts
        else:
            return False, f"API error: {response.status_code} - {response.text}"
            
    except Exception as e:
        return False, f"Error retrieving alerts: {str(e)}"

def get_trend_data(data_type, metric, location=None, days=30):
    """
    Get trend data for a specific pollution metric.
    
    Args:
        data_type (str): 'water' or 'air'
        metric (str): Specific metric to trend
        location (str, optional): Location name
        days (int): Number of days to include
        
    Returns:
        Tuple: (success (bool), data or error message (pd.DataFrame or str))
    """
    try:
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)
        
        url = f"{DEEPSEEK_BASE_URL}/trends/{data_type}/{metric}"
        headers = {
            "Authorization": f"Bearer {DEEPSEEK_API_KEY}",
            "Content-Type": "application/json"
        }
        
        params = {
            "start_date": start_date.strftime("%Y-%m-%d"),
            "end_date": end_date.strftime("%Y-%m-%d")
        }
        
        if location:
            params["location"] = location
            
        response = requests.get(url, headers=headers, params=params)
        
        if response.status_code == 200:
            trend_data = response.json().get("trend_data", [])
            df = pd.DataFrame(trend_data)
            return True, df
        else:
            return False, f"API error: {response.status_code} - {response.text}"
            
    except Exception as e:
        return False, f"Error retrieving trend data: {str(e)}"

def analyze_pollution_correlation(location=None):
    """
    Analyze correlation between water and air pollution in a location.
    
    Args:
        location (str, optional): Location name
        
    Returns:
        Tuple: (success (bool), data or error message (dict or str))
    """
    try:
        url = f"{DEEPSEEK_BASE_URL}/analysis/correlation"
        headers = {
            "Authorization": f"Bearer {DEEPSEEK_API_KEY}",
            "Content-Type": "application/json"
        }
        
        params = {}
        if location:
            params["location"] = location
            
        response = requests.get(url, headers=headers, params=params)
        
        if response.status_code == 200:
            return True, response.json()
        else:
            return False, f"API error: {response.status_code} - {response.text}"
            
    except Exception as e:
        return False, f"Error analyzing correlation: {str(e)}"

def generate_pollution_report(location, data_types=["water", "air"]):
    """
    Generate a comprehensive pollution report for a location.
    
    Args:
        location (str): Location to generate report for
        data_types (list): Types of pollution to include
        
    Returns:
        Tuple: (success (bool), report or error message (dict or str))
    """
    try:
        url = f"{DEEPSEEK_BASE_URL}/reports/generate"
        headers = {
            "Authorization": f"Bearer {DEEPSEEK_API_KEY}",
            "Content-Type": "application/json"
        }
        
        data = {
            "location": location,
            "data_types": data_types,
            "format": "json"
        }
            
        response = requests.post(url, headers=headers, json=data)
        
        if response.status_code == 200:
            return True, response.json()
        else:
            return False, f"API error: {response.status_code} - {response.text}"
            
    except Exception as e:
        return False, f"Error generating report: {str(e)}"

def handle_deepseek_api_error(error_msg):
    """Format error messages from DeepSeek API for display."""
    return {
        "error": True,
        "message": str(error_msg),
        "status": "API Error"
    }

# Advanced LLM integration with DeepSeek
def get_pollution_analysis(prompt, context_data=None):
    """
    Get AI-powered analysis of pollution data using DeepSeek's language models.
    
    Args:
        prompt (str): Analysis request or question
        context_data (dict, optional): Additional contextual data
        
    Returns:
        Tuple: (success (bool), analysis or error message (str))
    """
    try:
        url = f"{DEEPSEEK_BASE_URL}/llm/analyze"
        headers = {
            "Authorization": f"Bearer {DEEPSEEK_API_KEY}",
            "Content-Type": "application/json"
        }
        
        data = {
            "prompt": prompt,
            "max_tokens": 500
        }
        
        if context_data:
            data["context"] = json.dumps(context_data)
            
        response = requests.post(url, headers=headers, json=data)
        
        if response.status_code == 200:
            return True, response.json().get("analysis", "No analysis provided")
        else:
            return False, f"API error: {response.status_code} - {response.text}"
            
    except Exception as e:
        return False, f"Error getting analysis: {str(e)}"