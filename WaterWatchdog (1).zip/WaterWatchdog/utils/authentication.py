import streamlit as st
import streamlit_authenticator as stauth
import yaml
from yaml.loader import SafeLoader
import os
import pickle
from datetime import datetime, timedelta
import bcrypt

# File path for user credentials
CREDENTIALS_FILE = "credentials.yaml"

def init_authentication():
    """Initialize authentication configuration and return authenticator object"""
    # Check if credentials file exists, create default if not
    if not os.path.exists(CREDENTIALS_FILE):
        # Create default credentials file with admin user
        credentials = {
            'usernames': {
                'admin': {
                    'name': 'Administrator',
                    'email': 'admin@sawatermonitor.co.za',
                    'password': stauth.Hasher().generate(['admin'])[0],
                    'role': 'admin',
                    'subscription_type': 'yearly',
                    'subscription_start': datetime.now().strftime('%Y-%m-%d'),
                    'subscription_end': (datetime.now() + timedelta(days=365)).strftime('%Y-%m-%d'),
                    'registered_date': datetime.now().strftime('%Y-%m-%d'),
                }
            }
        }
        
        # Save to YAML file
        with open(CREDENTIALS_FILE, 'w') as file:
            yaml.dump(credentials, file, default_flow_style=False)
    
    # Load credentials
    with open(CREDENTIALS_FILE, 'r') as file:
        credentials = yaml.load(file, Loader=SafeLoader)
    
    # Configure authenticator
    authenticator = stauth.Authenticate(
        credentials=credentials['usernames'],
        cookie_name='sa_water_systems_auth',
        key='auth_key',
        cookie_expiry_days=30
    )
    
    return authenticator

def save_credentials(credentials):
    """Save updated credentials to file"""
    # Format for storage
    creds_dict = {'usernames': credentials}
    
    # Save to YAML file
    with open(CREDENTIALS_FILE, 'w') as file:
        yaml.dump(creds_dict, file, default_flow_style=False)

def register_new_user(username, name, password, email, role='user', subscription_type=None):
    """Register a new user in the system"""
    # Load existing credentials
    with open(CREDENTIALS_FILE, 'r') as file:
        credentials = yaml.load(file, Loader=SafeLoader)
    
    # Check if username already exists
    if username in credentials['usernames']:
        return False, "Username already exists"
    
    # Hash password
    hashed_password = stauth.Hasher().generate([password])[0]
    
    # Calculate subscription dates if applicable
    subscription_start = datetime.now()
    if subscription_type == 'monthly':
        subscription_end = subscription_start + timedelta(days=30)
    elif subscription_type == 'yearly':
        subscription_end = subscription_start + timedelta(days=365)
    else:
        subscription_end = None
    
    # Create new user entry
    credentials['usernames'][username] = {
        'name': name,
        'email': email,
        'password': hashed_password,
        'role': role,
        'subscription_type': subscription_type,
        'subscription_start': subscription_start.strftime('%Y-%m-%d') if subscription_type else None,
        'subscription_end': subscription_end.strftime('%Y-%m-%d') if subscription_type else None,
        'registered_date': datetime.now().strftime('%Y-%m-%d'),
    }
    
    # Save updated credentials
    with open(CREDENTIALS_FILE, 'w') as file:
        yaml.dump(credentials, file, default_flow_style=False)
    
    return True, "User registered successfully"

def is_subscription_active(username):
    """Check if a user's subscription is active"""
    # Load credentials
    with open(CREDENTIALS_FILE, 'r') as file:
        credentials = yaml.load(file, Loader=SafeLoader)
    
    # Check if user exists
    if username not in credentials['usernames']:
        return False
    
    user_data = credentials['usernames'][username]
    
    # If no subscription, return False
    if not user_data.get('subscription_type') or not user_data.get('subscription_end'):
        return False
    
    # Check if subscription is still valid
    subscription_end = datetime.strptime(user_data['subscription_end'], '%Y-%m-%d')
    return datetime.now() <= subscription_end

def get_user_details(username):
    """Get details for a specific user"""
    # Load credentials
    with open(CREDENTIALS_FILE, 'r') as file:
        credentials = yaml.load(file, Loader=SafeLoader)
    
    # Check if user exists
    if username not in credentials['usernames']:
        return None
    
    # Return user details (excluding password)
    user_data = credentials['usernames'][username].copy()
    if 'password' in user_data:
        del user_data['password']
    
    return user_data

def update_user_subscription(username, subscription_type):
    """Update a user's subscription type and dates"""
    # Load credentials
    with open(CREDENTIALS_FILE, 'r') as file:
        credentials = yaml.load(file, Loader=SafeLoader)
    
    # Check if user exists
    if username not in credentials['usernames']:
        return False, "User not found"
    
    # Calculate new subscription dates
    subscription_start = datetime.now()
    if subscription_type == 'monthly':
        subscription_end = subscription_start + timedelta(days=30)
    elif subscription_type == 'yearly':
        subscription_end = subscription_start + timedelta(days=365)
    else:
        return False, "Invalid subscription type"
    
    # Update user data
    credentials['usernames'][username]['subscription_type'] = subscription_type
    credentials['usernames'][username]['subscription_start'] = subscription_start.strftime('%Y-%m-%d')
    credentials['usernames'][username]['subscription_end'] = subscription_end.strftime('%Y-%m-%d')
    
    # Save updated credentials
    with open(CREDENTIALS_FILE, 'w') as file:
        yaml.dump(credentials, file, default_flow_style=False)
    
    return True, "Subscription updated successfully"