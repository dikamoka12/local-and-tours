"""Common utilities used across multiple pages"""

import streamlit as st

def display_apartheid_message():
    """Display the apartheid message with consistent styling"""
    st.markdown("<div style='background-color:#B22222; padding:15px; border-radius:10px; margin:15px 0px;'><h3 style='color:white; text-align:center; margin:0;'>Forced removals do catch up with the remover (apartheid)</h3></div>", unsafe_allow_html=True)

def display_traditional_water_knowledge():
    """Display the Traditional Water Knowledge message with consistent styling"""
    st.markdown("<div style='background-color:#006400; padding:15px; border-radius:10px; margin:15px 0px;'><h3 style='color:white; text-align:center; margin:0;'>Traditional Water Knowledge</h3></div>", unsafe_allow_html=True)

def display_common_messages():
    """Display both the Traditional Water Knowledge and apartheid messages with consistent styling"""
    display_traditional_water_knowledge()
    # We only display apartheid message in the footer now, not in the middle of pages