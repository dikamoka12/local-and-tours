import streamlit as st
import json
import os
import logging

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Default language is English
DEFAULT_LANGUAGE = "english"

# Available languages for the app (South African official languages)
AVAILABLE_LANGUAGES = {
    "english": "English",
    "afrikaans": "Afrikaans",
    "zulu": "isiZulu",
    "xhosa": "isiXhosa",
    "sotho": "Sesotho",
    "tswana": "Setswana",
    "venda": "Tshivenda",
    "tsonga": "Xitsonga",
    "swati": "siSwati",
    "ndebele": "isiNdebele",
    "pedi": "Sepedi"
}

# Dictionary to store translations
TRANSLATIONS = {}

def load_translations():
    """
    Load translations from JSON files
    """
    global TRANSLATIONS
    
    # Create translations directory if it doesn't exist
    os.makedirs("translations", exist_ok=True)
    
    for lang_code in AVAILABLE_LANGUAGES.keys():
        translation_file = f"translations/{lang_code}.json"
        
        # Create default translation file if it doesn't exist
        if not os.path.exists(translation_file) and lang_code != DEFAULT_LANGUAGE:
            create_default_translation_file(lang_code)
        
        # Load translation
        try:
            with open(translation_file, 'r', encoding='utf-8') as f:
                TRANSLATIONS[lang_code] = json.load(f)
            logger.info(f"Loaded translations for {lang_code}")
        except Exception as e:
            logger.error(f"Error loading translations for {lang_code}: {str(e)}")
            # Initialize with empty dictionary if file can't be loaded
            TRANSLATIONS[lang_code] = {}

def create_default_translation_file(lang_code):
    """
    Create a default translation file with English strings
    """
    # Default English strings that need translation
    default_strings = {
        # Common UI elements
        "app_title": "South African Water Systems",
        "app_subtitle": "Tourists and Locals",
        "navigation": "Navigation",
        "search": "Search",
        "filters": "Filters",
        "home": "Home",
        "water_sources": "Water Sources",
        "city_rankings": "City Rankings",
        "pollution_alerts": "Pollution Alerts",
        "global_pollution_map": "Global Pollution Map",
        "country_analysis": "Country Analysis",
        "pollution_database": "Pollution Database",
        "toxic_chemicals": "Toxic Chemicals",
        "beach_houses": "Beach Houses",
        "sa_water_systems": "SA Water Systems",
        "community_forum": "Community Forum",
        "educational_resources": "Educational Resources",
        "subscription": "Subscription",
        "login_register": "Login/Register",
        
        # Water types
        "all": "All",
        "rivers": "Rivers",
        "dams": "Dams",
        "oceans": "Oceans",
        "tap_water": "Tap Water",
        "underground_water": "Underground Water",
        "spring_water": "Spring Water",
        "others": "Others",
        
        # Regions
        "north_america": "North America",
        "south_america": "South America",
        "europe": "Europe",
        "africa": "Africa",
        "asia": "Asia",
        "oceania": "Oceania",
        
        # Critical alerts and water safety
        "alert_critical": "CRITICAL ALERT",
        "alert_high": "HIGH ALERT",
        "alert_moderate": "MODERATE ALERT",
        "water_unsafe": "Water unsafe for consumption or contact",
        "water_limited_use": "Limited water use recommended",
        "water_safe": "Water safe for designated uses",
        
        # Footer text
        "copyright": "© 2025 South African Water Systems Monitor. All rights reserved.",
        "emergency_contact": "For water emergencies, contact: support@sawatermonitor.co.za | +27 800 123 456",
        "download_offline": "Download Offline Version",
        
        # Login and subscription
        "login": "Login",
        "register": "Register",
        "username": "Username",
        "password": "Password",
        "email": "Email",
        "subscribe": "Subscribe",
        "monthly_plan": "Monthly Plan - R25",
        "yearly_plan": "Yearly Plan - R300",
        
        # Notifications
        "notifications": "Notifications",
        "sms_alerts": "SMS Alerts",
        "email_alerts": "Email Alerts",
        "alert_settings": "Alert Settings",
        "test_notification": "Test Notification",
        "notification_sent": "Notification Sent",
        
        # Educational content
        "traditional_knowledge": "Traditional Knowledge",
        "water_safety": "Water Safety",
        "pollution_effects": "Pollution Effects",
        "conservation": "Conservation",
        
        # Critical water safety messages
        "boil_water_notice": "IMPORTANT: Boil water before consumption",
        "do_not_use_notice": "IMPORTANT: Do not use this water",
        "safe_water_notice": "Water is safe for all uses",
    }
    
    # Save to file
    try:
        with open(f"translations/{lang_code}.json", 'w', encoding='utf-8') as f:
            json.dump(default_strings, f, ensure_ascii=False, indent=4)
        logger.info(f"Created default translation file for {lang_code}")
    except Exception as e:
        logger.error(f"Error creating default translation file for {lang_code}: {str(e)}")

def get_current_language():
    """
    Get the currently selected language from session state
    """
    if 'language' not in st.session_state:
        st.session_state.language = DEFAULT_LANGUAGE
    return st.session_state.language

def set_language(language):
    """
    Set the current language in session state
    """
    if language in AVAILABLE_LANGUAGES:
        st.session_state.language = language
        logger.info(f"Language set to {language}")
    else:
        logger.warning(f"Attempted to set invalid language: {language}")

def get_text(key):
    """
    Get translated text for a key in the current language
    """
    current_lang = get_current_language()
    
    # If translation exists for current language
    if current_lang in TRANSLATIONS and key in TRANSLATIONS[current_lang]:
        return TRANSLATIONS[current_lang][key]
    
    # Fallback to English
    if DEFAULT_LANGUAGE in TRANSLATIONS and key in TRANSLATIONS[DEFAULT_LANGUAGE]:
        return TRANSLATIONS[DEFAULT_LANGUAGE][key]
    
    # Last resort: return the key itself
    return key

def language_selector():
    """
    Display a language selector in the sidebar
    """
    st.sidebar.markdown("---")
    st.sidebar.subheader("Language / Taal / Ulwimi")
    
    # Convert language dict to list of tuples for selectbox
    language_options = list(AVAILABLE_LANGUAGES.items())
    
    # Find index of current language
    current_lang = get_current_language()
    current_index = next((i for i, (code, _) in enumerate(language_options) if code == current_lang), 0)
    
    # Create selectbox
    selected_lang_index = st.sidebar.selectbox(
        "Select Language",
        range(len(language_options)),
        format_func=lambda i: language_options[i][1],
        index=current_index
    )
    
    # Update language if changed
    if language_options[selected_lang_index][0] != current_lang:
        set_language(language_options[selected_lang_index][0])
        # Rerun app to apply language change
        st.rerun()

# Initialize translations
def init_translations():
    """
    Initialize translations when the app starts
    """
    # Load all available translations
    load_translations()
    
    # Create English translation file if it doesn't exist
    if not os.path.exists("translations/english.json"):
        create_default_translation_file("english")
        # Reload translations after creating default file
        load_translations()

# Create initial translation files for the most important languages
def create_initial_translations():
    """
    Create initial translation files with some translations filled in
    """
    # Afrikaans translations
    afrikaans = {
        "app_title": "Suid-Afrikaanse Waterstelsels",
        "app_subtitle": "Toeriste en Plaaslike",
        "navigation": "Navigasie",
        "search": "Soek",
        "filters": "Filters",
        "home": "Tuis",
        "water_sources": "Waterbronne",
        "alert_critical": "KRITIESE WAARSKUWING",
        "alert_high": "HOË WAARSKUWING",
        "alert_moderate": "MATIGE WAARSKUWING",
        "water_unsafe": "Water onveilig vir gebruik of kontak",
        "water_limited_use": "Beperkte watergebruik aanbeveel",
        "water_safe": "Water veilig vir aangewese gebruike",
        "download_offline": "Laai Vanlyn Weergawe Af",
        "boil_water_notice": "BELANGRIK: Kook water voor gebruik",
        "do_not_use_notice": "BELANGRIK: Moenie hierdie water gebruik nie",
        "safe_water_notice": "Water is veilig vir alle gebruike",
    }
    
    # isiZulu translations
    zulu = {
        "app_title": "Izinhlelo Zamanzi waseNingizimu Afrika",
        "app_subtitle": "Izivakashi Nabantu Basekhaya",
        "navigation": "Ukuzulazula",
        "search": "Sesha",
        "filters": "Izihlungi",
        "home": "Ikhaya",
        "water_sources": "Imithombo Yamanzi",
        "alert_critical": "ISEXWAYISO ESIBALULEKILE",
        "alert_high": "ISEXWAYISO ESIPHEZULU",
        "alert_moderate": "ISEXWAYISO ESINGAKANANI",
        "water_unsafe": "Amanzi awaphephile ukusetshenziswa noma ukuthinta",
        "water_limited_use": "Ukusetshenziswa kwamanzi okulinganiselwe kunconyelwa",
        "water_safe": "Amanzi aphephile ekusetshenzisweni okukhethiweyo",
        "download_offline": "Landa Inguqulo Engaxhunyiwe",
        "boil_water_notice": "OKUBALULEKILE: Bilisa amanzi ngaphambi kokuwasebenzisa",
        "do_not_use_notice": "OKUBALULEKILE: Ungawasebenzisi la manzi",
        "safe_water_notice": "Amanzi aphephile ekusetshenzisweni konke",
    }
    
    # isiXhosa translations
    xhosa = {
        "app_title": "Iinkqubo Zamanzi eMzantsi Afrika",
        "app_subtitle": "Abakhenkethi Nabahlali",
        "navigation": "Uhamba-hambo",
        "search": "Khangela",
        "filters": "Izihluzi",
        "home": "Ikhaya",
        "water_sources": "Imithombo Yamanzi",
        "alert_critical": "ISILUMKISO ESIBALULEKILEYO",
        "alert_high": "ISILUMKISO ESIPHEZULU",
        "alert_moderate": "ISILUMKISO ESIPHAKATHI",
        "water_unsafe": "Amanzi awakhuselekanga ukusetyenziswa okanye ukunxibelelana",
        "water_limited_use": "Ukusetyenziswa kwamanzi okulinganiselweyo kuyacetyiswa",
        "water_safe": "Amanzi akhuselekile ekusetyenzisweni okuchongiweyo",
        "download_offline": "Khuphela Uguqulelo Olungekho kwi-Intanethi",
        "boil_water_notice": "KUBALULEKILE: Bilisa amanzi phambi kokuwasebenzisa",
        "do_not_use_notice": "KUBALULEKILE: Musa ukusebenzisa la manzi",
        "safe_water_notice": "Amanzi akhuselekile ekusetyenzisweni konke",
    }
    
    # Save translations
    try:
        if not os.path.exists("translations"):
            os.makedirs("translations")
        
        with open("translations/afrikaans.json", 'w', encoding='utf-8') as f:
            json.dump(afrikaans, f, ensure_ascii=False, indent=4)
        
        with open("translations/zulu.json", 'w', encoding='utf-8') as f:
            json.dump(zulu, f, ensure_ascii=False, indent=4)
        
        with open("translations/xhosa.json", 'w', encoding='utf-8') as f:
            json.dump(xhosa, f, ensure_ascii=False, indent=4)
        
        logger.info("Created initial translations for Afrikaans, isiZulu, and isiXhosa")
    except Exception as e:
        logger.error(f"Error creating initial translations: {str(e)}")

# Call this at startup
def initialize():
    # Create translations directory
    os.makedirs("translations", exist_ok=True)
    
    # Create initial translations
    create_initial_translations()
    
    # Load all translations
    init_translations()