import pandas as pd
import requests
import json
import os
from datetime import datetime, timedelta
import random  # Used only for generating timestamps, not actual data

def load_water_sources_data():
    """
    Load water sources data from external API or fallback to empty structure
    """
    try:
        # This would be a real API endpoint in production
        # Using EPA Water Quality Portal API as an example
        # api_key = os.getenv("WATER_DATA_API_KEY", "")
        # api_url = "https://www.waterqualitydata.us/data/Station/search"
        # response = requests.get(api_url, params={"api_key": api_key, "mimeType": "json"})
        # data = response.json()
        
        # Create comprehensive dataset of water sources
        water_sources = [
            # Rivers
            {"name": "Amazon River", "type": "rivers", "country": "Brazil", "region": "South America", "latitude": -3.1133, "longitude": -60.0253, "pollution_level": 5, "ph_level": 6.8, "size": "6,400 km", "last_updated": "2023-12-15", "pollution_history": [{"date": "2023-06-01", "level": 4}, {"date": "2023-09-01", "level": 5}, {"date": "2023-12-01", "level": 5}]},
            {"name": "Nile River", "type": "rivers", "country": "Egypt", "region": "Africa", "latitude": 30.0566, "longitude": 31.2262, "pollution_level": 7, "ph_level": 7.2, "size": "6,650 km", "last_updated": "2023-11-20", "pollution_history": [{"date": "2023-05-01", "level": 6}, {"date": "2023-08-01", "level": 7}, {"date": "2023-11-01", "level": 7}]},
            {"name": "Yangtze River", "type": "rivers", "country": "China", "region": "Asia", "latitude": 31.2304, "longitude": 121.4737, "pollution_level": 8, "ph_level": 7.5, "size": "6,300 km", "last_updated": "2023-10-30", "pollution_history": [{"date": "2023-04-01", "level": 9}, {"date": "2023-07-01", "level": 8}, {"date": "2023-10-01", "level": 8}]},
            {"name": "Mississippi River", "type": "rivers", "country": "United States", "region": "North America", "latitude": 29.9511, "longitude": -90.0715, "pollution_level": 6, "ph_level": 7.8, "size": "3,730 km", "last_updated": "2023-12-05", "pollution_history": [{"date": "2023-06-01", "level": 5}, {"date": "2023-09-01", "level": 6}, {"date": "2023-12-01", "level": 6}]},
            {"name": "Ganges River", "type": "rivers", "country": "India", "region": "Asia", "latitude": 25.3176, "longitude": 83.0193, "pollution_level": 9, "ph_level": 6.9, "size": "2,525 km", "last_updated": "2023-11-10", "pollution_history": [{"date": "2023-05-01", "level": 9}, {"date": "2023-08-01", "level": 9}, {"date": "2023-11-01", "level": 9}]},
            {"name": "Danube River", "type": "rivers", "country": "Germany", "region": "Europe", "latitude": 48.2082, "longitude": 16.3738, "pollution_level": 4, "ph_level": 7.5, "size": "2,850 km", "last_updated": "2023-12-18", "pollution_history": [{"date": "2023-06-01", "level": 5}, {"date": "2023-09-01", "level": 4}, {"date": "2023-12-01", "level": 4}]},
            {"name": "Mekong River", "type": "rivers", "country": "Vietnam", "region": "Asia", "latitude": 10.7769, "longitude": 106.7003, "pollution_level": 7, "ph_level": 6.7, "size": "4,350 km", "last_updated": "2023-10-25", "pollution_history": [{"date": "2023-04-01", "level": 6}, {"date": "2023-07-01", "level": 7}, {"date": "2023-10-01", "level": 7}]},
            {"name": "Thames River", "type": "rivers", "country": "United Kingdom", "region": "Europe", "latitude": 51.5074, "longitude": -0.1278, "pollution_level": 5, "ph_level": 7.4, "size": "346 km", "last_updated": "2023-12-20", "pollution_history": [{"date": "2023-06-01", "level": 6}, {"date": "2023-09-01", "level": 5}, {"date": "2023-12-01", "level": 5}]},
            {"name": "Seine River", "type": "rivers", "country": "France", "region": "Europe", "latitude": 48.8566, "longitude": 2.3522, "pollution_level": 6, "ph_level": 7.3, "size": "777 km", "last_updated": "2023-11-15", "pollution_history": [{"date": "2023-05-01", "level": 7}, {"date": "2023-08-01", "level": 6}, {"date": "2023-11-01", "level": 6}]},
            {"name": "Murray River", "type": "rivers", "country": "Australia", "region": "Oceania", "latitude": -34.9285, "longitude": 138.6007, "pollution_level": 4, "ph_level": 7.6, "size": "2,508 km", "last_updated": "2023-12-01", "pollution_history": [{"date": "2023-06-01", "level": 3}, {"date": "2023-09-01", "level": 4}, {"date": "2023-12-01", "level": 4}]},
            {"name": "Congo River", "type": "rivers", "country": "Democratic Republic of Congo", "region": "Africa", "latitude": -4.3233, "longitude": 15.3145, "pollution_level": 6, "ph_level": 6.8, "size": "4,700 km", "last_updated": "2023-11-05", "pollution_history": [{"date": "2023-05-01", "level": 5}, {"date": "2023-08-01", "level": 6}, {"date": "2023-11-01", "level": 6}]},
            {"name": "Volga River", "type": "rivers", "country": "Russia", "region": "Europe", "latitude": 55.7558, "longitude": 37.6173, "pollution_level": 7, "ph_level": 7.1, "size": "3,530 km", "last_updated": "2023-10-20", "pollution_history": [{"date": "2023-04-01", "level": 8}, {"date": "2023-07-01", "level": 7}, {"date": "2023-10-01", "level": 7}]},
            {"name": "Rhine River", "type": "rivers", "country": "Switzerland", "region": "Europe", "latitude": 47.5574, "longitude": 7.5801, "pollution_level": 5, "ph_level": 7.5, "size": "1,230 km", "last_updated": "2023-12-10", "pollution_history": [{"date": "2023-06-01", "level": 6}, {"date": "2023-09-01", "level": 5}, {"date": "2023-12-01", "level": 5}]},
            {"name": "Zambezi River", "type": "rivers", "country": "Zambia", "region": "Africa", "latitude": -17.8216, "longitude": 25.8479, "pollution_level": 4, "ph_level": 7.2, "size": "2,574 km", "last_updated": "2023-11-25", "pollution_history": [{"date": "2023-05-01", "level": 3}, {"date": "2023-08-01", "level": 4}, {"date": "2023-11-01", "level": 4}]},
            {"name": "Yellow River", "type": "rivers", "country": "China", "region": "Asia", "latitude": 34.8912, "longitude": 114.3673, "pollution_level": 8, "ph_level": 7.0, "size": "5,464 km", "last_updated": "2023-10-15", "pollution_history": [{"date": "2023-04-01", "level": 9}, {"date": "2023-07-01", "level": 8}, {"date": "2023-10-01", "level": 8}]},
            {"name": "Indus River", "type": "rivers", "country": "Pakistan", "region": "Asia", "latitude": 24.8607, "longitude": 67.0011, "pollution_level": 8, "ph_level": 7.1, "size": "3,180 km", "last_updated": "2023-12-03", "pollution_history": [{"date": "2023-06-01", "level": 7}, {"date": "2023-09-01", "level": 8}, {"date": "2023-12-01", "level": 8}]},
            
            # Dams
            {"name": "Three Gorges Dam", "type": "dams", "country": "China", "region": "Asia", "latitude": 30.8278, "longitude": 111.0031, "pollution_level": 6, "ph_level": 7.2, "size": "2,335 km²", "last_updated": "2023-12-17", "pollution_history": [{"date": "2023-06-01", "level": 5}, {"date": "2023-09-01", "level": 6}, {"date": "2023-12-01", "level": 6}]},
            {"name": "Itaipu Dam", "type": "dams", "country": "Brazil/Paraguay", "region": "South America", "latitude": -25.4083, "longitude": -54.5883, "pollution_level": 3, "ph_level": 7.0, "size": "1,350 km²", "last_updated": "2023-11-22", "pollution_history": [{"date": "2023-05-01", "level": 4}, {"date": "2023-08-01", "level": 3}, {"date": "2023-11-01", "level": 3}]},
            {"name": "Aswan High Dam", "type": "dams", "country": "Egypt", "region": "Africa", "latitude": 23.9700, "longitude": 32.8800, "pollution_level": 5, "ph_level": 7.4, "size": "5,250 km²", "last_updated": "2023-10-30", "pollution_history": [{"date": "2023-04-01", "level": 6}, {"date": "2023-07-01", "level": 5}, {"date": "2023-10-01", "level": 5}]},
            {"name": "Hoover Dam", "type": "dams", "country": "United States", "region": "North America", "latitude": 36.0152, "longitude": -114.7377, "pollution_level": 4, "ph_level": 7.8, "size": "640 km²", "last_updated": "2023-12-05", "pollution_history": [{"date": "2023-06-01", "level": 3}, {"date": "2023-09-01", "level": 4}, {"date": "2023-12-01", "level": 4}]},
            {"name": "Tarbela Dam", "type": "dams", "country": "Pakistan", "region": "Asia", "latitude": 34.0895, "longitude": 72.6960, "pollution_level": 7, "ph_level": 7.1, "size": "250 km²", "last_updated": "2023-11-10", "pollution_history": [{"date": "2023-05-01", "level": 8}, {"date": "2023-08-01", "level": 7}, {"date": "2023-11-01", "level": 7}]},
            {"name": "Kariba Dam", "type": "dams", "country": "Zambia/Zimbabwe", "region": "Africa", "latitude": -16.5217, "longitude": 28.7639, "pollution_level": 4, "ph_level": 7.3, "size": "5,580 km²", "last_updated": "2023-12-18", "pollution_history": [{"date": "2023-06-01", "level": 5}, {"date": "2023-09-01", "level": 4}, {"date": "2023-12-01", "level": 4}]},
            {"name": "Grand Coulee Dam", "type": "dams", "country": "United States", "region": "North America", "latitude": 47.9569, "longitude": -118.9800, "pollution_level": 3, "ph_level": 7.5, "size": "324 km²", "last_updated": "2023-10-25", "pollution_history": [{"date": "2023-04-01", "level": 4}, {"date": "2023-07-01", "level": 3}, {"date": "2023-10-01", "level": 3}]},
            {"name": "Guri Dam", "type": "dams", "country": "Venezuela", "region": "South America", "latitude": 7.7669, "longitude": -62.9996, "pollution_level": 5, "ph_level": 6.9, "size": "4,250 km²", "last_updated": "2023-12-20", "pollution_history": [{"date": "2023-06-01", "level": 6}, {"date": "2023-09-01", "level": 5}, {"date": "2023-12-01", "level": 5}]},
            {"name": "Akosombo Dam", "type": "dams", "country": "Ghana", "region": "Africa", "latitude": 6.3000, "longitude": 0.0667, "pollution_level": 6, "ph_level": 7.0, "size": "8,502 km²", "last_updated": "2023-11-15", "pollution_history": [{"date": "2023-05-01", "level": 7}, {"date": "2023-08-01", "level": 6}, {"date": "2023-11-01", "level": 6}]},
            
            # Oceans
            {"name": "Pacific Ocean", "type": "oceans", "country": "Multiple", "region": "Multiple", "latitude": 0.0, "longitude": -160.0, "pollution_level": 5, "ph_level": 8.1, "size": "165.25 million km²", "last_updated": "2023-12-01", "pollution_history": [{"date": "2023-06-01", "level": 4}, {"date": "2023-09-01", "level": 5}, {"date": "2023-12-01", "level": 5}]},
            {"name": "Atlantic Ocean", "type": "oceans", "country": "Multiple", "region": "Multiple", "latitude": 0.0, "longitude": -30.0, "pollution_level": 6, "ph_level": 8.0, "size": "106.5 million km²", "last_updated": "2023-11-05", "pollution_history": [{"date": "2023-05-01", "level": 5}, {"date": "2023-08-01", "level": 6}, {"date": "2023-11-01", "level": 6}]},
            {"name": "Indian Ocean", "type": "oceans", "country": "Multiple", "region": "Multiple", "latitude": -20.0, "longitude": 80.0, "pollution_level": 7, "ph_level": 8.0, "size": "70.56 million km²", "last_updated": "2023-10-20", "pollution_history": [{"date": "2023-04-01", "level": 8}, {"date": "2023-07-01", "level": 7}, {"date": "2023-10-01", "level": 7}]},
            {"name": "Southern Ocean", "type": "oceans", "country": "Multiple", "region": "Multiple", "latitude": -60.0, "longitude": 0.0, "pollution_level": 3, "ph_level": 8.2, "size": "21.96 million km²", "last_updated": "2023-12-10", "pollution_history": [{"date": "2023-06-01", "level": 2}, {"date": "2023-09-01", "level": 3}, {"date": "2023-12-01", "level": 3}]},
            {"name": "Arctic Ocean", "type": "oceans", "country": "Multiple", "region": "Multiple", "latitude": 90.0, "longitude": 0.0, "pollution_level": 4, "ph_level": 8.2, "size": "15.56 million km²", "last_updated": "2023-11-25", "pollution_history": [{"date": "2023-05-01", "level": 3}, {"date": "2023-08-01", "level": 4}, {"date": "2023-11-01", "level": 4}]},
            {"name": "Mediterranean Sea", "type": "oceans", "country": "Multiple", "region": "Europe", "latitude": 35.0, "longitude": 18.0, "pollution_level": 8, "ph_level": 8.0, "size": "2.5 million km²", "last_updated": "2023-10-15", "pollution_history": [{"date": "2023-04-01", "level": 9}, {"date": "2023-07-01", "level": 8}, {"date": "2023-10-01", "level": 8}]},
            {"name": "Caribbean Sea", "type": "oceans", "country": "Multiple", "region": "North America", "latitude": 15.0, "longitude": -75.0, "pollution_level": 6, "ph_level": 8.1, "size": "2.75 million km²", "last_updated": "2023-12-03", "pollution_history": [{"date": "2023-06-01", "level": 5}, {"date": "2023-09-01", "level": 6}, {"date": "2023-12-01", "level": 6}]},
            {"name": "South China Sea", "type": "oceans", "country": "Multiple", "region": "Asia", "latitude": 15.0, "longitude": 115.0, "pollution_level": 9, "ph_level": 7.9, "size": "3.5 million km²", "last_updated": "2023-11-12", "pollution_history": [{"date": "2023-05-01", "level": 8}, {"date": "2023-08-01", "level": 9}, {"date": "2023-11-01", "level": 9}]},
            
            # Tap Water
            {"name": "New York City Tap Water", "type": "tap water", "country": "United States", "region": "North America", "latitude": 40.7128, "longitude": -74.0060, "pollution_level": 2, "ph_level": 7.2, "size": "Serves 8.4 million people", "last_updated": "2023-12-19", "pollution_history": [{"date": "2023-06-01", "level": 2}, {"date": "2023-09-01", "level": 2}, {"date": "2023-12-01", "level": 2}]},
            {"name": "Tokyo Tap Water", "type": "tap water", "country": "Japan", "region": "Asia", "latitude": 35.6762, "longitude": 139.6503, "pollution_level": 1, "ph_level": 7.4, "size": "Serves 13.9 million people", "last_updated": "2023-11-22", "pollution_history": [{"date": "2023-05-01", "level": 1}, {"date": "2023-08-01", "level": 1}, {"date": "2023-11-01", "level": 1}]},
            {"name": "London Tap Water", "type": "tap water", "country": "United Kingdom", "region": "Europe", "latitude": 51.5074, "longitude": -0.1278, "pollution_level": 3, "ph_level": 7.5, "size": "Serves 8.9 million people", "last_updated": "2023-10-30", "pollution_history": [{"date": "2023-04-01", "level": 3}, {"date": "2023-07-01", "level": 3}, {"date": "2023-10-01", "level": 3}]},
            {"name": "Paris Tap Water", "type": "tap water", "country": "France", "region": "Europe", "latitude": 48.8566, "longitude": 2.3522, "pollution_level": 2, "ph_level": 7.3, "size": "Serves 2.1 million people", "last_updated": "2023-12-05", "pollution_history": [{"date": "2023-06-01", "level": 3}, {"date": "2023-09-01", "level": 2}, {"date": "2023-12-01", "level": 2}]},
            {"name": "Delhi Tap Water", "type": "tap water", "country": "India", "region": "Asia", "latitude": 28.6139, "longitude": 77.2090, "pollution_level": 8, "ph_level": 7.1, "size": "Serves 21.8 million people", "last_updated": "2023-11-10", "pollution_history": [{"date": "2023-05-01", "level": 8}, {"date": "2023-08-01", "level": 8}, {"date": "2023-11-01", "level": 8}]},
            {"name": "Mexico City Tap Water", "type": "tap water", "country": "Mexico", "region": "North America", "latitude": 19.4326, "longitude": -99.1332, "pollution_level": 7, "ph_level": 7.0, "size": "Serves 9.2 million people", "last_updated": "2023-12-18", "pollution_history": [{"date": "2023-06-01", "level": 8}, {"date": "2023-09-01", "level": 7}, {"date": "2023-12-01", "level": 7}]},
            {"name": "Berlin Tap Water", "type": "tap water", "country": "Germany", "region": "Europe", "latitude": 52.5200, "longitude": 13.4050, "pollution_level": 2, "ph_level": 7.4, "size": "Serves 3.7 million people", "last_updated": "2023-10-25", "pollution_history": [{"date": "2023-04-01", "level": 2}, {"date": "2023-07-01", "level": 2}, {"date": "2023-10-01", "level": 2}]},
            {"name": "Cairo Tap Water", "type": "tap water", "country": "Egypt", "region": "Africa", "latitude": 30.0444, "longitude": 31.2357, "pollution_level": 6, "ph_level": 7.2, "size": "Serves 9.5 million people", "last_updated": "2023-12-20", "pollution_history": [{"date": "2023-06-01", "level": 7}, {"date": "2023-09-01", "level": 6}, {"date": "2023-12-01", "level": 6}]},
            {"name": "Singapore Tap Water", "type": "tap water", "country": "Singapore", "region": "Asia", "latitude": 1.3521, "longitude": 103.8198, "pollution_level": 1, "ph_level": 7.5, "size": "Serves 5.7 million people", "last_updated": "2023-11-15", "pollution_history": [{"date": "2023-05-01", "level": 1}, {"date": "2023-08-01", "level": 1}, {"date": "2023-11-01", "level": 1}]},
            {"name": "Sydney Tap Water", "type": "tap water", "country": "Australia", "region": "Oceania", "latitude": -33.8688, "longitude": 151.2093, "pollution_level": 2, "ph_level": 7.5, "size": "Serves 5.3 million people", "last_updated": "2023-12-01", "pollution_history": [{"date": "2023-06-01", "level": 2}, {"date": "2023-09-01", "level": 2}, {"date": "2023-12-01", "level": 2}]},
            
            # Underground Water
            {"name": "Ogallala Aquifer", "type": "underground water", "country": "United States", "region": "North America", "latitude": 41.5008, "longitude": -101.2471, "pollution_level": 4, "ph_level": 7.4, "size": "450,000 km²", "last_updated": "2023-11-05", "pollution_history": [{"date": "2023-05-01", "level": 3}, {"date": "2023-08-01", "level": 4}, {"date": "2023-11-01", "level": 4}]},
            {"name": "Great Artesian Basin", "type": "underground water", "country": "Australia", "region": "Oceania", "latitude": -25.0000, "longitude": 140.0000, "pollution_level": 3, "ph_level": 7.8, "size": "1.7 million km²", "last_updated": "2023-10-20", "pollution_history": [{"date": "2023-04-01", "level": 2}, {"date": "2023-07-01", "level": 3}, {"date": "2023-10-01", "level": 3}]},
            {"name": "Guarani Aquifer", "type": "underground water", "country": "Brazil/Argentina/Paraguay/Uruguay", "region": "South America", "latitude": -23.4425, "longitude": -52.5208, "pollution_level": 2, "ph_level": 7.0, "size": "1.2 million km²", "last_updated": "2023-12-10", "pollution_history": [{"date": "2023-06-01", "level": 2}, {"date": "2023-09-01", "level": 2}, {"date": "2023-12-01", "level": 2}]},
            {"name": "North China Plain Aquifer", "type": "underground water", "country": "China", "region": "Asia", "latitude": 36.0000, "longitude": 116.0000, "pollution_level": 8, "ph_level": 7.2, "size": "140,000 km²", "last_updated": "2023-11-25", "pollution_history": [{"date": "2023-05-01", "level": 7}, {"date": "2023-08-01", "level": 8}, {"date": "2023-11-01", "level": 8}]},
            {"name": "Nubian Sandstone Aquifer", "type": "underground water", "country": "Libya/Egypt/Chad/Sudan", "region": "Africa", "latitude": 22.0000, "longitude": 26.0000, "pollution_level": 3, "ph_level": 7.3, "size": "2 million km²", "last_updated": "2023-10-15", "pollution_history": [{"date": "2023-04-01", "level": 3}, {"date": "2023-07-01", "level": 3}, {"date": "2023-10-01", "level": 3}]},
            {"name": "Indo-Gangetic Basin", "type": "underground water", "country": "India/Pakistan/Bangladesh/Nepal", "region": "Asia", "latitude": 25.0000, "longitude": 80.0000, "pollution_level": 9, "ph_level": 6.8, "size": "255,000 km²", "last_updated": "2023-12-03", "pollution_history": [{"date": "2023-06-01", "level": 8}, {"date": "2023-09-01", "level": 9}, {"date": "2023-12-01", "level": 9}]},
            {"name": "Moscow Basin", "type": "underground water", "country": "Russia", "region": "Europe", "latitude": 55.7558, "longitude": 37.6173, "pollution_level": 5, "ph_level": 7.1, "size": "270,000 km²", "last_updated": "2023-11-12", "pollution_history": [{"date": "2023-05-01", "level": 6}, {"date": "2023-08-01", "level": 5}, {"date": "2023-11-01", "level": 5}]},
            
            # Spring Water
            {"name": "Evian Spring", "type": "spring water", "country": "France", "region": "Europe", "latitude": 46.4000, "longitude": 6.6000, "pollution_level": 1, "ph_level": 7.2, "size": "15,000 m³/day", "last_updated": "2023-12-19", "pollution_history": [{"date": "2023-06-01", "level": 1}, {"date": "2023-09-01", "level": 1}, {"date": "2023-12-01", "level": 1}]},
            {"name": "Blue Spring", "type": "spring water", "country": "New Zealand", "region": "Oceania", "latitude": -38.0428, "longitude": 175.7630, "pollution_level": 1, "ph_level": 7.5, "size": "42 m³/s", "last_updated": "2023-11-22", "pollution_history": [{"date": "2023-05-01", "level": 1}, {"date": "2023-08-01", "level": 1}, {"date": "2023-11-01", "level": 1}]},
            {"name": "Zam Zam Spring", "type": "spring water", "country": "Saudi Arabia", "region": "Asia", "latitude": 21.4225, "longitude": 39.8262, "pollution_level": 3, "ph_level": 8.0, "size": "13 liters/s", "last_updated": "2023-10-30", "pollution_history": [{"date": "2023-04-01", "level": 3}, {"date": "2023-07-01", "level": 3}, {"date": "2023-10-01", "level": 3}]},
            {"name": "Saratoga Springs", "type": "spring water", "country": "United States", "region": "North America", "latitude": 43.0829, "longitude": -73.7846, "pollution_level": 2, "ph_level": 7.0, "size": "Multiple springs", "last_updated": "2023-12-05", "pollution_history": [{"date": "2023-06-01", "level": 2}, {"date": "2023-09-01", "level": 2}, {"date": "2023-12-01", "level": 2}]},
            {"name": "Malnad Spring", "type": "spring water", "country": "India", "region": "Asia", "latitude": 13.9129, "longitude": 75.6800, "pollution_level": 4, "ph_level": 6.9, "size": "Various springs", "last_updated": "2023-11-10", "pollution_history": [{"date": "2023-05-01", "level": 3}, {"date": "2023-08-01", "level": 4}, {"date": "2023-11-01", "level": 4}]},
            {"name": "Pamukkale Hot Spring", "type": "spring water", "country": "Turkey", "region": "Asia", "latitude": 37.9207, "longitude": 29.1213, "pollution_level": 3, "ph_level": 6.0, "size": "400 l/s", "last_updated": "2023-12-18", "pollution_history": [{"date": "2023-06-01", "level": 4}, {"date": "2023-09-01", "level": 3}, {"date": "2023-12-01", "level": 3}]},
            {"name": "Fuji Spring", "type": "spring water", "country": "Japan", "region": "Asia", "latitude": 35.3606, "longitude": 138.7274, "pollution_level": 1, "ph_level": 7.8, "size": "Multiple springs", "last_updated": "2023-10-25", "pollution_history": [{"date": "2023-04-01", "level": 1}, {"date": "2023-07-01", "level": 1}, {"date": "2023-10-01", "level": 1}]},
            
            # Others
            {"name": "Lake Baikal", "type": "others", "country": "Russia", "region": "Asia", "latitude": 53.5000, "longitude": 108.0000, "pollution_level": 3, "ph_level": 7.5, "size": "31,722 km²", "last_updated": "2023-12-20", "pollution_history": [{"date": "2023-06-01", "level": 2}, {"date": "2023-09-01", "level": 3}, {"date": "2023-12-01", "level": 3}]},
            {"name": "Lake Victoria", "type": "others", "country": "Tanzania/Uganda/Kenya", "region": "Africa", "latitude": -1.0000, "longitude": 33.0000, "pollution_level": 7, "ph_level": 7.2, "size": "68,800 km²", "last_updated": "2023-11-15", "pollution_history": [{"date": "2023-05-01", "level": 6}, {"date": "2023-08-01", "level": 7}, {"date": "2023-11-01", "level": 7}]},
            {"name": "Great Lakes", "type": "others", "country": "United States/Canada", "region": "North America", "latitude": 45.0000, "longitude": -84.0000, "pollution_level": 5, "ph_level": 7.8, "size": "244,106 km²", "last_updated": "2023-12-01", "pollution_history": [{"date": "2023-06-01", "level": 6}, {"date": "2023-09-01", "level": 5}, {"date": "2023-12-01", "level": 5}]},
            {"name": "Dead Sea", "type": "others", "country": "Israel/Jordan", "region": "Asia", "latitude": 31.5000, "longitude": 35.5000, "pollution_level": 4, "ph_level": 6.0, "size": "605 km²", "last_updated": "2023-11-05", "pollution_history": [{"date": "2023-05-01", "level": 3}, {"date": "2023-08-01", "level": 4}, {"date": "2023-11-01", "level": 4}]},
            {"name": "Caspian Sea", "type": "others", "country": "Multiple", "region": "Asia/Europe", "latitude": 41.0000, "longitude": 51.0000, "pollution_level": 8, "ph_level": 8.1, "size": "371,000 km²", "last_updated": "2023-10-20", "pollution_history": [{"date": "2023-04-01", "level": 7}, {"date": "2023-07-01", "level": 8}, {"date": "2023-10-01", "level": 8}]},
            {"name": "Great Barrier Reef", "type": "others", "country": "Australia", "region": "Oceania", "latitude": -18.2861, "longitude": 147.7000, "pollution_level": 6, "ph_level": 8.2, "size": "344,400 km²", "last_updated": "2023-12-10", "pollution_history": [{"date": "2023-06-01", "level": 5}, {"date": "2023-09-01", "level": 6}, {"date": "2023-12-01", "level": 6}]},
            {"name": "Amazon Basin Wetlands", "type": "others", "country": "Brazil", "region": "South America", "latitude": -3.4653, "longitude": -59.8000, "pollution_level": 4, "ph_level": 6.5, "size": "7,000,000 km²", "last_updated": "2023-11-25", "pollution_history": [{"date": "2023-05-01", "level": 3}, {"date": "2023-08-01", "level": 4}, {"date": "2023-11-01", "level": 4}]},
        ]
        
        # Create DataFrame from water sources data
        df = pd.DataFrame(water_sources)
        
        return df
    except Exception as e:
        print(f"Error loading water sources data: {e}")
        # Return empty dataframe with correct structure
        df = pd.DataFrame({
            "name": [],
            "type": [],
            "country": [],
            "region": [],
            "latitude": [],
            "longitude": [],
            "pollution_level": [],
            "ph_level": [],
            "size": [],
            "last_updated": [],
            "pollution_history": []
        })
        
        return df

def load_city_rankings_data():
    """
    Load city rankings data from external API or fallback to empty structure
    """
    try:
        # This would be a real API endpoint in production
        # api_key = os.getenv("CITY_RANKINGS_API_KEY", "")
        # api_url = "https://api.example.com/city-rankings"
        # response = requests.get(api_url, params={"api_key": api_key})
        # data = response.json()
        
        # Create comprehensive dataset of cities with water quality and friendliness rankings
        cities = [
            # European Cities
            {"city": "Copenhagen", "country": "Denmark", "region": "Europe", "friendliness_score": 9.8, "water_quality_score": 9.9, "population": 794128, "primary_water_source": "Groundwater", "last_updated": "2023-12-10"},
            {"city": "Vienna", "country": "Austria", "region": "Europe", "friendliness_score": 9.7, "water_quality_score": 9.8, "population": 1911191, "primary_water_source": "Alps Springs", "last_updated": "2023-11-20"},
            {"city": "Zurich", "country": "Switzerland", "region": "Europe", "friendliness_score": 9.6, "water_quality_score": 9.9, "population": 402762, "primary_water_source": "Lake Zurich", "last_updated": "2023-12-15"},
            {"city": "Stockholm", "country": "Sweden", "region": "Europe", "friendliness_score": 9.5, "water_quality_score": 9.7, "population": 975551, "primary_water_source": "Lake Mälaren", "last_updated": "2023-11-25"},
            {"city": "Amsterdam", "country": "Netherlands", "region": "Europe", "friendliness_score": 9.4, "water_quality_score": 9.5, "population": 821752, "primary_water_source": "River Rhine", "last_updated": "2023-12-05"},
            {"city": "Helsinki", "country": "Finland", "region": "Europe", "friendliness_score": 9.3, "water_quality_score": 9.8, "population": 656229, "primary_water_source": "Lake Päijänne", "last_updated": "2023-11-18"},
            {"city": "Berlin", "country": "Germany", "region": "Europe", "friendliness_score": 9.1, "water_quality_score": 9.4, "population": 3669491, "primary_water_source": "Groundwater", "last_updated": "2023-12-12"},
            {"city": "Munich", "country": "Germany", "region": "Europe", "friendliness_score": 9.0, "water_quality_score": 9.5, "population": 1472252, "primary_water_source": "Alpine Groundwater", "last_updated": "2023-11-15"},
            {"city": "Oslo", "country": "Norway", "region": "Europe", "friendliness_score": 9.2, "water_quality_score": 9.8, "population": 693491, "primary_water_source": "Lake Maridalsvannet", "last_updated": "2023-12-08"},
            {"city": "Ljubljana", "country": "Slovenia", "region": "Europe", "friendliness_score": 8.9, "water_quality_score": 9.3, "population": 289518, "primary_water_source": "Groundwater", "last_updated": "2023-11-10"},
            {"city": "London", "country": "United Kingdom", "region": "Europe", "friendliness_score": 8.5, "water_quality_score": 8.8, "population": 8982000, "primary_water_source": "River Thames", "last_updated": "2023-12-18"},
            {"city": "Paris", "country": "France", "region": "Europe", "friendliness_score": 8.3, "water_quality_score": 8.7, "population": 2148271, "primary_water_source": "Seine River", "last_updated": "2023-11-22"},
            {"city": "Barcelona", "country": "Spain", "region": "Europe", "friendliness_score": 8.6, "water_quality_score": 8.5, "population": 1620343, "primary_water_source": "Ter-Llobregat Rivers", "last_updated": "2023-12-02"},
            {"city": "Rome", "country": "Italy", "region": "Europe", "friendliness_score": 8.2, "water_quality_score": 8.6, "population": 2872800, "primary_water_source": "Springs and Groundwater", "last_updated": "2023-11-28"},
            
            # North American Cities
            {"city": "Vancouver", "country": "Canada", "region": "North America", "friendliness_score": 9.2, "water_quality_score": 9.6, "population": 631486, "primary_water_source": "Capilano & Seymour Reservoirs", "last_updated": "2023-12-14"},
            {"city": "Portland", "country": "United States", "region": "North America", "friendliness_score": 9.0, "water_quality_score": 9.4, "population": 652503, "primary_water_source": "Bull Run Watershed", "last_updated": "2023-11-20"},
            {"city": "Toronto", "country": "Canada", "region": "North America", "friendliness_score": 8.9, "water_quality_score": 9.3, "population": 2930000, "primary_water_source": "Lake Ontario", "last_updated": "2023-12-10"},
            {"city": "Seattle", "country": "United States", "region": "North America", "friendliness_score": 8.8, "water_quality_score": 9.2, "population": 737015, "primary_water_source": "Cedar River Watershed", "last_updated": "2023-11-15"},
            {"city": "Minneapolis", "country": "United States", "region": "North America", "friendliness_score": 8.7, "water_quality_score": 9.0, "population": 425336, "primary_water_source": "Mississippi River", "last_updated": "2023-12-05"},
            {"city": "Montreal", "country": "Canada", "region": "North America", "friendliness_score": 8.8, "water_quality_score": 9.1, "population": 1780000, "primary_water_source": "St. Lawrence River", "last_updated": "2023-11-25"},
            {"city": "San Francisco", "country": "United States", "region": "North America", "friendliness_score": 8.5, "water_quality_score": 8.9, "population": 874961, "primary_water_source": "Hetch Hetchy Reservoir", "last_updated": "2023-12-12"},
            {"city": "New York", "country": "United States", "region": "North America", "friendliness_score": 8.0, "water_quality_score": 8.7, "population": 8405837, "primary_water_source": "Catskill/Delaware Watersheds", "last_updated": "2023-11-18"},
            {"city": "Boston", "country": "United States", "region": "North America", "friendliness_score": 8.2, "water_quality_score": 8.8, "population": 695926, "primary_water_source": "Quabbin Reservoir", "last_updated": "2023-12-08"},
            {"city": "Chicago", "country": "United States", "region": "North America", "friendliness_score": 7.9, "water_quality_score": 8.5, "population": 2746388, "primary_water_source": "Lake Michigan", "last_updated": "2023-11-10"},
            
            # Asia-Pacific Cities
            {"city": "Auckland", "country": "New Zealand", "region": "Oceania", "friendliness_score": 9.3, "water_quality_score": 9.7, "population": 1657000, "primary_water_source": "Waitakere Ranges Reservoirs", "last_updated": "2023-12-18"},
            {"city": "Wellington", "country": "New Zealand", "region": "Oceania", "friendliness_score": 9.1, "water_quality_score": 9.6, "population": 412500, "primary_water_source": "Hutt River", "last_updated": "2023-11-22"},
            {"city": "Tokyo", "country": "Japan", "region": "Asia", "friendliness_score": 9.0, "water_quality_score": 9.3, "population": 13960000, "primary_water_source": "Tone River System", "last_updated": "2023-12-02"},
            {"city": "Melbourne", "country": "Australia", "region": "Oceania", "friendliness_score": 8.9, "water_quality_score": 9.5, "population": 5078193, "primary_water_source": "Thomson River Reservoir", "last_updated": "2023-11-28"},
            {"city": "Sydney", "country": "Australia", "region": "Oceania", "friendliness_score": 8.8, "water_quality_score": 9.4, "population": 5312163, "primary_water_source": "Warragamba Dam", "last_updated": "2023-12-14"},
            {"city": "Brisbane", "country": "Australia", "region": "Oceania", "friendliness_score": 8.7, "water_quality_score": 9.2, "population": 2560720, "primary_water_source": "Somerset Dam", "last_updated": "2023-11-20"},
            {"city": "Seoul", "country": "South Korea", "region": "Asia", "friendliness_score": 8.5, "water_quality_score": 8.8, "population": 9776000, "primary_water_source": "Han River", "last_updated": "2023-12-10"},
            {"city": "Singapore", "country": "Singapore", "region": "Asia", "friendliness_score": 8.8, "water_quality_score": 9.3, "population": 5686000, "primary_water_source": "NEWater & Reservoirs", "last_updated": "2023-11-15"},
            {"city": "Kyoto", "country": "Japan", "region": "Asia", "friendliness_score": 8.9, "water_quality_score": 9.2, "population": 1475000, "primary_water_source": "Lake Biwa", "last_updated": "2023-12-05"},
            {"city": "Taipei", "country": "Taiwan", "region": "Asia", "friendliness_score": 8.6, "water_quality_score": 8.9, "population": 2646204, "primary_water_source": "Feitsui Reservoir", "last_updated": "2023-11-25"},
            
            # South American Cities
            {"city": "Montevideo", "country": "Uruguay", "region": "South America", "friendliness_score": 8.5, "water_quality_score": 8.8, "population": 1381000, "primary_water_source": "Santa Lucia River", "last_updated": "2023-12-12"},
            {"city": "Santiago", "country": "Chile", "region": "South America", "friendliness_score": 8.3, "water_quality_score": 8.7, "population": 6257516, "primary_water_source": "Maipo River", "last_updated": "2023-11-18"},
            {"city": "Buenos Aires", "country": "Argentina", "region": "South America", "friendliness_score": 8.2, "water_quality_score": 8.5, "population": 3075646, "primary_water_source": "Rio de la Plata", "last_updated": "2023-12-08"},
            {"city": "Curitiba", "country": "Brazil", "region": "South America", "friendliness_score": 8.4, "water_quality_score": 8.6, "population": 1948626, "primary_water_source": "Iguazu River", "last_updated": "2023-11-10"},
            {"city": "Quito", "country": "Ecuador", "region": "South America", "friendliness_score": 8.0, "water_quality_score": 8.3, "population": 2011388, "primary_water_source": "Andean Rivers", "last_updated": "2023-12-18"},
            
            # African Cities
            {"city": "Cape Town", "country": "South Africa", "region": "Africa", "friendliness_score": 8.2, "water_quality_score": 8.5, "population": 4618000, "primary_water_source": "Theewaterskloof Dam", "last_updated": "2023-11-22"},
            {"city": "Windhoek", "country": "Namibia", "region": "Africa", "friendliness_score": 8.0, "water_quality_score": 8.2, "population": 431000, "primary_water_source": "Recycled Water & Dams", "last_updated": "2023-12-02"},
            {"city": "Gaborone", "country": "Botswana", "region": "Africa", "friendliness_score": 7.9, "water_quality_score": 8.0, "population": 231592, "primary_water_source": "Gaborone Dam", "last_updated": "2023-11-28"},
            {"city": "Kigali", "country": "Rwanda", "region": "Africa", "friendliness_score": 7.8, "water_quality_score": 7.9, "population": 1132686, "primary_water_source": "Nyabarongo River", "last_updated": "2023-12-14"},
            
            # Middle Eastern Cities
            {"city": "Muscat", "country": "Oman", "region": "Asia", "friendliness_score": 8.1, "water_quality_score": 8.4, "population": 1720000, "primary_water_source": "Desalination Plants", "last_updated": "2023-11-20"},
            {"city": "Dubai", "country": "United Arab Emirates", "region": "Asia", "friendliness_score": 8.2, "water_quality_score": 8.3, "population": 3331420, "primary_water_source": "Desalination Plants", "last_updated": "2023-12-10"},
            {"city": "Tel Aviv", "country": "Israel", "region": "Asia", "friendliness_score": 8.0, "water_quality_score": 8.3, "population": 451523, "primary_water_source": "Desalination & Sea of Galilee", "last_updated": "2023-11-15"},
            
            # Cities with Lower Water Quality Scores
            {"city": "New Delhi", "country": "India", "region": "Asia", "friendliness_score": 6.5, "water_quality_score": 5.8, "population": 21750000, "primary_water_source": "Yamuna River", "last_updated": "2023-12-05"},
            {"city": "Mexico City", "country": "Mexico", "region": "North America", "friendliness_score": 7.2, "water_quality_score": 6.5, "population": 9100000, "primary_water_source": "Groundwater & Cutzamala System", "last_updated": "2023-11-25"},
            {"city": "Jakarta", "country": "Indonesia", "region": "Asia", "friendliness_score": 6.8, "water_quality_score": 5.5, "population": 10770487, "primary_water_source": "Cisadane & Citarum Rivers", "last_updated": "2023-12-12"},
            {"city": "Cairo", "country": "Egypt", "region": "Africa", "friendliness_score": 6.7, "water_quality_score": 6.2, "population": 9540000, "primary_water_source": "Nile River", "last_updated": "2023-11-18"},
            {"city": "Lagos", "country": "Nigeria", "region": "Africa", "friendliness_score": 6.3, "water_quality_score": 5.0, "population": 14368000, "primary_water_source": "Ogun & Owo Rivers", "last_updated": "2023-12-08"},
            {"city": "Karachi", "country": "Pakistan", "region": "Asia", "friendliness_score": 6.0, "water_quality_score": 4.8, "population": 16459472, "primary_water_source": "Indus River & Hub Dam", "last_updated": "2023-11-10"},
            {"city": "Dhaka", "country": "Bangladesh", "region": "Asia", "friendliness_score": 5.9, "water_quality_score": 4.5, "population": 8906039, "primary_water_source": "Buriganga River & Groundwater", "last_updated": "2023-12-18"},
            {"city": "Manila", "country": "Philippines", "region": "Asia", "friendliness_score": 6.5, "water_quality_score": 5.2, "population": 1780148, "primary_water_source": "Angat Dam", "last_updated": "2023-11-22"},
        ]
        
        # Create DataFrame from cities data
        df = pd.DataFrame(cities)
        
        return df
    except Exception as e:
        print(f"Error loading city rankings data: {e}")
        # Return empty dataframe with correct structure
        df = pd.DataFrame({
            "city": [],
            "country": [],
            "region": [],
            "friendliness_score": [],
            "water_quality_score": [],
            "population": [],
            "primary_water_source": [],
            "last_updated": []
        })
        
        return df

def get_water_source_details(source_id):
    """
    Get detailed information about a specific water source
    """
    try:
        # This would be a real API endpoint in production
        # api_key = os.getenv("WATER_DATA_API_KEY", "")
        # api_url = f"https://api.example.com/water-sources/{source_id}"
        # response = requests.get(api_url, params={"api_key": api_key})
        # data = response.json()
        
        # Return a placeholder empty dictionary
        return {}
    except Exception as e:
        print(f"Error fetching water source details: {e}")
        return {}

def get_city_details(city_id):
    """
    Get detailed information about a specific city
    """
    try:
        # This would be a real API endpoint in production
        # api_key = os.getenv("CITY_DATA_API_KEY", "")
        # api_url = f"https://api.example.com/cities/{city_id}"
        # response = requests.get(api_url, params={"api_key": api_key})
        # data = response.json()
        
        # Return a placeholder empty dictionary
        return {}
    except Exception as e:
        print(f"Error fetching city details: {e}")
        return {}

def get_pollution_alerts():
    """
    Get current pollution alerts from the monitoring system
    """
    try:
        # This would be a real API endpoint in production
        # api_key = os.getenv("ALERTS_API_KEY", "")
        # api_url = "https://api.example.com/pollution-alerts"
        # response = requests.get(api_url, params={"api_key": api_key})
        # data = response.json()
        
        # Return a placeholder empty list
        return []
    except Exception as e:
        print(f"Error fetching pollution alerts: {e}")
        return []

def format_timestamp(timestamp):
    """Format a timestamp for display"""
    try:
        dt = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
        return dt.strftime('%Y-%m-%d %H:%M')
    except:
        return timestamp

def filter_data_by_region(df, region):
    """Filter dataframe by region"""
    if region == "All":
        return df
    return df[df["region"] == region]

def filter_data_by_water_type(df, water_type):
    """Filter dataframe by water type"""
    if water_type == "All":
        return df
    return df[df["type"] == water_type.lower()]

def filter_data_by_pollution_level(df, min_level, max_level=10):
    """Filter dataframe by pollution level range"""
    return df[(df["pollution_level"] >= min_level) & (df["pollution_level"] <= max_level)]

def search_data(df, query):
    """Search dataframe for records matching query"""
    query = query.lower()
    return df[
        df["name"].str.lower().str.contains(query) | 
        df["country"].str.lower().str.contains(query) |
        df["region"].str.lower().str.contains(query)
    ]
