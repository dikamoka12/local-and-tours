import os
import streamlit as st
from twilio.rest import Client
from datetime import datetime
import logging

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def send_sms_alert(to_phone_number, message):
    """
    Send SMS notification using Twilio
    
    Args:
        to_phone_number: Recipient's phone number (format: +country_code_number)
        message: SMS message content
    
    Returns:
        tuple: (success boolean, message string)
    """
    # Get Twilio credentials from environment variables
    account_sid = os.environ.get('TWILIO_ACCOUNT_SID')
    auth_token = os.environ.get('TWILIO_AUTH_TOKEN')
    from_phone_number = os.environ.get('TWILIO_PHONE_NUMBER')
    
    # Check if credentials are available
    if not all([account_sid, auth_token, from_phone_number]):
        error_msg = "Twilio credentials not found in environment variables"
        logger.error(error_msg)
        return False, error_msg
    
    # Validate recipient phone number (basic check)
    if not to_phone_number or not to_phone_number.startswith('+'):
        error_msg = "Invalid phone number format. Must include country code (e.g., +27...)"
        logger.error(error_msg)
        return False, error_msg
    
    try:
        # Initialize Twilio client
        client = Client(account_sid, auth_token)
        
        # Send message
        twilio_message = client.messages.create(
            body=message,
            from_=from_phone_number,
            to=to_phone_number
        )
        
        logger.info(f"SMS sent successfully. SID: {twilio_message.sid}")
        return True, f"SMS sent successfully to {to_phone_number}"
        
    except Exception as e:
        error_msg = f"Failed to send SMS: {str(e)}"
        logger.error(error_msg)
        return False, error_msg

def send_water_quality_alert(to_phone_number, water_source, pollution_level, location):
    """
    Send a formatted water quality alert
    
    Args:
        to_phone_number: Recipient's phone number
        water_source: Name of the water source
        pollution_level: Pollution level (1-10)
        location: Location of the water source
    
    Returns:
        tuple: (success boolean, message string)
    """
    # Format the alert message
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")
    
    # Determine alert severity
    if pollution_level >= 8:
        severity = "CRITICAL"
    elif pollution_level >= 6:
        severity = "HIGH"
    else:
        severity = "MODERATE"
    
    message = (
        f"⚠️ WATER QUALITY ALERT - {severity}\n\n"
        f"Source: {water_source}\n"
        f"Location: {location}\n"
        f"Pollution Level: {pollution_level}/10\n"
        f"Time: {timestamp}\n\n"
        f"Please avoid using this water source until further notice. "
        f"See South African Water Systems Monitor for details."
    )
    
    return send_sms_alert(to_phone_number, message)

def register_notification_preferences(username, phone, regions=None, min_level=7, 
                                     notification_methods=None):
    """
    Register a user's notification preferences
    
    Args:
        username: User's username
        phone: User's phone number
        regions: List of regions to monitor
        min_level: Minimum pollution level to trigger notifications
        notification_methods: List of notification methods ('sms', 'email')
        
    Returns:
        tuple: (success boolean, message string)
    """
    # Set defaults
    if regions is None:
        regions = ["All"]
    
    if notification_methods is None:
        notification_methods = ["sms"]
    
    # Validate phone number if SMS notifications are requested
    if "sms" in notification_methods and (not phone or not phone.startswith('+')):
        return False, "Valid phone number with country code required for SMS notifications"
    
    # Store preferences in session state for now (in a real app, would save to database)
    if 'notification_preferences' not in st.session_state:
        st.session_state.notification_preferences = {}
    
    st.session_state.notification_preferences[username] = {
        'phone': phone,
        'regions': regions,
        'min_level': min_level,
        'methods': notification_methods,
        'last_updated': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    
    return True, "Notification preferences saved successfully"

def should_notify_user(username, water_source_data):
    """
    Determine if a user should be notified about a water source
    
    Args:
        username: Username to check
        water_source_data: Dictionary with water source data
        
    Returns:
        boolean: True if user should be notified, False otherwise
    """
    if 'notification_preferences' not in st.session_state:
        return False
    
    if username not in st.session_state.notification_preferences:
        return False
    
    prefs = st.session_state.notification_preferences[username]
    
    # Check if pollution level meets threshold
    if water_source_data['pollution_level'] < prefs['min_level']:
        return False
    
    # Check if region matches user preferences
    if "All" not in prefs['regions'] and water_source_data['region'] not in prefs['regions']:
        return False
    
    return True

def send_user_notification(username, water_source_data):
    """
    Send notification to a user about a water source
    
    Args:
        username: Username to notify
        water_source_data: Dictionary with water source data
        
    Returns:
        tuple: (success boolean, message string)
    """
    if not should_notify_user(username, water_source_data):
        return False, "User does not need to be notified"
    
    prefs = st.session_state.notification_preferences[username]
    results = []
    
    # Send SMS if configured
    if 'sms' in prefs['methods'] and prefs['phone']:
        success, message = send_water_quality_alert(
            prefs['phone'],
            water_source_data['name'],
            water_source_data['pollution_level'],
            f"{water_source_data['country']}, {water_source_data['region']}"
        )
        results.append(f"SMS: {'Success' if success else 'Failed - ' + message}")
    
    # Send email if configured (placeholder for future implementation)
    if 'email' in prefs['methods']:
        # Email notification would be implemented here
        results.append("Email: Not implemented yet")
    
    return True, "; ".join(results)

def notify_users_about_water_source(water_source_data):
    """
    Notify all eligible users about a water source
    
    Args:
        water_source_data: Dictionary with water source data
        
    Returns:
        tuple: (success boolean, message string)
    """
    if 'notification_preferences' not in st.session_state:
        return False, "No notification preferences found"
    
    results = []
    for username, prefs in st.session_state.notification_preferences.items():
        if should_notify_user(username, water_source_data):
            success, message = send_user_notification(username, water_source_data)
            results.append(f"{username}: {message}")
    
    if not results:
        return False, "No eligible users found for notifications"
    
    return True, "; ".join(results)