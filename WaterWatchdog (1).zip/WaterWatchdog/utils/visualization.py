import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import pydeck as pdk
import streamlit as st
import altair as alt
import json
import os
from datetime import datetime

def create_map_visualization(df, column_color="pollution_level"):
    """
    Create a map visualization of water sources
    
    Args:
        df: DataFrame containing water source data
        column_color: Column to use for color-coding points
    
    Returns:
        PyDeck map layer
    """
    if len(df) == 0:
        # If dataframe is empty, return an empty map centered on world view
        return pdk.Deck(
            map_style="mapbox://styles/mapbox/light-v9",
            initial_view_state=pdk.ViewState(
                latitude=20,
                longitude=0,
                zoom=1,
                pitch=0,
            )
        )
    
    # Create PyDeck scatterplot layer
    layer = pdk.Layer(
        "ScatterplotLayer",
        df,
        get_position=["longitude", "latitude"],
        get_color=[
            f"255 * ({column_color} < 3 ? 0 : ({column_color} < 7 ? ({column_color} - 3) / 4 : 1))",
            f"255 * ({column_color} < 7 ? 1 : (10 - {column_color}) / 3)",
            "0",
            "180"
        ],
        get_radius=25000,  # Size in meters
        pickable=True,
        auto_highlight=True,
    )
    
    # Calculate view state based on data
    center_lat = df["latitude"].mean()
    center_lon = df["longitude"].mean()
    
    # Create tooltip
    tooltip = {
        "html": "<b>{name}</b><br>"
                "Type: {type}<br>"
                "Country: {country}<br>"
                "Pollution Level: {pollution_level}/10",
        "style": {
            "backgroundColor": "steelblue",
            "color": "white"
        }
    }
    
    # Return the deck
    return pdk.Deck(
        map_style="mapbox://styles/mapbox/light-v9",
        layers=[layer],
        initial_view_state=pdk.ViewState(
            latitude=center_lat,
            longitude=center_lon,
            zoom=1.5,
            pitch=0,
        ),
        tooltip=tooltip
    )

def create_pollution_chart(df):
    """
    Create a chart showing pollution levels by water type
    
    Args:
        df: DataFrame containing water source data
    
    Returns:
        Plotly figure
    """
    if len(df) == 0:
        # Return empty figure with message
        fig = go.Figure()
        fig.add_annotation(
            text="No data available",
            xref="paper",
            yref="paper",
            x=0.5,
            y=0.5,
            showarrow=False
        )
        return fig
    
    # Aggregate data by water type
    agg_df = df.groupby("type").agg(
        avg_pollution=("pollution_level", "mean"),
        count=("name", "count")
    ).reset_index()
    
    # Create bar chart
    fig = px.bar(
        agg_df,
        x="type",
        y="avg_pollution",
        color="avg_pollution",
        color_continuous_scale=["green", "yellow", "red"],
        labels={
            "type": "Water Type",
            "avg_pollution": "Average Pollution Level (0-10)",
            "count": "Number of Sources"
        },
        title="Average Pollution Level by Water Type",
        text="count"
    )
    
    fig.update_traces(texttemplate="%{text}", textposition="outside")
    fig.update_layout(uniformtext_minsize=8, uniformtext_mode='hide')
    
    return fig

def create_city_rankings_chart(df, top_n=20):
    """
    Create a chart showing top cities by friendliness score
    
    Args:
        df: DataFrame containing city rankings data
        top_n: Number of top cities to display
    
    Returns:
        Plotly figure
    """
    if len(df) == 0:
        # Return empty figure with message
        fig = go.Figure()
        fig.add_annotation(
            text="No data available",
            xref="paper",
            yref="paper",
            x=0.5,
            y=0.5,
            showarrow=False
        )
        return fig
    
    # Sort and get top N cities
    top_cities = df.sort_values("friendliness_score", ascending=False).head(top_n)
    
    # Create bar chart
    fig = px.bar(
        top_cities,
        x="city",
        y="friendliness_score",
        color="water_quality_score",
        color_continuous_scale=px.colors.sequential.Blues,
        labels={
            "city": "City",
            "friendliness_score": "Friendliness Score (0-10)",
            "water_quality_score": "Water Quality Score (0-10)"
        },
        title=f"Top {top_n} Friendliest Cities",
        hover_data=["country", "region", "primary_water_source"]
    )
    
    fig.update_layout(xaxis={'categoryorder':'total descending'})
    
    return fig

def create_correlation_chart(df):
    """
    Create a scatter plot showing correlation between water quality and city friendliness
    
    Args:
        df: DataFrame containing city rankings data
    
    Returns:
        Plotly figure
    """
    if len(df) == 0:
        # Return empty figure with message
        fig = go.Figure()
        fig.add_annotation(
            text="No data available",
            xref="paper",
            yref="paper",
            x=0.5,
            y=0.5,
            showarrow=False
        )
        return fig
    
    # Create scatter plot
    fig = px.scatter(
        df,
        x="water_quality_score",
        y="friendliness_score",
        color="region",
        size="population",
        hover_name="city",
        hover_data=["country", "primary_water_source"],
        title="Correlation: Water Quality vs. City Friendliness",
        labels={
            "water_quality_score": "Water Quality Score (0-10)",
            "friendliness_score": "Friendliness Score (0-10)",
            "region": "Region",
            "population": "Population"
        },
        size_max=30
    )
    
    # Add trendline
    fig.update_layout(
        shapes=[
            {
                'type': 'line',
                'x0': min(df["water_quality_score"]),
                'y0': min(df["water_quality_score"]) * (df["friendliness_score"] / df["water_quality_score"]).mean(),
                'x1': max(df["water_quality_score"]),
                'y1': max(df["water_quality_score"]) * (df["friendliness_score"] / df["water_quality_score"]).mean(),
                'line': {
                    'color': 'rgba(0,0,0,0.3)',
                    'width': 2,
                    'dash': 'dash',
                }
            }
        ]
    )
    
    return fig

def create_pollution_trend_chart(history_data):
    """
    Create a line chart showing pollution trend over time
    
    Args:
        history_data: List of dictionaries with pollution history data
    
    Returns:
        Plotly figure
    """
    if not history_data or len(history_data) == 0:
        # Return empty figure with message
        fig = go.Figure()
        fig.add_annotation(
            text="No historical data available",
            xref="paper",
            yref="paper",
            x=0.5,
            y=0.5,
            showarrow=False
        )
        return fig
    
    # Convert to DataFrame
    df = pd.DataFrame(history_data)
    
    # Create line chart
    fig = px.line(
        df,
        x="date",
        y="level",
        title="Pollution Level History",
        labels={
            "date": "Date",
            "level": "Pollution Level (0-10)"
        }
    )
    
    # Add safe threshold line
    fig.add_hline(
        y=7,
        line_dash="dash",
        line_color="red",
        annotation_text="Danger Threshold",
        annotation_position="bottom right"
    )
    
    fig.add_hline(
        y=3,
        line_dash="dash",
        line_color="green",
        annotation_text="Safe Level",
        annotation_position="bottom right"
    )
    
    return fig

def create_water_distribution_chart(df):
    """
    Create a pie chart showing distribution of water source types
    
    Args:
        df: DataFrame containing water source data
    
    Returns:
        Plotly figure
    """
    if len(df) == 0:
        # Return empty figure with message
        fig = go.Figure()
        fig.add_annotation(
            text="No data available",
            xref="paper",
            yref="paper",
            x=0.5,
            y=0.5,
            showarrow=False
        )
        return fig
    
    # Aggregate data by water type
    type_counts = df["type"].value_counts().reset_index()
    type_counts.columns = ["type", "count"]
    
    # Create pie chart
    fig = px.pie(
        type_counts,
        values="count",
        names="type",
        title="Distribution of Water Source Types",
        hole=0.4,
        color_discrete_sequence=px.colors.qualitative.Set3
    )
    
    return fig


def create_interactive_community_map(df=None, enable_reporting=False, show_community=True,
                               region=None, water_type=None, min_pollution_level=None, status=None):
    """
    Create an interactive map for community reporting of water quality issues with filtering options
    
    Args:
        df: DataFrame containing existing water source data
        enable_reporting: Whether to enable reporting mode for users to add new water sources
        show_community: Whether to show community reports
        region: Filter community reports by region
        water_type: Filter community reports by water type
        min_pollution_level: Filter reports by minimum pollution level
        status: Filter community reports by status (verified, pending, rejected)
    
    Returns:
        PyDeck map with filtered data
    """
    # Initialize community reports file if it doesn't exist
    community_reports_file = "community_reports.json"
    if not os.path.exists(community_reports_file):
        with open(community_reports_file, 'w') as f:
            json.dump([], f)
    
    # Load existing community reports
    try:
        with open(community_reports_file, 'r') as f:
            community_reports = json.load(f)
    except:
        community_reports = []
    
    # Convert community reports to DataFrame
    if community_reports and show_community:
        community_df = pd.DataFrame(community_reports)
        
        # Apply filters to community data
        if region:
            community_df = community_df[community_df['region'].str.lower() == region.lower()]
            
        if water_type:
            community_df = community_df[community_df['type'].str.lower() == water_type.lower()]
            
        if min_pollution_level is not None:
            community_df = community_df[community_df['pollution_level'] >= min_pollution_level]
            
        if status:
            community_df = community_df[community_df['status'] == status]
        
        if not community_df.empty:
            community_df['source'] = 'community'
    elif show_community:
        community_df = pd.DataFrame(columns=['name', 'type', 'latitude', 'longitude', 
                                             'country', 'region', 'pollution_level', 
                                             'description', 'reported_by', 'reported_date', 'source',
                                             'status', 'report_id'])
    else:
        community_df = pd.DataFrame()  # Empty DataFrame if community reports are not to be shown
    
    # Combine with official data if provided
    if df is not None and not df.empty:
        # Add source column to distinguish official data
        df_with_source = df.copy()
        df_with_source['source'] = 'official'
        
        # Apply minimum pollution level filter to official data if specified
        if min_pollution_level is not None:
            df_with_source = df_with_source[df_with_source['pollution_level'] >= min_pollution_level]
        
        # Combine dataframes if community data should be shown
        if show_community and not community_df.empty:
            combined_df = pd.concat([df_with_source, community_df], ignore_index=True)
        else:
            combined_df = df_with_source
    else:
        # If no official data, use community data if available and to be shown
        if show_community and not community_df.empty:
            combined_df = community_df
        else:
            combined_df = pd.DataFrame()  # Empty DataFrame if no data to show
    
    # Create map
    if not combined_df.empty:
        # Create different layers for official and community data
        official_df = combined_df[combined_df['source'] == 'official'] if 'source' in combined_df.columns else pd.DataFrame()
        community_df = combined_df[combined_df['source'] == 'community'] if 'source' in combined_df.columns else pd.DataFrame()
        
        layers = []
        
        # Official data layer (green/yellow/red based on pollution level)
        if not official_df.empty:
            official_layer = pdk.Layer(
                "ScatterplotLayer",
                official_df,
                get_position=["longitude", "latitude"],
                get_color=[
                    f"255 * (pollution_level < 3 ? 0 : (pollution_level < 7 ? (pollution_level - 3) / 4 : 1))",
                    f"255 * (pollution_level < 7 ? 1 : (10 - pollution_level) / 3)",
                    "0",
                    "180"
                ],
                get_radius=25000,  # Size in meters
                pickable=True,
                auto_highlight=True,
            )
            layers.append(official_layer)
        
        # Community data layers with different colors based on status
        if not community_df.empty:
            # Verified reports (green-purple)
            verified_df = community_df[community_df['status'] == 'verified'] if 'status' in community_df.columns else pd.DataFrame()
            if not verified_df.empty:
                verified_layer = pdk.Layer(
                    "ScatterplotLayer",
                    verified_df,
                    get_position=["longitude", "latitude"],
                    get_color=[
                        f"100",  # Red component
                        f"150",  # Green component
                        f"200",  # Blue component
                        "220"    # Alpha (more opaque for verified)
                    ],
                    get_radius=20000,  # Size in meters
                    pickable=True,
                    auto_highlight=True,
                )
                layers.append(verified_layer)
            
            # Pending reports (purple)
            pending_df = community_df[community_df['status'] == 'pending'] if 'status' in community_df.columns else community_df
            if not pending_df.empty:
                pending_layer = pdk.Layer(
                    "ScatterplotLayer",
                    pending_df,
                    get_position=["longitude", "latitude"],
                    get_color=[
                        f"200",  # Red component
                        f"0",    # Green component
                        f"200",  # Blue component
                        "180"    # Alpha
                    ],
                    get_radius=15000,  # Size in meters
                    pickable=True,
                    auto_highlight=True,
                )
                layers.append(pending_layer)
            
            # Rejected reports (gray, smaller) - only shown if explicitly requested
            if status == 'rejected':
                rejected_df = community_df[community_df['status'] == 'rejected'] if 'status' in community_df.columns else pd.DataFrame()
                if not rejected_df.empty:
                    rejected_layer = pdk.Layer(
                        "ScatterplotLayer",
                        rejected_df,
                        get_position=["longitude", "latitude"],
                        get_color=[
                            f"150",  # Red component
                            f"150",  # Green component
                            f"150",  # Blue component
                            "120"    # Alpha (more transparent)
                        ],
                        get_radius=10000,  # Size in meters (smaller)
                        pickable=True,
                        auto_highlight=True,
                    )
                    layers.append(rejected_layer)
        
        # Calculate view state based on data
        center_lat = combined_df["latitude"].mean()
        center_lon = combined_df["longitude"].mean()
        
        # Create enhanced tooltip with more information
        tooltip = {
            "html": "<div style='background-color: #3B5998; color: white; padding: 10px; border-radius: 5px;'>"
                    "<h3 style='margin-top:0;'>{name}</h3>"
                    "<p><b>Type:</b> {type}<br>"
                    "<b>Location:</b> {region}, {country}<br>"
                    "<b>Pollution Level:</b> {pollution_level}/10<br>"
                    "<b>Source:</b> {source}" +
                    ("<br><b>Status:</b> {status}" if 'status' in combined_df.columns else "") +
                    ("<br><b>Reported by:</b> {reported_by}" if 'source' in combined_df.columns and 'reported_by' in combined_df.columns else "") +
                    ("<br><b>Date:</b> {reported_date}" if 'reported_date' in combined_df.columns else "") +
                    "</p></div>",
            "style": {
                "backgroundColor": "transparent",
                "color": "white"
            }
        }
        
        # Create the deck with layers
        map_view = pdk.Deck(
            map_style="mapbox://styles/mapbox/light-v9",
            layers=layers,
            initial_view_state=pdk.ViewState(
                latitude=center_lat,
                longitude=center_lon,
                zoom=1.5,
                pitch=0,
            ),
            tooltip=tooltip
        )
    else:
        # If no data, return an empty map centered on world view
        map_view = pdk.Deck(
            map_style="mapbox://styles/mapbox/light-v9",
            initial_view_state=pdk.ViewState(
                latitude=-29.0,  # South Africa
                longitude=24.0,
                zoom=4,
                pitch=0,
            )
        )
    
    # Return map view
    return map_view


def save_uploaded_image(uploaded_file, report_id):
    """
    Save an uploaded image file with a specific report ID
    
    Args:
        uploaded_file: The uploaded file object from st.file_uploader
        report_id: Unique ID for the report
    
    Returns:
        String path to the saved image or None if failed
    """
    if uploaded_file is None:
        return None
        
    # Create directory if it doesn't exist
    image_dir = "report_images"
    if not os.path.exists(image_dir):
        os.makedirs(image_dir)
    
    # Create safe filename
    file_ext = os.path.splitext(uploaded_file.name)[1].lower()
    safe_filename = f"{report_id}{file_ext}"
    file_path = os.path.join(image_dir, safe_filename)
    
    # Save the file
    try:
        with open(file_path, "wb") as f:
            f.write(uploaded_file.getbuffer())
        return file_path
    except Exception as e:
        st.error(f"Error saving image: {str(e)}")
        return None


def display_community_reporting_interface():
    """
    Display an enhanced interface for users to report water quality issues
    
    Returns:
        Boolean indicating whether a new report was submitted
    """
    st.subheader("Report Water Quality Issue")
    st.markdown("""
    Help monitor water quality by reporting issues you've observed in your community.
    Your reports create awareness and help identify potential pollution sources.
    """)
    
    # Community report form
    with st.form("community_report_form"):
        # Basic water source information
        name = st.text_input("Water Source Name", placeholder="e.g., Vaal River at Midvaal")
        
        col1, col2 = st.columns(2)
        with col1:
            water_type = st.selectbox(
                "Water Type",
                options=["Rivers", "Dams", "Oceans", "Tap Water", "Underground Water", "Spring Water", "Others"],
                format_func=lambda x: x
            )
        
        with col2:
            pollution_level = st.slider(
                "Observed Pollution Level (1-10)",
                min_value=1,
                max_value=10,
                value=5,
                help="1 = Very clean, 10 = Severely polluted"
            )
        
        # Location information
        st.subheader("Location Information")
        col1, col2 = st.columns(2)
        with col1:
            country = st.text_input("Country", value="South Africa")
            region = st.text_input("Region/Province", placeholder="e.g., Western Cape")
        
        with col2:
            latitude = st.number_input(
                "Latitude",
                min_value=-90.0,
                max_value=90.0,
                value=-29.0,
                format="%.6f",
                help="If you don't know the exact coordinates, you can estimate from a map"
            )
            longitude = st.number_input(
                "Longitude", 
                min_value=-180.0,
                max_value=180.0,
                value=24.0,
                format="%.6f"
            )
        
        # Specific pollution information
        st.subheader("Pollution Details")
        
        # Observable characteristics
        characteristics = st.multiselect(
            "Observable Characteristics (select all that apply):",
            options=[
                "Unusual Color/Appearance", 
                "Unusual Smell",
                "Floating Debris/Trash",
                "Oil/Chemical Sheen",
                "Dead Fish/Wildlife",
                "Algae/Plant Overgrowth",
                "Foam/Bubbles",
                "Murky/Cloudy Water",
                "Sediment/Silt",
                "Chemical Containers/Dumping"
            ]
        )
        
        # Potential pollutant sources
        pollution_source = st.multiselect(
            "Potential Source(s) of Pollution:",
            options=[
                "Industrial Discharge",
                "Municipal Sewage",
                "Agricultural Runoff",
                "Stormwater Runoff",
                "Mining Activity",
                "Residential Waste",
                "Shipping/Boating",
                "Construction",
                "Unknown"
            ]
        )
        
        # Suspected chemicals/pollutants
        suspected_chemicals = st.multiselect(
            "Suspected Chemicals/Pollutants (if known):",
            options=[
                "Heavy Metals (Lead, Mercury, etc.)",
                "Fertilizers/Nutrients",
                "Pesticides/Herbicides",
                "Petroleum Products",
                "Plastics/Microplastics",
                "Pharmaceuticals",
                "Sewage/Fecal Matter",
                "Industrial Chemicals",
                "Unknown"
            ]
        )
        
        # Description and reporter information
        st.subheader("Additional Information")
        description = st.text_area(
            "Describe the water quality issue in detail",
            placeholder="Provide details about what you observed, visible pollutants, smells, duration of issue, etc."
        )
        
        # Image upload
        st.subheader("Photo Evidence (Optional)")
        st.write("Photos help verify and document the pollution issue:")
        image_file = st.file_uploader(
            "Upload a photo of the pollution",
            type=["jpg", "jpeg", "png"],
            help="Max file size: 5MB"
        )
        
        # Optional image description if an image is uploaded
        if image_file:
            image_description = st.text_input(
                "Brief description of the photo",
                placeholder="e.g., Oil slick on river surface near bridge"
            )
        else:
            image_description = None
        
        # Your information
        st.subheader("Your Information")
        col1, col2 = st.columns(2)
        with col1:
            reporter_name = st.text_input(
                "Your Name (optional)",
                placeholder="e.g., John Doe"
            )
        with col2:
            reporter_contact = st.text_input(
                "Contact (optional)",
                placeholder="e.g., email or phone number"
            )
        
        # Privacy and notifications
        receive_updates = st.checkbox("I would like to receive updates on this report")
        
        # Submit button
        submitted = st.form_submit_button("Submit Water Quality Report")
        
        if submitted:
            if not name:
                st.error("Please provide a name for the water source.")
                return False
            
            # Initialize community reports file if it doesn't exist
            community_reports_file = "community_reports.json"
            if not os.path.exists(community_reports_file):
                with open(community_reports_file, 'w') as f:
                    json.dump([], f)
            
            # Load existing reports
            try:
                with open(community_reports_file, 'r') as f:
                    community_reports = json.load(f)
            except:
                community_reports = []
            
            # Generate a unique report ID
            report_id = f"rep_{datetime.now().strftime('%Y%m%d%H%M%S')}_{len(community_reports) + 1}"
            
            # Save uploaded image if any
            image_path = None
            if image_file:
                image_path = save_uploaded_image(image_file, report_id)
            
            # Create new report
            new_report = {
                'report_id': report_id,
                'name': name,
                'type': water_type.lower(),
                'pollution_level': pollution_level,
                'latitude': latitude,
                'longitude': longitude,
                'country': country,
                'region': region,
                'characteristics': characteristics,
                'pollution_source': pollution_source,
                'suspected_chemicals': suspected_chemicals,
                'description': description,
                'image_path': image_path,
                'image_description': image_description,
                'reported_by': reporter_name if reporter_name else "Anonymous",
                'reporter_contact': reporter_contact if reporter_contact else None,
                'receive_updates': receive_updates,
                'reported_date': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                'source': 'community',
                'status': 'pending',  # pending, verified, rejected
                'verified_by': None,
                'verification_date': None,
                'verification_notes': None
            }
            
            # Add to reports
            community_reports.append(new_report)
            
            # Save updated reports
            with open(community_reports_file, 'w') as f:
                json.dump(community_reports, f, indent=4)
            
            st.success("Thank you for your report! Your contribution helps monitor water quality.")
            st.success(f"Your report ID is: {report_id}. Please save this for future reference.")
            return True
    
    return False


def get_community_reports(region=None, report_type=None, min_pollution_level=None, status=None):
    """
    Get community reports with optional filtering
    
    Args:
        region (str, optional): Filter by region/province
        report_type (str, optional): Filter by water type
        min_pollution_level (int, optional): Filter by minimum pollution level
        status (str, optional): Filter by report status (pending, verified, rejected)
    
    Returns:
        List of community report dictionaries
    """
    community_reports_file = "community_reports.json"
    
    # Initialize file if it doesn't exist
    if not os.path.exists(community_reports_file):
        with open(community_reports_file, 'w') as f:
            json.dump([], f)
    
    # Load reports
    try:
        with open(community_reports_file, 'r') as f:
            community_reports = json.load(f)
            
        # Apply filters if specified
        filtered_reports = community_reports
        
        if region:
            filtered_reports = [r for r in filtered_reports if r.get('region', '').lower() == region.lower()]
            
        if report_type:
            filtered_reports = [r for r in filtered_reports if r.get('type', '').lower() == report_type.lower()]
            
        if min_pollution_level is not None:
            filtered_reports = [r for r in filtered_reports if r.get('pollution_level', 0) >= min_pollution_level]
            
        if status:
            filtered_reports = [r for r in filtered_reports if r.get('status', '').lower() == status.lower()]
            
        return filtered_reports
        
    except Exception as e:
        st.error(f"Error loading community reports: {str(e)}")
        return []


def display_report_details(report):
    """
    Display detailed information for a specific report
    
    Args:
        report: Dictionary containing report data
    """
    if not report:
        st.warning("No report data to display.")
        return
    
    # Create expandable section for report details
    with st.expander(f"{report['name']} - {report.get('reported_date', 'No date')}", expanded=True):
        # Create columns for main info and image
        col1, col2 = st.columns([7, 3])
        
        with col1:
            # Basic info
            st.markdown(f"**Report ID:** {report.get('report_id', 'N/A')}")
            st.markdown(f"**Water Type:** {report.get('type', 'N/A').title()}")
            st.markdown(f"**Location:** {report.get('region', 'N/A')}, {report.get('country', 'N/A')}")
            st.markdown(f"**Reported By:** {report.get('reported_by', 'Anonymous')}")
            st.markdown(f"**Pollution Level:** {report.get('pollution_level', 'N/A')}/10")
            st.markdown(f"**Status:** {report.get('status', 'pending').title()}")
            
            # Show coordinates as clickable link to map
            lat = report.get('latitude')
            lng = report.get('longitude')
            if lat and lng:
                map_url = f"https://www.google.com/maps/search/?api=1&query={lat},{lng}"
                st.markdown(f"**Coordinates:** [{lat}, {lng}]({map_url})")
            
            # Description
            if report.get('description'):
                st.subheader("Description")
                st.markdown(report['description'])
        
        with col2:
            # Show image if available
            image_path = report.get('image_path')
            if image_path and os.path.exists(image_path):
                try:
                    st.image(image_path, caption=report.get('image_description', 'Reported pollution'))
                except Exception as e:
                    st.error(f"Could not display image: {str(e)}")
        
        # Show detailed pollution information
        st.subheader("Pollution Details")
        
        # Characteristics (if available)
        if 'characteristics' in report and report['characteristics']:
            st.markdown("**Observable Characteristics:**")
            for char in report['characteristics']:
                st.markdown(f"- {char}")
        
        # Sources (if available)
        if 'pollution_source' in report and report['pollution_source']:
            st.markdown("**Potential Sources:**")
            for source in report['pollution_source']:
                st.markdown(f"- {source}")
        
        # Chemicals (if available)
        if 'suspected_chemicals' in report and report['suspected_chemicals']:
            st.markdown("**Suspected Chemicals/Pollutants:**")
            for chem in report['suspected_chemicals']:
                st.markdown(f"- {chem}")
        
        # Verification information if verified
        if report.get('status') == 'verified' and report.get('verification_date'):
            st.subheader("Verification Information")
            st.markdown(f"**Verified By:** {report.get('verified_by', 'Admin')}")
            st.markdown(f"**Verification Date:** {report.get('verification_date')}")
            if report.get('verification_notes'):
                st.markdown(f"**Notes:** {report['verification_notes']}")


def display_report_moderation_interface(reports=None):
    """
    Display an interface for moderating community reports
    
    Args:
        reports: List of report dictionaries to display for moderation
    """
    if not reports:
        reports = get_community_reports()
    
    if not reports:
        st.info("No reports to moderate.")
        return
    
    # Filter to show only pending reports by default
    pending_reports = [r for r in reports if r.get('status') == 'pending']
    
    st.subheader(f"Report Moderation ({len(pending_reports)} pending)")
    
    # Create tabs for different statuses
    mod_tab1, mod_tab2, mod_tab3 = st.tabs(["Pending", "Verified", "Rejected"])
    
    with mod_tab1:
        if not pending_reports:
            st.info("No pending reports to moderate.")
        else:
            for i, report in enumerate(pending_reports):
                st.markdown(f"### Report #{i+1}: {report['name']}")
                
                # Display report details
                display_report_details(report)
                
                # Moderation actions
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    if st.button(f"Verify Report #{i+1}", key=f"verify_{report.get('report_id', i)}"):
                        verify_report(report.get('report_id', ''), 'verified', 'Admin', 'Report verified by admin')
                        st.success("Report verified successfully!")
                        st.rerun()
                
                with col2:
                    if st.button(f"Reject Report #{i+1}", key=f"reject_{report.get('report_id', i)}"):
                        verify_report(report.get('report_id', ''), 'rejected', 'Admin', 'Report rejected by admin')
                        st.error("Report rejected.")
                        st.rerun()
                
                with col3:
                    if st.button(f"Delete Report #{i+1}", key=f"delete_{report.get('report_id', i)}"):
                        delete_report(report.get('report_id', ''))
                        st.warning("Report deleted.")
                        st.rerun()
                
                st.markdown("---")
    
    with mod_tab2:
        verified_reports = [r for r in reports if r.get('status') == 'verified']
        if not verified_reports:
            st.info("No verified reports to display.")
        else:
            for i, report in enumerate(verified_reports):
                st.markdown(f"### Report #{i+1}: {report['name']}")
                display_report_details(report)
                st.markdown("---")
    
    with mod_tab3:
        rejected_reports = [r for r in reports if r.get('status') == 'rejected']
        if not rejected_reports:
            st.info("No rejected reports to display.")
        else:
            for i, report in enumerate(rejected_reports):
                st.markdown(f"### Report #{i+1}: {report['name']}")
                display_report_details(report)
                st.markdown("---")


def verify_report(report_id, status, verified_by, notes=None):
    """
    Update the status of a report (verify or reject)
    
    Args:
        report_id: ID of the report to update
        status: New status ('verified' or 'rejected')
        verified_by: Name of the person verifying the report
        notes: Optional verification notes
    
    Returns:
        Boolean indicating success
    """
    if not report_id:
        return False
        
    community_reports_file = "community_reports.json"
    if not os.path.exists(community_reports_file):
        return False
    
    try:
        # Load all reports
        with open(community_reports_file, 'r') as f:
            reports = json.load(f)
        
        # Find and update the report
        for report in reports:
            if report.get('report_id') == report_id:
                report['status'] = status
                report['verified_by'] = verified_by
                report['verification_date'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                if notes:
                    report['verification_notes'] = notes
                break
        
        # Save updated reports
        with open(community_reports_file, 'w') as f:
            json.dump(reports, f, indent=4)
            
        return True
    
    except Exception as e:
        st.error(f"Error updating report: {str(e)}")
        return False


def delete_report(report_id):
    """
    Delete a report from the community reports
    
    Args:
        report_id: ID of the report to delete
    
    Returns:
        Boolean indicating success
    """
    if not report_id:
        return False
        
    community_reports_file = "community_reports.json"
    if not os.path.exists(community_reports_file):
        return False
    
    try:
        # Load all reports
        with open(community_reports_file, 'r') as f:
            reports = json.load(f)
        
        # Find and delete the report
        reports = [r for r in reports if r.get('report_id') != report_id]
        
        # Save updated reports
        with open(community_reports_file, 'w') as f:
            json.dump(reports, f, indent=4)
            
        return True
    
    except Exception as e:
        st.error(f"Error deleting report: {str(e)}")
        return False
