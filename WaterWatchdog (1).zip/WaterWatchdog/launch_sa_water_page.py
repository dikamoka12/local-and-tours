import streamlit as st
from pages.sa_water_systems import app

st.set_page_config(
    page_title="SA Water Systems",
    page_icon="💧",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Run the SA Water Systems app directly
app()