import streamlit as st
import pandas as pd
import plotly.express as px
import pydeck as pdk
from utils.data_processor import load_water_sources_data, load_city_rankings_data
from utils.visualization import create_map_visualization, create_pollution_chart
from utils.multilingual import init_translations, get_text, language_selector
from utils.offline_content import get_offline_package_download_link

st.set_page_config(
    page_title="Global Water Monitor",
    page_icon="💧",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Add common header and footer to all pages
def display_common_header():
    try:
        # Responsive header with CSS media queries
        header_css = """
        <style>
            .sa-header {
                text-align: center;
                color: #1E88E5;
                background-color: #E3F2FD;
                padding: 20px;
                border-radius: 10px;
                margin-bottom: 5px;
                font-size: 2.5rem;
            }
            .sa-subheader {
                text-align: center;
                color: #D81B60;
                background-color: #FCE4EC;
                padding: 15px;
                margin-top: 10px;
                border-radius: 10px;
                font-size: 1.8rem;
            }
            .traditional-knowledge {
                text-align: center;
                color: white;
                background-color: #006400;
                padding: 15px;
                margin-top: 10px;
                border-radius: 10px;
                font-size: 1.7rem;
                font-weight: bold;
            }
            .apartheid-message {
                text-align: center;
                color: white;
                background-color: #B22222;
                padding: 15px;
                margin-top: 10px;
                border-radius: 10px;
                font-size: 1.6rem;
                font-weight: bold;
            }
            /* Media query for mobile devices */
            @media (max-width: 768px) {
                .sa-header {
                    font-size: 1.8rem;
                    padding: 15px 10px;
                }
                .sa-subheader {
                    font-size: 1.3rem;
                    padding: 10px 5px;
                }
                .traditional-knowledge {
                    font-size: 1.3rem;
                    padding: 10px 5px;
                }
                .apartheid-message {
                    font-size: 1.2rem;
                    padding: 10px 5px;
                }
            }
            /* Media query for very small screens */
            @media (max-width: 480px) {
                .sa-header {
                    font-size: 1.4rem;
                    padding: 10px 5px;
                }
                .sa-subheader {
                    font-size: 1.1rem;
                    padding: 8px 4px;
                }
                .traditional-knowledge {
                    font-size: 1.1rem;
                    padding: 8px 4px;
                }
                .apartheid-message {
                    font-size: 1.0rem;
                    padding: 8px 4px;
                }
            }
            /* Debug info */
            .debug-info {
                background-color: #FFFFCC;
                color: #333;
                padding: 5px;
                border-radius: 5px;
                font-size: 0.8rem;
                margin-bottom: 5px;
            }
        </style>
        """
        
        # Apply the CSS
        st.markdown(header_css, unsafe_allow_html=True)
        
        # Add debug info if in debug mode
        if 'debug_mode' in st.session_state and st.session_state.debug_mode:
            st.markdown("""
            <div class="debug-info">
                DEBUG: Header rendering successfully.
            </div>
            """, unsafe_allow_html=True)
        
        # Display the Traditional Water Knowledge message at the very top
        st.markdown("<div class='traditional-knowledge'>Traditional Water Knowledge</div>", unsafe_allow_html=True)
        
        # Display the header with the CSS classes and translated content
        app_title = get_text("app_title").upper()
        app_subtitle = get_text("app_subtitle").upper()
        
        st.markdown(f"<div class='sa-header'>{app_title}</div>", unsafe_allow_html=True)
        st.markdown(f"<div class='sa-subheader'>{app_subtitle}</div>", unsafe_allow_html=True)
        
        # Removed the apartheid message from the header
    except Exception as e:
        st.error(f"Error in header: {str(e)}")
        st.markdown("### SOUTH AFRICAN WATER SYSTEMS")
        st.markdown("#### Monitoring and Information Portal")
        # Even in error case, show only the traditional knowledge message in the header
        st.markdown("<div style='background-color:#006400; padding:10px; border-radius:5px; margin-bottom:10px;'><h3 style='color:white; text-align:center;'>Traditional Water Knowledge</h3></div>", unsafe_allow_html=True)
    
def display_footer():
    # Responsive footer with CSS media queries
    footer_css = """
    <style>
        .sa-footer {
            text-align: center;
            color: #616161;
            padding: 20px;
            margin-top: 30px;
            border-top: 1px solid #e0e0e0;
        }
        .sa-footer-text {
            font-size: 1rem;
            margin-bottom: 5px;
        }
        .sa-emergency {
            font-size: 0.9rem;
            margin-top: 10px;
        }
        .traditional-footer-knowledge {
            text-align: center;
            color: white;
            background-color: #006400;
            padding: 15px;
            margin-top: 15px;
            margin-bottom: 15px;
            border-radius: 10px;
            font-size: 1.3rem;
            font-weight: bold;
        }
        .apartheid-footer-message {
            text-align: center;
            color: white;
            background-color: #B22222;
            padding: 15px;
            margin-top: 15px;
            margin-bottom: 15px;
            border-radius: 10px;
            font-size: 1.3rem;
            font-weight: bold;
        }
        /* Media query for mobile devices */
        @media (max-width: 768px) {
            .sa-footer {
                padding: 15px 10px;
            }
            .sa-footer-text {
                font-size: 0.9rem;
            }
            .sa-emergency {
                font-size: 0.8rem;
            }
            .traditional-footer-knowledge {
                font-size: 1.1rem;
                padding: 10px 5px;
            }
            .apartheid-footer-message {
                font-size: 1.1rem;
                padding: 10px 5px;
            }
        }
        /* Media query for downloading offline content */
        .offline-content-btn {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 15px;
            font-weight: bold;
            display: inline-block;
        }
        .offline-content-btn:hover {
            background-color: #45a049;
        }
    </style>
    """
    
    # Apply the CSS
    st.markdown(footer_css, unsafe_allow_html=True)
    
    # Display the traditional knowledge message before the footer
    st.markdown("<div class='traditional-footer-knowledge'>Traditional Water Knowledge</div>", unsafe_allow_html=True)
    
    # Display the apartheid message before the footer
    st.markdown("<div class='apartheid-footer-message'>Forced removals do catch up with the remover (apartheid)</div>", unsafe_allow_html=True)
    
    # Display the footer with the CSS classes and translated content
    copyright_text = get_text("copyright")
    emergency_contact = get_text("emergency_contact")
    
    # Generate the offline package download link
    offline_download_link = get_offline_package_download_link()
    
    footer_html = f"""
    <div class='sa-footer'>
        <div class='sa-footer-text'>{copyright_text}</div>
        <div class='sa-emergency'>{emergency_contact}</div>
        {offline_download_link}
    </div>
    """
    
    st.markdown(footer_html, unsafe_allow_html=True)

# Initialize session state
if 'selected_water_type' not in st.session_state:
    st.session_state.selected_water_type = "All"
if 'selected_region' not in st.session_state:
    st.session_state.selected_region = "All"
if 'search_query' not in st.session_state:
    st.session_state.search_query = ""

def main():
    # Add debug session state variable
    if 'debug_mode' not in st.session_state:
        st.session_state.debug_mode = True

    # Initialize translations
    init_translations()
    
    # Debug indicator at the very top
    if st.session_state.debug_mode:
        st.markdown("""
        <div style="background-color:yellow; padding:10px; border-radius:5px;">
            DEBUG MODE ACTIVE - Session state is working
        </div>
        """, unsafe_allow_html=True)
        
    # New sidebar header with direct styling
    st.sidebar.markdown("""
    <div style="background-color:#1E88E5; color:white; font-weight:bold; padding:10px; border-radius:5px; margin-bottom:15px; text-align:center;">
        NAVIGATION MENU
    </div>
    """, unsafe_allow_html=True)
    
    # Define main navigation categories
    category = st.sidebar.selectbox(
        "Select Category",
        ["Water Quality", "Pollution Information", "Community Features", "Resources & Tools", "Account"]
    )
    
    # Dynamic page selection based on category
    if category == "Water Quality":
        page = st.sidebar.radio(
            "Water Quality Pages",
            ["Home", "Water Sources", "City Rankings", "Pollution Alerts", "Global Pollution Map"],
            format_func=lambda x: get_text(x.lower().replace(" ", "_"))
        )
    elif category == "Pollution Information":
        page = st.sidebar.radio(
            "Pollution Information",
            ["Air Pollution", "Toxic Chemicals", "Pollution Database", "Country Analysis"],
            format_func=lambda x: get_text(x.lower().replace(" ", "_"))
        )
    elif category == "Community Features":
        page = st.sidebar.radio(
            "Community Features",
            ["Community Map", "Community Forum"],
            format_func=lambda x: get_text(x.lower().replace(" ", "_"))
        )
    elif category == "Resources & Tools":
        page = st.sidebar.radio(
            "Resources & Tools",
            ["Educational Resources", "SA Water Systems", "Beach Houses"],
            format_func=lambda x: get_text(x.lower().replace(" ", "_"))
        )
    # Live Monitoring section removed
    else:  # Account
        page = st.sidebar.radio(
            "Account",
            ["Login/Register", "Subscription"],
            format_func=lambda x: get_text(x.lower().replace(" ", "_"))
        )
    
    # Debug info in sidebar
    if st.session_state.debug_mode:
        st.sidebar.markdown("---")
        st.sidebar.markdown("### Debug Info")
        st.sidebar.markdown(f"Selected page: **{page}**")
        st.sidebar.markdown(f"Session state keys: {list(st.session_state.keys())}")
    
    # Language selector with direct styling
    st.sidebar.markdown("<hr style='margin: 15px 0px; border-color: #e0e0e0;'>", unsafe_allow_html=True)
    st.sidebar.markdown("""
    <div style="background-color:#4CAF50; color:white; font-weight:bold; padding:8px; border-radius:5px; margin:10px 0px; text-align:center;">
        LANGUAGE
    </div>
    """, unsafe_allow_html=True)
    language_selector()
    
    # Filters with direct styling
    st.sidebar.markdown("<hr style='margin: 15px 0px; border-color: #e0e0e0;'>", unsafe_allow_html=True)
    st.sidebar.markdown(f"""
    <div style="background-color:#FF9800; color:white; font-weight:bold; padding:8px; border-radius:5px; margin:10px 0px; text-align:center;">
        {get_text('filters').upper()}
    </div>
    """, unsafe_allow_html=True)
    water_types = ["All", "Rivers", "Dams", "Oceans", "Tap Water", "Underground Water", "Spring Water", "Others"]
    water_types_display = [get_text(w.lower().replace(" ", "_")) for w in water_types]
    display_to_actual = dict(zip(water_types_display, water_types))
    
    selected_type_display = st.sidebar.selectbox(
        get_text("water_type"),
        options=water_types_display
    )
    st.session_state.selected_water_type = display_to_actual[selected_type_display]
    
    regions = ["All", "North America", "South America", "Europe", "Africa", "Asia", "Oceania"]
    regions_display = [get_text(r.lower().replace(" ", "_")) for r in regions]
    regions_dict = dict(zip(regions_display, regions))
    
    selected_region_display = st.sidebar.selectbox(
        get_text("region"),
        options=regions_display
    )
    st.session_state.selected_region = regions_dict[selected_region_display]
    
    # Search section with direct styling
    st.sidebar.markdown("<hr style='margin: 15px 0px; border-color: #e0e0e0;'>", unsafe_allow_html=True)
    st.sidebar.markdown(f"""
    <div style="background-color:#F44336; color:white; font-weight:bold; padding:8px; border-radius:5px; margin:10px 0px; text-align:center;">
        {get_text('search').upper()}
    </div>
    """, unsafe_allow_html=True)
    st.session_state.search_query = st.sidebar.text_input(get_text("search_placeholder"))
    
    # Load data
    water_sources_df = load_water_sources_data()
    city_rankings_df = load_city_rankings_data()
    
    # Filter data based on selections
    filtered_water_df = filter_water_data(water_sources_df)
    
    # Display common header on every page
    display_common_header()
    
    # Main content
    if page == "Home":
        display_home_page(filtered_water_df, city_rankings_df)
    elif page == "Water Sources":
        st.title("Water Sources")
        display_water_sources_page(filtered_water_df)
    elif page == "City Rankings":
        st.title("City Friendliness Rankings")
        display_city_rankings_page(city_rankings_df)
    elif page == "Pollution Alerts":
        st.title("Pollution Alerts")
        display_pollution_alerts_page(filtered_water_df)
    elif page == "Global Pollution Map":
        st.title("Global Water Pollution Map")
        display_global_pollution_map(water_sources_df)
    elif page == "Country Analysis":
        st.title("Country Pollution Analysis")
        display_country_pollution_analysis(water_sources_df, city_rankings_df)
    elif page == "Pollution Database":
        # Import the pollution database page
        import pages.pollution_database as pollution_database
        pollution_database.app()
    elif page == "Toxic Chemicals":
        # Import the toxic chemicals page
        import pages.toxic_chemicals as toxic_chemicals
        toxic_chemicals.app()
    elif page == "Air Pollution":
        # Direct implementation in app.py instead of importing from pages
        try:
            st.title("Air Pollution Information")
            
            # Add South African Water Systems Header
            st.markdown("<div style='background-color:#1E3B70; padding:10px; border-radius:5px; margin-bottom:20px;'><h2 style='color:white; text-align:center;'>SOUTH AFRICAN WATER SYSTEMS - TOURISTS AND LOCALS</h2></div>", unsafe_allow_html=True)
            
            st.write("This page provides comprehensive information about air pollution causes and dangerous chemicals.")
            
            # Major Causes Section
            st.header("Major Causes of Air Pollution")
            
            st.markdown("""
            ### Primary Sources of Air Pollution:
            
            1. **Industrial Activities**
               - Manufacturing facilities
               - Power plants
               - Mining operations
               - Oil refineries
               - Chemical production
            
            2. **Transportation**
               - Vehicle emissions
               - Aircraft emissions
               - Marine vessels
               - Diesel engines
            
            3. **Agricultural Activities**
               - Livestock farming
               - Fertilizer application
               - Pesticide use
               - Agricultural waste burning
            
            4. **Residential Sources**
               - Household heating (wood, coal)
               - Cooking with solid fuels
               - Consumer products (paints, cleaners)
               - Residential waste burning
            
            5. **Natural Sources**
               - Volcanic eruptions
               - Dust storms
               - Forest fires
               - Biological decay
            """)
            
            # Harmful Chemicals Section
            st.header("Harmful Chemicals and Pollutants")
            
            st.markdown("""
            ### Most Dangerous Air Pollutants:
            
            #### Criteria Air Pollutants
            - **Particulate Matter (PM2.5 and PM10)** - Causes respiratory issues, cardiovascular problems
            - **Ground-level Ozone (O₃)** - Triggers asthma, reduces lung function
            - **Nitrogen Oxides (NOx)** - Causes respiratory inflammation, contributes to acid rain
            - **Sulfur Dioxide (SO₂)** - Irritates breathing, damages vegetation
            - **Carbon Monoxide (CO)** - Reduces oxygen delivery to body organs
            - **Lead (Pb)** - Damages nervous system, particularly in children
            
            #### Hazardous Air Pollutants
            - **Benzene** - Known carcinogen, causes blood disorders
            - **Formaldehyde** - Irritates respiratory system, classified as carcinogen
            - **Mercury** - Neurotoxic, developmental impacts
            - **Dioxins and Furans** - Highly toxic, linked to cancer
            - **Polycyclic Aromatic Hydrocarbons (PAHs)** - Several are carcinogenic
            """)
            
            # South Africa Focus
            st.header("Air Pollution in South Africa")
            
            st.markdown("""
            ### Key Challenges in South Africa:
            
            1. **Coal-Based Energy Production**
               - South Africa relies heavily on coal for electricity
               - Eskom power stations in the Highveld release significant pollutants
               - Mpumalanga province contains most coal-fired power plants
            
            2. **Mining Activity**
               - Mining operations release dust with heavy metals
               - Mine dumps create ongoing sources of windblown dust
               - Gold, platinum, and coal mining areas have higher pollution
            
            3. **Industrial Activities**
               - Petrochemical facilities (particularly in areas like Sasolburg)
               - Manufacturing and heavy industry in certain zones
            
            4. **Priority Areas with Poor Air Quality**
               - Vaal Triangle Airshed
               - Highveld Priority Area
               - Waterberg-Bojanala Priority Area
            """)
            
            # Health Effects
            st.header("Health Effects of Air Pollution")
            
            st.markdown("""
            ### Health Impacts:
            
            - **Respiratory System**: Asthma, COPD, reduced lung function, respiratory infections
            - **Cardiovascular System**: Heart attacks, stroke, arrhythmias, hypertension
            - **Nervous System**: Cognitive decline, developmental delays, neurodegenerative diseases
            - **Reproductive System**: Reduced fertility, pregnancy complications, low birth weight
            - **Other Systems**: Kidney damage, liver damage, eye irritation, skin disorders
            
            ### Vulnerable Populations:
            - Children
            - Elderly
            - Pregnant women
            - People with existing health conditions
            """)
            
            # Environmental Effects
            st.header("Environmental Impact")
            
            st.markdown("""
            ### Environmental Effects:
            
            - **Ecosystem Damage**: Acidification of lakes, nutrient imbalances, damage to forests
            - **Climate Change**: Global warming, altered precipitation, extreme weather
            - **Agricultural Impacts**: Reduced crop yields, damage to plant tissues
            - **Built Environment**: Deterioration of buildings, corrosion of metals
            - **Visibility Impairment**: Urban haze, reduced visibility in scenic areas
            """)
            
            # Connection to Water
            st.header("Connection to Water Systems")
            
            st.markdown("""
            ### How Air Pollution Affects Water:
            
            - **Acid Rain**: Sulfur dioxide and nitrogen oxides create acidic precipitation
            - **Atmospheric Deposition**: Pollutants settle directly into water bodies
            - **Nutrient Loading**: Nitrogen compounds can cause eutrophication
            - **Mercury Contamination**: Airborne mercury eventually enters the water system
            
            These connections highlight why air and water pollution must be addressed together.
            """)
            
            # Solutions
            st.header("Solutions and Mitigation Strategies")
            
            st.markdown("""
            ### Key Approaches to Reducing Air Pollution:
            
            #### Policy Measures
            - Emission standards for industries and vehicles
            - Air quality monitoring networks
            - Clean air legislation and enforcement
            
            #### Technological Solutions
            - Renewable energy (solar, wind, hydroelectric)
            - Energy efficiency improvements
            - Advanced emission control systems
            - Electric vehicles
            
            #### Individual Actions
            - Reducing energy consumption
            - Using public transportation
            - Properly maintaining vehicles
            - Avoiding burning waste
            - Using environmentally friendly products
            """)
            
            # References
            st.markdown("""
            ---
            ### References and Further Reading
            
            - World Health Organization (WHO) Air Quality Guidelines
            - United States Environmental Protection Agency (EPA) Air Quality resources
            - South African Air Quality Information System (SAAQIS)
            - The Lancet Commission on Pollution and Health
            - State of Global Air reports
            """)
            
            # Add footer
            st.markdown("<br><br>", unsafe_allow_html=True)
            st.markdown("<div style='background-color:#1E3B70; padding:10px; border-radius:5px; margin-top:20px;'><h3 style='color:white; text-align:center;'>SOUTH AFRICAN WATER SYSTEMS - TOURISTS AND LOCALS</h3></div>", unsafe_allow_html=True)
            
        except Exception as e:
            st.error(f"Error in Air Pollution page: {str(e)}")
    elif page == "Beach Houses":
        # Import the beach houses page
        import pages.beach_houses as beach_houses
        beach_houses.app()
    elif page == "SA Water Systems":
        # Import the South African water systems page
        import pages.sa_water_systems as sa_water_systems
        sa_water_systems.app()
    elif page == "Community Map":
        # Direct implementation in app.py instead of importing from pages
        try:
            st.title("Community Map")
            st.write("This is a simple community map page implemented directly in app.py")
            
            # Create basic tabs
            tab1, tab2 = st.tabs(["View Map", "Report Issue"])
            
            with tab1:
                st.write("Map would be displayed here")
                
            with tab2:
                st.write("Reporting form would be here")
                
        except Exception as e:
            st.error(f"Error in Community Map: {str(e)}")
    elif page == "Subscription":
        # Import the subscription page
        import pages.subscription as subscription
        subscription.app()
    elif page == "Community Forum":
        # Import the community forum page
        import pages.community_forum as community_forum
        community_forum.app()
    elif page == "Educational Resources":
        # Import the educational resources page
        import pages.educational_resources as educational_resources
        educational_resources.app()
    elif page == "Login/Register":
        # Import the login page
        import pages.login as login
        login.app()
    # MCP Dashboard page removed

def filter_water_data(df):
    """Filter water sources data based on sidebar selections"""
    filtered_df = df.copy()
    
    # Filter by water type
    if st.session_state.selected_water_type != "All":
        filtered_df = filtered_df[filtered_df["type"] == st.session_state.selected_water_type.lower()]
    
    # Filter by region
    if st.session_state.selected_region != "All":
        filtered_df = filtered_df[filtered_df["region"] == st.session_state.selected_region]
    
    # Filter by search query
    if st.session_state.search_query:
        search_lower = st.session_state.search_query.lower()
        filtered_df = filtered_df[
            filtered_df["name"].str.lower().str.contains(search_lower) | 
            filtered_df["country"].str.lower().str.contains(search_lower)
        ]
    
    return filtered_df

def display_home_page(water_df, city_df):
    st.title("Global Water Sources Monitor")
    st.subheader("Track water quality, pollution levels, and city friendliness worldwide")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("### Water Sources Map")
        st.write("Color intensity indicates pollution severity (Red = High pollution)")
        map_layer = create_map_visualization(water_df)
        st.pydeck_chart(map_layer)
    
    with col2:
        st.markdown("### Water Quality Overview")
        fig = create_pollution_chart(water_df)
        st.plotly_chart(fig, use_container_width=True)
    
    st.markdown("### Top 5 Friendliest Cities")
    top_cities = city_df.sort_values("friendliness_score", ascending=False).head(5)
    
    # Format the dataframe for display
    display_cities = top_cities[["city", "country", "friendliness_score", "water_quality_score"]]
    display_cities.columns = ["City", "Country", "Friendliness Score", "Water Quality Score"]
    st.table(display_cities)
    
    st.markdown("### Recent Pollution Alerts")
    alerts = water_df[water_df["pollution_level"] > 7].sort_values("last_updated", ascending=False).head(3)
    
    if len(alerts) > 0:
        for _, alert in alerts.iterrows():
            st.warning(f"⚠️ High pollution detected in {alert['name']}, {alert['country']}. Level: {alert['pollution_level']}/10")
    else:
        st.info("No high-level pollution alerts at this time.")

    # Add summary of most polluted water sources
    st.markdown("### Most Polluted Water Sources Worldwide")
    most_polluted = water_df.sort_values("pollution_level", ascending=False).head(10)
    fig = px.bar(
        most_polluted,
        x="name",
        y="pollution_level",
        color="pollution_level",
        color_continuous_scale=["yellow", "orange", "red"],
        labels={"name": "Water Source", "pollution_level": "Pollution Level", "country": "Country", "type": "Type"},
        hover_data=["country", "type", "ph_level"],
        title="Top 10 Most Polluted Water Sources"
    )
    fig.update_layout(xaxis={'categoryorder':'total descending'})
    st.plotly_chart(fig, use_container_width=True)
    
    # AIR POLLUTION SECTION ADDED DIRECTLY TO HOME PAGE
    st.markdown("---")
    st.title("Air Pollution Information")
    
    # Add South African Water Systems Header
    st.markdown("<div style='background-color:#1E3B70; padding:10px; border-radius:5px; margin-bottom:20px;'><h2 style='color:white; text-align:center;'>SOUTH AFRICAN WATER SYSTEMS - TOURISTS AND LOCALS</h2></div>", unsafe_allow_html=True)
    
    st.write("This section provides comprehensive information about air pollution causes and dangerous chemicals.")
    
    # Major Causes Section
    st.header("Major Causes of Air Pollution")
    
    st.markdown("""
    ### Primary Sources of Air Pollution:
    
    1. **Industrial Activities**
       - Manufacturing facilities
       - Power plants
       - Mining operations
       - Oil refineries
       - Chemical production
    
    2. **Transportation**
       - Vehicle emissions
       - Aircraft emissions
       - Marine vessels
       - Diesel engines
    
    3. **Agricultural Activities**
       - Livestock farming
       - Fertilizer application
       - Pesticide use
       - Agricultural waste burning
    
    4. **Residential Sources**
       - Household heating (wood, coal)
       - Cooking with solid fuels
       - Consumer products (paints, cleaners)
       - Residential waste burning
    
    5. **Natural Sources**
       - Volcanic eruptions
       - Dust storms
       - Forest fires
       - Biological decay
    """)
    
    # Harmful Chemicals Section
    st.header("Harmful Chemicals and Pollutants")
    
    st.markdown("""
    ### Most Dangerous Air Pollutants:
    
    #### Criteria Air Pollutants
    - **Particulate Matter (PM2.5 and PM10)** - Causes respiratory issues, cardiovascular problems
    - **Ground-level Ozone (O₃)** - Triggers asthma, reduces lung function
    - **Nitrogen Oxides (NOx)** - Causes respiratory inflammation, contributes to acid rain
    - **Sulfur Dioxide (SO₂)** - Irritates breathing, damages vegetation
    - **Carbon Monoxide (CO)** - Reduces oxygen delivery to body organs
    - **Lead (Pb)** - Damages nervous system, particularly in children
    
    #### Hazardous Air Pollutants
    - **Benzene** - Known carcinogen, causes blood disorders
    - **Formaldehyde** - Irritates respiratory system, classified as carcinogen
    - **Mercury** - Neurotoxic, developmental impacts
    - **Dioxins and Furans** - Highly toxic, linked to cancer
    - **Polycyclic Aromatic Hydrocarbons (PAHs)** - Several are carcinogenic
    """)
    
    # South Africa Focus
    st.header("Air Pollution in South Africa")
    
    st.markdown("""
    ### Key Challenges in South Africa:
    
    1. **Coal-Based Energy Production**
       - South Africa relies heavily on coal for electricity
       - Eskom power stations in the Highveld release significant pollutants
       - Mpumalanga province contains most coal-fired power plants
    
    2. **Mining Activity**
       - Mining operations release dust with heavy metals
       - Mine dumps create ongoing sources of windblown dust
       - Gold, platinum, and coal mining areas have higher pollution
    
    3. **Industrial Activities**
       - Petrochemical facilities (particularly in areas like Sasolburg)
       - Manufacturing and heavy industry in certain zones
    
    4. **Priority Areas with Poor Air Quality**
       - Vaal Triangle Airshed
       - Highveld Priority Area
       - Waterberg-Bojanala Priority Area
    """)
    
    # Health Effects
    st.header("Health Effects of Air Pollution")
    
    st.markdown("""
    ### Health Impacts:
    
    - **Respiratory System**: Asthma, COPD, reduced lung function, respiratory infections
    - **Cardiovascular System**: Heart attacks, stroke, arrhythmias, hypertension
    - **Nervous System**: Cognitive decline, developmental delays, neurodegenerative diseases
    - **Reproductive System**: Reduced fertility, pregnancy complications, low birth weight
    - **Other Systems**: Kidney damage, liver damage, eye irritation, skin disorders
    
    ### Vulnerable Populations:
    - Children
    - Elderly
    - Pregnant women
    - People with existing health conditions
    """)
    
    # Environmental Effects
    st.header("Environmental Impact of Air Pollution")
    
    st.markdown("""
    ### Environmental Effects:
    
    - **Ecosystem Damage**: Acidification of lakes, nutrient imbalances, damage to forests
    - **Climate Change**: Global warming, altered precipitation, extreme weather
    - **Agricultural Impacts**: Reduced crop yields, damage to plant tissues
    - **Built Environment**: Deterioration of buildings, corrosion of metals
    - **Visibility Impairment**: Urban haze, reduced visibility in scenic areas
    """)
    
    # Connection to Water
    st.header("Connection to Water Systems")
    
    st.markdown("""
    ### How Air Pollution Affects Water:
    
    - **Acid Rain**: Sulfur dioxide and nitrogen oxides create acidic precipitation
    - **Atmospheric Deposition**: Pollutants settle directly into water bodies
    - **Nutrient Loading**: Nitrogen compounds can cause eutrophication
    - **Mercury Contamination**: Airborne mercury eventually enters the water system
    
    These connections highlight why air and water pollution must be addressed together.
    """)
    
    # Solutions
    st.header("Solutions and Mitigation Strategies")
    
    st.markdown("""
    ### Key Approaches to Reducing Air Pollution:
    
    #### Policy Measures
    - Emission standards for industries and vehicles
    - Air quality monitoring networks
    - Clean air legislation and enforcement
    
    #### Technological Solutions
    - Renewable energy (solar, wind, hydroelectric)
    - Energy efficiency improvements
    - Advanced emission control systems
    - Electric vehicles
    
    #### Individual Actions
    - Reducing energy consumption
    - Using public transportation
    - Properly maintaining vehicles
    - Avoiding burning waste
    - Using environmentally friendly products
    """)
    
    # References
    st.markdown("""
    ---
    ### References and Further Reading
    
    - World Health Organization (WHO) Air Quality Guidelines
    - United States Environmental Protection Agency (EPA) Air Quality resources
    - South African Air Quality Information System (SAAQIS)
    - The Lancet Commission on Pollution and Health
    - State of Global Air reports
    """)
    
    # Add footer
    st.markdown("<br><br>", unsafe_allow_html=True)
    st.markdown("<div style='background-color:#1E3B70; padding:10px; border-radius:5px; margin-top:20px;'><h3 style='color:white; text-align:center;'>SOUTH AFRICAN WATER SYSTEMS - TOURISTS AND LOCALS</h3></div>", unsafe_allow_html=True)

def display_water_sources_page(df):
    st.write("Explore detailed information about water sources around the world.")
    
    col1, col2 = st.columns([3, 1])
    
    with col1:
        # Display map
        st.subheader("Water Sources Map")
        map_layer = create_map_visualization(df)
        st.pydeck_chart(map_layer)
    
    with col2:
        # Display statistics
        st.subheader("Statistics")
        st.metric("Total Water Sources", len(df))
        if len(df) > 0:
            st.metric("Average Pollution Level", f"{df['pollution_level'].mean():.1f}/10")
            highly_polluted = len(df[df['pollution_level'] >= 7])
            st.metric("Highly Polluted Sources", f"{highly_polluted} ({(highly_polluted/len(df)*100):.1f}%)")
        
        # Water types distribution
        st.subheader("Water Types Distribution")
        if len(df) > 0:
            type_counts = df['type'].value_counts()
            fig = px.pie(values=type_counts.values, names=type_counts.index, hole=0.4)
            st.plotly_chart(fig, use_container_width=True)
    
    # Detailed water sources table with pollution emphasis
    st.subheader("Water Sources Data")
    if len(df) > 0:
        # Sort options for pollution focus
        sort_option = st.selectbox(
            "Sort by",
            ["Pollution Level (High to Low)", "Pollution Level (Low to High)", "Name", "Country", "Water Type"]
        )
        
        if sort_option == "Pollution Level (High to Low)":
            df = df.sort_values("pollution_level", ascending=False)
        elif sort_option == "Pollution Level (Low to High)":
            df = df.sort_values("pollution_level", ascending=True)
        elif sort_option == "Name":
            df = df.sort_values("name")
        elif sort_option == "Country":
            df = df.sort_values("country")
        elif sort_option == "Water Type":
            df = df.sort_values("type")
        
        display_df = df[["name", "type", "country", "region", "pollution_level", "ph_level", "last_updated"]]
        display_df.columns = ["Name", "Type", "Country", "Region", "Pollution Level", "pH Level", "Last Updated"]
        
        # Apply styling to highlight pollution levels
        def highlight_pollution(val):
            if val >= 8:
                return 'background-color: #ffcccc'
            elif val >= 6:
                return 'background-color: #ffffcc'
            else:
                return ''
        
        # Apply styling to the dataframe (but streamlit doesn't support this advanced styling)
        # styled_df = display_df.style.applymap(highlight_pollution, subset=['Pollution Level'])
        st.dataframe(display_df, use_container_width=True)
    else:
        st.info("No water sources available for the selected filters.")
    
    # Water source details
    st.subheader("Water Source Details")
    if len(df) > 0:
        selected_source = st.selectbox("Select a water source for detailed information", df["name"].tolist())
        
        if selected_source:
            source_data = df[df["name"] == selected_source].iloc[0]
            
            # Create columns for layout
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown(f"**Name:** {source_data['name']}")
                st.markdown(f"**Type:** {source_data['type'].capitalize()}")
                st.markdown(f"**Country:** {source_data['country']}")
                st.markdown(f"**Region:** {source_data['region']}")
            
            with col2:
                # Show pollution level with visual indicator
                pollution_level = source_data['pollution_level']
                pollution_color = "green" if pollution_level < 4 else "orange" if pollution_level < 7 else "red"
                st.markdown(f"**Pollution Level:** <span style='color:{pollution_color};font-weight:bold;'>{pollution_level}/10</span>", unsafe_allow_html=True)
                
                # Interpret pollution level
                pollution_desc = "Safe" if pollution_level < 4 else "Moderate concern" if pollution_level < 7 else "High concern"
                st.markdown(f"**Pollution Status:** {pollution_desc}")
                
                st.markdown(f"**pH Level:** {source_data['ph_level']}")
                st.markdown(f"**Size/Length:** {source_data['size']}")
                st.markdown(f"**Last Updated:** {source_data['last_updated']}")
            
            # Show pollution trend if available
            if "pollution_history" in source_data and len(source_data["pollution_history"]) > 0:
                st.subheader("Pollution Trend")
                history_df = pd.DataFrame(source_data["pollution_history"])
                fig = px.line(
                    history_df, 
                    x="date", 
                    y="level", 
                    title=f"Pollution Level History - {selected_source}",
                    labels={"level": "Pollution Level", "date": "Date"}
                )
                
                # Add threshold lines
                fig.add_hline(
                    y=7,
                    line_dash="dash",
                    line_color="red",
                    annotation_text="High Pollution Threshold",
                    annotation_position="bottom right"
                )
                
                fig.add_hline(
                    y=4,
                    line_dash="dash",
                    line_color="orange",
                    annotation_text="Moderate Pollution Threshold",
                    annotation_position="bottom right"
                )
                
                st.plotly_chart(fig, use_container_width=True)
            
            # Add potential health impacts based on pollution level
            st.subheader("Potential Health and Environmental Impacts")
            if pollution_level >= 8:
                st.error("""
                **High Pollution Levels - Serious Concerns**
                - Water unsafe for human consumption without extensive treatment
                - May contain industrial chemicals, heavy metals, or biological contaminants
                - Serious risk to aquatic life and ecosystem health
                - Potential long-term impacts on local environment
                """)
            elif pollution_level >= 5:
                st.warning("""
                **Moderate Pollution Levels - Caution Advised**
                - Water may require significant treatment before consumption
                - May affect sensitive aquatic species
                - Potential for algal blooms or reduced biodiversity
                - Regular monitoring recommended
                """)
            else:
                st.success("""
                **Low Pollution Levels - Generally Safe**
                - Water likely safe for designated uses with standard treatment
                - Healthy ecosystem can be maintained
                - Supports diverse aquatic life
                - Continue regular monitoring to maintain quality
                """)
    else:
        st.info("No water sources available for the selected filters.")

def display_city_rankings_page(df):
    st.write("Discover which cities around the world are rated as most friendly, with data on their water quality.")
    
    # Top cities chart
    st.subheader("Top 20 Friendliest Cities")
    top_cities = df.sort_values("friendliness_score", ascending=False).head(20)
    
    fig = px.bar(
        top_cities, 
        x="city", 
        y="friendliness_score", 
        color="water_quality_score",
        hover_data=["country", "population", "primary_water_source"],
        color_continuous_scale=px.colors.sequential.Blues,
        labels={"friendliness_score": "Friendliness Score", "city": "City", "water_quality_score": "Water Quality Score"}
    )
    fig.update_layout(xaxis={'categoryorder':'total descending'})
    st.plotly_chart(fig, use_container_width=True)
    
    # Correlation analysis
    st.subheader("Correlation: Water Quality vs. City Friendliness")
    fig = px.scatter(
        df, 
        x="water_quality_score", 
        y="friendliness_score",
        hover_name="city",
        hover_data=["country", "population", "primary_water_source"],
        size="population",
        color="region",
        size_max=30,
        opacity=0.7
    )
    st.plotly_chart(fig, use_container_width=True)
    
    # Add water quality ranking
    st.subheader("Cities Ranked by Water Quality")
    water_quality_cities = df.sort_values("water_quality_score", ascending=False).head(10)
    fig = px.bar(
        water_quality_cities,
        x="city",
        y="water_quality_score",
        color="region",
        labels={"water_quality_score": "Water Quality Score", "city": "City"},
        hover_data=["country", "primary_water_source"],
        title="Top 10 Cities with Best Water Quality"
    )
    fig.update_layout(xaxis={'categoryorder':'total descending'})
    st.plotly_chart(fig, use_container_width=True)
    
    # Show cities with poor water quality
    st.subheader("Cities with Water Quality Concerns")
    poor_water_cities = df.sort_values("water_quality_score").head(10)
    fig = px.bar(
        poor_water_cities,
        x="city",
        y="water_quality_score",
        color="water_quality_score",
        color_continuous_scale=["red", "orange", "yellow"],
        labels={"water_quality_score": "Water Quality Score", "city": "City"},
        hover_data=["country", "primary_water_source"],
        title="10 Cities with Poorest Water Quality"
    )
    fig.update_layout(xaxis={'categoryorder':'total ascending'})
    st.plotly_chart(fig, use_container_width=True)
    
    # Full city rankings
    st.subheader("City Rankings Table")
    
    # Add search functionality
    search_city = st.text_input("Search for a city")
    
    filtered_df = df
    if search_city:
        filtered_df = df[df["city"].str.lower().str.contains(search_city.lower()) | 
                          df["country"].str.lower().str.contains(search_city.lower())]
    
    # Region filter
    regions = ["All"] + sorted(df["region"].unique().tolist())
    selected_region = st.selectbox("Filter by region", regions)
    
    if selected_region != "All":
        filtered_df = filtered_df[filtered_df["region"] == selected_region]
    
    # Add water quality filter
    min_water_quality, max_water_quality = st.slider(
        "Water Quality Score Range", 
        min_value=1.0, 
        max_value=10.0, 
        value=(1.0, 10.0),
        step=0.5
    )
    
    filtered_df = filtered_df[
        (filtered_df["water_quality_score"] >= min_water_quality) & 
        (filtered_df["water_quality_score"] <= max_water_quality)
    ]
    
    # Sort options
    sort_by = st.selectbox("Sort by", ["Friendliness (High to Low)", "Friendliness (Low to High)", 
                                      "Water Quality (High to Low)", "Water Quality (Low to High)"])
    
    if sort_by == "Friendliness (High to Low)":
        filtered_df = filtered_df.sort_values("friendliness_score", ascending=False)
    elif sort_by == "Friendliness (Low to High)":
        filtered_df = filtered_df.sort_values("friendliness_score", ascending=True)
    elif sort_by == "Water Quality (High to Low)":
        filtered_df = filtered_df.sort_values("water_quality_score", ascending=False)
    elif sort_by == "Water Quality (Low to High)":
        filtered_df = filtered_df.sort_values("water_quality_score", ascending=True)
    
    # Display the table
    display_df = filtered_df[["city", "country", "region", "friendliness_score", "water_quality_score", "population", "primary_water_source"]]
    display_df.columns = ["City", "Country", "Region", "Friendliness Score", "Water Quality Score", "Population", "Primary Water Source"]
    st.dataframe(display_df, use_container_width=True)
    
    # City details
    st.subheader("City Details")
    if len(filtered_df) > 0:
        selected_city = st.selectbox("Select a city for detailed information", filtered_df["city"].tolist())
        
        if selected_city:
            city_data = filtered_df[filtered_df["city"] == selected_city].iloc[0]
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown(f"**City:** {city_data['city']}")
                st.markdown(f"**Country:** {city_data['country']}")
                st.markdown(f"**Region:** {city_data['region']}")
                st.markdown(f"**Population:** {city_data['population']:,}")
            
            with col2:
                st.markdown(f"**Friendliness Score:** {city_data['friendliness_score']}/10")
                
                # Display water quality with color coding
                water_quality = city_data['water_quality_score']
                quality_color = "green" if water_quality >= 8 else "orange" if water_quality >= 6 else "red"
                st.markdown(f"**Water Quality Score:** <span style='color:{quality_color};font-weight:bold;'>{water_quality}/10</span>", unsafe_allow_html=True)
                
                st.markdown(f"**Primary Water Source:** {city_data['primary_water_source']}")
                st.markdown(f"**Last Updated:** {city_data['last_updated']}")
            
            # Water quality assessment
            st.subheader("Water Quality Assessment")
            if water_quality >= 8:
                st.success("""
                **Excellent Water Quality**
                - Safe for consumption with standard treatment
                - Clean water sources with minimal contamination
                - Effective water management and protection programs
                - Regular testing and quality control
                """)
            elif water_quality >= 6:
                st.warning("""
                **Acceptable Water Quality**
                - Generally safe with appropriate treatment
                - Some contamination issues may exist
                - Water management could be improved
                - Regular monitoring in place
                """)
            else:
                st.error("""
                **Poor Water Quality**
                - May be unsafe for consumption without extensive treatment
                - Significant contamination issues
                - Inadequate water treatment infrastructure
                - Potential health risks to residents
                - Immediate water management improvements needed
                """)
    else:
        st.info("No cities match your current filters.")

def display_pollution_alerts_page(df):
    st.write("Stay informed about water pollution events and alerts from around the world.")
    
    # Filters
    col1, col2 = st.columns(2)
    
    with col1:
        min_pollution = st.slider("Minimum Pollution Level", 1, 10, 7)
    
    with col2:
        alert_types = st.multiselect(
            "Water Source Types", 
            ["rivers", "dams", "oceans", "tap water", "underground water", "spring water", "others"],
            ["rivers", "dams", "oceans"]
        )
    
    # Filter alerts
    alerts_df = df[(df["pollution_level"] >= min_pollution) & (df["type"].isin(alert_types))]
    alerts_df = alerts_df.sort_values("pollution_level", ascending=False)
    
    # Alerts count
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Active Alerts", len(alerts_df))
    
    with col2:
        if len(alerts_df) > 0:
            critical_count = len(alerts_df[alerts_df["pollution_level"] >= 9])
            st.metric("Critical Alerts (Level 9-10)", critical_count)
    
    with col3:
        if len(alerts_df) > 0:
            high_count = len(alerts_df[(alerts_df["pollution_level"] >= 7) & (alerts_df["pollution_level"] < 9)])
            st.metric("High Alerts (Level 7-8)", high_count)
    
    # Map of alerts
    st.subheader("Pollution Alerts Map")
    if len(alerts_df) > 0:
        map_layer = create_map_visualization(alerts_df, column_color="pollution_level")
        st.pydeck_chart(map_layer)
    else:
        st.info("No alerts match your current criteria.")
    
    # Alerts by region
    if len(alerts_df) > 0:
        st.subheader("Pollution Alerts by Region")
        region_counts = alerts_df["region"].value_counts().reset_index()
        region_counts.columns = ["Region", "Alert Count"]
        
        fig = px.bar(
            region_counts,
            x="Region",
            y="Alert Count",
            color="Alert Count",
            color_continuous_scale=["yellow", "orange", "red"],
            title="Distribution of Pollution Alerts by Region"
        )
        st.plotly_chart(fig, use_container_width=True)
    
    # Alerts table
    st.subheader("Current Alerts")
    
    if len(alerts_df) > 0:
        # Add detailed filters
        country_filter = st.selectbox("Filter by Country", ["All"] + sorted(alerts_df["country"].unique().tolist()))
        
        filtered_alerts = alerts_df
        if country_filter != "All":
            filtered_alerts = alerts_df[alerts_df["country"] == country_filter]
        
        for i, alert in filtered_alerts.iterrows():
            col1, col2, col3 = st.columns([3, 2, 1])
            
            severity = "🔴 Critical" if alert["pollution_level"] >= 9 else "🟠 High" if alert["pollution_level"] >= 7 else "🟡 Moderate"
            
            with col1:
                st.markdown(f"**{alert['name']}** ({alert['type'].capitalize()})")
                st.markdown(f"{alert['country']}, {alert['region']}")
            
            with col2:
                st.markdown(f"**Pollution Level:** {alert['pollution_level']}/10")
                st.markdown(f"**pH Level:** {alert['ph_level']}")
                st.markdown(f"**Updated:** {alert['last_updated']}")
            
            with col3:
                st.markdown(f"**{severity}**")
            
            # Add health recommendation based on pollution level
            if alert["pollution_level"] >= 9:
                st.error("""
                **Health Advisory: Critical**
                - Avoid all contact with water
                - Report to local authorities immediately
                - Significant environmental and health hazard
                """)
            elif alert["pollution_level"] >= 7:
                st.warning("""
                **Health Advisory: High Concern**
                - Avoid swimming, fishing, or recreational use
                - Do not consume fish from this water source
                - Keep pets and livestock away from water
                """)
            
            st.markdown("---")
    else:
        st.info("No pollution alerts match your criteria.")
    
    # Notification system mockup
    st.subheader("Notification Settings")
    st.write("Configure how you want to receive alerts about water pollution in your area.")
    
    notification_prefs = st.multiselect(
        "Notification Methods",
        ["Email", "SMS", "Mobile Push Notifications", "Weekly Report"],
        ["Email"]
    )
    
    alert_threshold = st.slider("Alert Threshold (Pollution Level)", 1, 10, 6)
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.text_input("Email Address", placeholder="your@email.com")
    
    with col2:
        st.text_input("Phone Number", placeholder="+1234567890")
    
    preferred_regions = st.multiselect(
        "Regions of Interest",
        df["region"].unique().tolist(),
        df["region"].unique().tolist()[:1] if len(df["region"].unique()) > 0 else []
    )
    
    st.button("Save Notification Preferences")
    st.info("Note: This is a demonstration of the notification system. In a production environment, this would connect to a real alerting system.")

def display_global_pollution_map(df):
    """Display an interactive global map focused on pollution levels"""
    st.write("Explore water pollution levels across the globe with this interactive map.")
    
    # Filter options
    col1, col2 = st.columns(2)
    
    with col1:
        min_pollution = st.slider("Minimum Pollution Level to Display", 1, 10, 1)
    
    with col2:
        selected_types = st.multiselect(
            "Water Source Types", 
            ["rivers", "dams", "oceans", "tap water", "underground water", "spring water", "others"],
            ["rivers", "dams", "oceans", "tap water", "underground water", "spring water", "others"]
        )
    
    # Filter data
    filtered_df = df[(df["pollution_level"] >= min_pollution) & (df["type"].isin(selected_types))]
    
    # Create the map
    st.subheader(f"Global Pollution Map (Showing {len(filtered_df)} Water Sources)")
    
    if len(filtered_df) > 0:
        # Display visualization explanation
        st.markdown("""
        **Map Legend:**
        - **Red**: High pollution (Levels 8-10)
        - **Orange/Yellow**: Moderate pollution (Levels 4-7)
        - **Green**: Low pollution (Levels 1-3)
        - **Size of dots**: Relative to pollution level
        
        Click on any point for detailed information. Zoom in/out to explore different regions.
        """)
        
        # Create enhanced map visualization
        map_view = create_map_visualization(filtered_df, column_color="pollution_level")
        st.pydeck_chart(map_view)
        
        # Show pollution statistics
        st.subheader("Pollution Statistics")
        
        # Calculate statistics
        total_sources = len(filtered_df)
        high_pollution = len(filtered_df[filtered_df["pollution_level"] >= 8])
        moderate_pollution = len(filtered_df[(filtered_df["pollution_level"] >= 4) & (filtered_df["pollution_level"] < 8)])
        low_pollution = len(filtered_df[filtered_df["pollution_level"] < 4])
        
        # Display metrics
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("High Pollution Sources", f"{high_pollution} ({high_pollution/total_sources*100:.1f}%)")
        
        with col2:
            st.metric("Moderate Pollution Sources", f"{moderate_pollution} ({moderate_pollution/total_sources*100:.1f}%)")
        
        with col3:
            st.metric("Low Pollution Sources", f"{low_pollution} ({low_pollution/total_sources*100:.1f}%)")
        
        # Add region breakdown
        st.subheader("Pollution by Region")
        
        # Group by region and calculate average pollution
        region_pollution = filtered_df.groupby("region")["pollution_level"].agg(
            ["mean", "min", "max", "count"]
        ).reset_index()
        region_pollution.columns = ["Region", "Average Pollution", "Minimum Pollution", "Maximum Pollution", "Source Count"]
        region_pollution = region_pollution.sort_values("Average Pollution", ascending=False)
        
        # Create visualization
        fig = px.bar(
            region_pollution,
            x="Region",
            y="Average Pollution",
            color="Average Pollution",
            color_continuous_scale=["green", "yellow", "orange", "red"],
            hover_data=["Minimum Pollution", "Maximum Pollution", "Source Count"],
            labels={"Average Pollution": "Avg. Pollution Level"},
            title="Average Pollution Level by Region"
        )
        
        st.plotly_chart(fig, use_container_width=True)
        
        # Add water type breakdown
        st.subheader("Pollution by Water Type")
        
        # Group by type and calculate average pollution
        type_pollution = filtered_df.groupby("type")["pollution_level"].agg(
            ["mean", "min", "max", "count"]
        ).reset_index()
        type_pollution.columns = ["Water Type", "Average Pollution", "Minimum Pollution", "Maximum Pollution", "Source Count"]
        type_pollution = type_pollution.sort_values("Average Pollution", ascending=False)
        
        # Create visualization
        fig = px.bar(
            type_pollution,
            x="Water Type",
            y="Average Pollution",
            color="Average Pollution",
            color_continuous_scale=["green", "yellow", "orange", "red"],
            hover_data=["Minimum Pollution", "Maximum Pollution", "Source Count"],
            labels={"Average Pollution": "Avg. Pollution Level"},
            title="Average Pollution Level by Water Type"
        )
        
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No water sources match your current filter criteria.")

def display_country_pollution_analysis(water_df, city_df):
    """Display detailed pollution analysis by country"""
    st.write("Analyze water pollution levels and water quality by country and continent.")
    
    # Get unique countries from both datasets
    water_countries = water_df["country"].unique().tolist()
    city_countries = city_df["country"].unique().tolist()
    all_countries = sorted(list(set(water_countries + city_countries)))
    
    # Remove "Multiple" from the list
    if "Multiple" in all_countries:
        all_countries.remove("Multiple")
    
    # Filter options
    col1, col2 = st.columns(2)
    
    with col1:
        # Add continent/region filter
        all_regions = ["All"] + sorted(water_df["region"].unique().tolist())
        if "Multiple" in all_regions:
            all_regions.remove("Multiple")
        selected_region = st.selectbox("Filter by Continent/Region", all_regions)
    
    with col2:
        # Add country selection
        filtered_countries = all_countries
        if selected_region != "All":
            # Filter countries by selected region
            region_water_df = water_df[water_df["region"] == selected_region]
            region_city_df = city_df[city_df["region"] == selected_region]
            region_countries = sorted(list(set(region_water_df["country"].unique().tolist() + region_city_df["country"].unique().tolist())))
            if "Multiple" in region_countries:
                region_countries.remove("Multiple")
            filtered_countries = region_countries
        
        selected_country = st.selectbox("Select Country for Detailed Analysis", ["All"] + filtered_countries)
    
    # Filter data based on selection
    filtered_water_df = water_df
    filtered_city_df = city_df
    
    if selected_region != "All":
        filtered_water_df = filtered_water_df[filtered_water_df["region"] == selected_region]
        filtered_city_df = filtered_city_df[filtered_city_df["region"] == selected_region]
    
    if selected_country != "All":
        filtered_water_df = filtered_water_df[filtered_water_df["country"] == selected_country]
        filtered_city_df = filtered_city_df[filtered_city_df["country"] == selected_country]
    
    # Display continent/region analysis
    if selected_country == "All":
        st.subheader(f"{'Global' if selected_region == 'All' else selected_region} Water Pollution Analysis")
        
        # Get countries in the region and their average pollution
        country_pollution = filtered_water_df.groupby("country")["pollution_level"].agg(
            ["mean", "min", "max", "count"]
        ).reset_index()
        country_pollution.columns = ["Country", "Average Pollution", "Minimum Pollution", "Maximum Pollution", "Water Source Count"]
        country_pollution = country_pollution.sort_values("Average Pollution", ascending=False)
        
        # Create visualization
        if len(country_pollution) > 0:
            fig = px.bar(
                country_pollution.head(20),  # Show top 20 if there are many
                x="Country",
                y="Average Pollution",
                color="Average Pollution",
                color_continuous_scale=["green", "yellow", "orange", "red"],
                hover_data=["Minimum Pollution", "Maximum Pollution", "Water Source Count"],
                labels={"Average Pollution": "Avg. Pollution Level"},
                title=f"Countries with Highest Average Water Pollution {'Globally' if selected_region == 'All' else 'in ' + selected_region}"
            )
            
            st.plotly_chart(fig, use_container_width=True)
            
            # Get city water quality by country
            city_water_quality = filtered_city_df.groupby("country")["water_quality_score"].agg(
                ["mean", "min", "max", "count"]
            ).reset_index()
            city_water_quality.columns = ["Country", "Average Water Quality", "Minimum Water Quality", "Maximum Water Quality", "City Count"]
            city_water_quality = city_water_quality.sort_values("Average Water Quality", ascending=False)
            
            if len(city_water_quality) > 0:
                # Create visualization for city water quality
                fig = px.bar(
                    city_water_quality.head(20),  # Show top 20 if there are many
                    x="Country",
                    y="Average Water Quality",
                    color="Average Water Quality",
                    color_continuous_scale=["red", "orange", "lightgreen", "green"],
                    hover_data=["Minimum Water Quality", "Maximum Water Quality", "City Count"],
                    labels={"Average Water Quality": "Avg. Water Quality Score"},
                    title=f"Countries with Highest Average City Water Quality {'Globally' if selected_region == 'All' else 'in ' + selected_region}"
                )
                
                st.plotly_chart(fig, use_container_width=True)
                
                # Create correlation chart between pollution and water quality
                if len(country_pollution) > 0 and len(city_water_quality) > 0:
                    # Merge datasets on country
                    merged_df = pd.merge(country_pollution, city_water_quality, on="Country", how="inner")
                    
                    if len(merged_df) > 0:
                        fig = px.scatter(
                            merged_df,
                            x="Average Pollution",
                            y="Average Water Quality",
                            hover_name="Country",
                            size="Water Source Count",
                            color="Average Water Quality",
                            color_continuous_scale=["red", "yellow", "green"],
                            labels={
                                "Average Pollution": "Average Water Source Pollution",
                                "Average Water Quality": "Average City Water Quality"
                            },
                            title="Correlation: Water Source Pollution vs City Water Quality by Country"
                        )
                        
                        # Add trend line
                        fig.update_layout(
                            shapes=[
                                {
                                    'type': 'line',
                                    'x0': merged_df["Average Pollution"].min(),
                                    'y0': merged_df["Average Water Quality"].max(),
                                    'x1': merged_df["Average Pollution"].max(),
                                    'y1': merged_df["Average Water Quality"].min(),
                                    'line': {
                                        'color': 'grey',
                                        'width': 2,
                                        'dash': 'dash',
                                    }
                                }
                            ]
                        )
                        
                        st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No water source data available for the selected region.")
    
    # Display country analysis
    else:
        st.subheader(f"{selected_country} Water Pollution Analysis")
        
        # Show map of water sources in the country
        if len(filtered_water_df) > 0:
            st.write(f"Map of Water Sources in {selected_country}")
            map_view = create_map_visualization(filtered_water_df, column_color="pollution_level")
            st.pydeck_chart(map_view)
            
            # Statistics
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.metric("Total Water Sources", len(filtered_water_df))
            
            with col2:
                avg_pollution = filtered_water_df["pollution_level"].mean()
                st.metric("Average Pollution Level", f"{avg_pollution:.1f}/10")
            
            with col3:
                high_pollution = len(filtered_water_df[filtered_water_df["pollution_level"] >= 7])
                st.metric("High Pollution Sources", f"{high_pollution} ({high_pollution/len(filtered_water_df)*100:.1f}%)")
            
            # Water type analysis
            st.subheader(f"Water Types in {selected_country}")
            country_water_types = filtered_water_df["type"].value_counts().reset_index()
            country_water_types.columns = ["Type", "Count"]
            
            fig = px.pie(
                country_water_types,
                values="Count",
                names="Type",
                title=f"Distribution of Water Source Types in {selected_country}"
            )
            
            st.plotly_chart(fig, use_container_width=True)
            
            # Most polluted sources
            st.subheader(f"Most Polluted Water Sources in {selected_country}")
            most_polluted = filtered_water_df.sort_values("pollution_level", ascending=False).head(10)
            
            if len(most_polluted) > 0:
                fig = px.bar(
                    most_polluted,
                    x="name",
                    y="pollution_level",
                    color="pollution_level",
                    color_continuous_scale=["yellow", "orange", "red"],
                    hover_data=["type", "ph_level"],
                    labels={"name": "Water Source", "pollution_level": "Pollution Level"},
                    title=f"Top Polluted Water Sources in {selected_country}"
                )
                
                st.plotly_chart(fig, use_container_width=True)
                
                # Table of all water sources
                st.subheader(f"All Water Sources in {selected_country}")
                display_df = filtered_water_df[["name", "type", "pollution_level", "ph_level", "size", "last_updated"]]
                display_df.columns = ["Name", "Type", "Pollution Level", "pH Level", "Size", "Last Updated"]
                st.dataframe(display_df.sort_values("Pollution Level", ascending=False), use_container_width=True)
        else:
            st.info(f"No water source data available for {selected_country}.")
        
        # Display city water quality data
        if len(filtered_city_df) > 0:
            st.subheader(f"Cities in {selected_country}")
            
            # Statistics
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.metric("Total Cities", len(filtered_city_df))
            
            with col2:
                avg_water_quality = filtered_city_df["water_quality_score"].mean()
                st.metric("Average Water Quality", f"{avg_water_quality:.1f}/10")
            
            with col3:
                good_quality = len(filtered_city_df[filtered_city_df["water_quality_score"] >= 8])
                st.metric("Good Water Quality Cities", f"{good_quality} ({good_quality/len(filtered_city_df)*100:.1f}%)")
            
            # City rankings
            fig = px.bar(
                filtered_city_df.sort_values("water_quality_score", ascending=False),
                x="city",
                y="water_quality_score",
                color="water_quality_score",
                color_continuous_scale=["red", "orange", "lightgreen", "green"],
                hover_data=["population", "primary_water_source"],
                labels={"city": "City", "water_quality_score": "Water Quality Score"},
                title=f"Cities in {selected_country} by Water Quality"
            )
            
            st.plotly_chart(fig, use_container_width=True)
            
            # Table of all cities
            st.subheader(f"All Cities in {selected_country}")
            display_df = filtered_city_df[["city", "water_quality_score", "friendliness_score", "population", "primary_water_source"]]
            display_df.columns = ["City", "Water Quality Score", "Friendliness Score", "Population", "Primary Water Source"]
            st.dataframe(display_df.sort_values("Water Quality Score", ascending=False), use_container_width=True)
        else:
            st.info(f"No city data available for {selected_country}.")

if __name__ == "__main__":
    main()
    # Add footer to every page
    display_footer()
