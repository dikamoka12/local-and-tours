import streamlit as st
import pandas as pd

st.set_page_config(
    page_title="Community Map Direct",
    page_icon="🗺️",
    layout="wide"
)

st.title("Community Map - Direct Access")
st.markdown("### This is a direct access version of the Community Map page")

# Create simple tabs
tab1, tab2 = st.tabs(["Map View", "Report Form"])

with tab1:
    st.write("This is where the map would be displayed")
    
with tab2:
    st.write("This is where the report form would be displayed")
    
    # Simple form
    with st.form("report_form"):
        name = st.text_input("Water Source Name")
        location = st.text_input("Location")
        pollution_level = st.slider("Pollution Level", 1, 10, 5)
        
        submitted = st.form_submit_button("Submit Report")
        if submitted:
            st.success("Report submitted successfully!")