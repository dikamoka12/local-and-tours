import streamlit as st
import pandas as pd
import plotly.express as px

st.set_page_config(
    page_title="SA Water Systems",
    page_icon="💧",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Main title with styling
st.markdown("<h1 style='text-align: center; color: #1E88E5; background-color: #E3F2FD; padding: 20px; border-radius: 10px;'>SOUTH AFRICAN WATER SYSTEMS</h1>", unsafe_allow_html=True)

# New header for TOURISTS AND LOCALS
st.markdown("<h2 style='text-align: center; font-size: 28px; color: #D81B60; background-color: #FCE4EC; padding: 15px; margin-top: 10px; border-radius: 10px;'>TOURISTS AND LOCALS</h2>", unsafe_allow_html=True)

# Subscription section
st.markdown("<h2 style='text-align: center; font-size: 28px; color: #6200EA; background-color: #EDE7F6; padding: 15px; margin-top: 30px; border-radius: 10px;'>SUBSCRIBE FOR CLEAN WATER ALERTS</h2>", unsafe_allow_html=True)

st.markdown("""
<div style='background-color:#EDE7F6; padding:20px; border-radius:10px;'>
    <p style='font-size:18px; text-align:center;'>Stay informed about water quality issues that may affect your health, religious ceremonies, or traditional practices</p>
    
    <div style='display:flex; justify-content:space-around; margin:20px 0;'>
        <div style='background-color:#D1C4E9; padding:15px; border-radius:10px; width:45%;'>
            <h4 style='font-size:20px;'>Monthly</h4>
            <p style='font-size:24px; font-weight:bold;'>R25.00</p>
            <p style='font-size:16px;'>Cancel anytime</p>
        </div>
        
        <div style='background-color:#D1C4E9; padding:15px; border-radius:10px; width:45%;'>
            <h4 style='font-size:20px;'>Yearly</h4>
            <p style='font-size:24px; font-weight:bold;'>R300.00</p>
            <p style='font-size:16px;'>Save R00.00 yearly</p>
        </div>
    </div>
    
    <h4 style='font-size:20px; margin-top:20px;'>Subscriber Benefits:</h4>
    <ul style='text-align:left; font-size:16px;'>
        <li><strong>Real-time Pollution Alerts</strong> - Get SMS and email notifications about water contamination in your area</li>
        <li><strong>Monthly Water Quality Reports</strong> - Detailed analysis of your local water sources</li>
        <li><strong>Community Forum Access</strong> - Connect with others concerned about water quality</li>
        <li><strong>Water Testing Kit</strong> - Annual subscribers receive a basic water testing kit</li>
        <li><strong>Spring Water Map Updates</strong> - Get notifications about newly accessible natural springs</li>
        <li><strong>Water Rights Advocacy</strong> - Support legal actions to protect public water access</li>
    </ul>
    
    <div style='margin-top:20px;'>
        <form>
            <input type="text" placeholder="Full Name" style='width:100%; padding:10px; margin-bottom:10px; border-radius:5px; border:1px solid #6200EA;'>
            <input type="email" placeholder="Email Address" style='width:100%; padding:10px; margin-bottom:10px; border-radius:5px; border:1px solid #6200EA;'>
            <input type="tel" placeholder="Mobile Number" style='width:100%; padding:10px; margin-bottom:10px; border-radius:5px; border:1px solid #6200EA;'>
            <select style='width:100%; padding:10px; margin-bottom:20px; border-radius:5px; border:1px solid #6200EA;'>
                <option value="">Select Your Region</option>
                <option value="gauteng">Gauteng</option>
                <option value="western_cape">Western Cape</option>
                <option value="eastern_cape">Eastern Cape</option>
                <option value="kwazulu_natal">KwaZulu-Natal</option>
                <option value="free_state">Free State</option>
                <option value="north_west">North West</option>
                <option value="mpumalanga">Mpumalanga</option>
                <option value="limpopo">Limpopo</option>
                <option value="northern_cape">Northern Cape</option>
            </select>
            <button style='background-color:#6200EA; color:white; width:100%; padding:12px; border:none; border-radius:5px; font-size:18px; cursor:pointer;'>Subscribe Now</button>
        </form>
    </div>
    
    <p style='font-size:14px; margin-top:10px;'>Your subscription supports water testing and community alert systems. Cancel anytime.</p>
</div>

<!-- Donation section under subscription -->
<div style='margin-top:30px; border:2px solid #00897B; border-radius:10px; padding:20px; text-align:center;'>
    <h3 style='font-size:24px; color:#00897B;'>One-Time Donation</h3>
    <p style='font-size:16px;'>Support our work with a one-time contribution to clean water initiatives</p>
    
    <div style='display:flex; justify-content:space-around; margin:20px 0;'>
        <div style='padding:10px; border-radius:5px; background-color:#E0F2F1; width:30%;'>
            <p style='font-weight:bold;'>R50</p>
        </div>
        <div style='padding:10px; border-radius:5px; background-color:#B2DFDB; width:30%;'>
            <p style='font-weight:bold;'>R100</p>
        </div>
        <div style='padding:10px; border-radius:5px; background-color:#80CBC4; width:30%;'>
            <p style='font-weight:bold;'>R500</p>
        </div>
    </div>
    
    <input type="text" placeholder="Enter custom amount" style='width:100%; padding:10px; margin-bottom:10px; border-radius:5px; border:1px solid #00897B;'>
    <button style='background-color:#00897B; color:white; width:100%; padding:10px; border:none; border-radius:5px; font-size:16px; cursor:pointer;'>Donate Now</button>
</div>
""", unsafe_allow_html=True)

# Footer message about forced removals
st.markdown("""
<div style='margin-top:50px; background-color:#263238; color:#FFFFFF; padding:20px; border-radius:10px; text-align:center;'>
    <p style='font-size:22px; font-weight:bold;'>Forced removals do catch up with the remover (apartheid)</p>
</div>
""", unsafe_allow_html=True)